package xyz.angames.dolphy.client.module.modules;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import xyz.angames.dolphy.client.module.Module;

@Environment(EnvType.CLIENT)
public class BoyKisserModule extends Module {
   public BoyKisserModule() {
      super("BoyKisser", Module.Category.MISC);
   }
}
