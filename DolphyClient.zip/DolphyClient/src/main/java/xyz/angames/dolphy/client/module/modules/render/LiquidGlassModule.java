package xyz.angames.dolphy.client.module.modules.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.setting.BooleanSetting;
import xyz.angames.dolphy.client.module.setting.ModeSetting;
import xyz.angames.dolphy.client.module.setting.NumberSetting;

@Environment(EnvType.CLIENT)
public class LiquidGlassModule extends Module {
   public final ModeSetting style = new ModeSetting("Style", "iOS Widget", "iOS Widget", "Dynamic Island", "Pure Lens");
   public final NumberSetting blurRadius = new NumberSetting("Blur Radius", 9.0, 0.0, 24.0, 0.5);
   public final NumberSetting refraction = new NumberSetting("Refraction", 0.065, 0.0, 0.20, 0.005);
   public final NumberSetting fresnelPower = new NumberSetting("Fresnel Power", 2.4, 0.5, 8.0, 0.1);
   public final NumberSetting rimGloss = new NumberSetting("Rim Gloss", 0.88, 0.0, 1.0, 0.02);
   public final NumberSetting glassTint = new NumberSetting("Glass Tint", 0.14, 0.0, 0.60, 0.02);
   public final NumberSetting squircle = new NumberSetting("Squircle", 2.8, 1.5, 5.5, 0.1);
   public final NumberSetting cornerRadius = new NumberSetting("Corner Radius", 16.0, 4.0, 28.0, 0.5);
   public final BooleanSetting themeRim = new BooleanSetting("Theme Rim", false);
   public final BooleanSetting innerGlass = new BooleanSetting("Inner Glass Pills", true);

   public LiquidGlassModule() {
      super("LiquidGlass", "iPhone iOS 26 Liquid Glass refractive test HUD.", Module.Category.RENDER);
      this.addSetting(this.style);
      this.addSetting(this.blurRadius);
      this.addSetting(this.refraction);
      this.addSetting(this.fresnelPower);
      this.addSetting(this.rimGloss);
      this.addSetting(this.glassTint);
      this.addSetting(this.squircle);
      this.addSetting(this.cornerRadius);
      this.addSetting(this.themeRim);
      this.addSetting(this.innerGlass);
      this.setEnabled(true);
   }
}
