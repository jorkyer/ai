package xyz.angames.dolphy;

import net.fabricmc.api.ModInitializer;

public class DolphyMod implements ModInitializer {
   public void onInitialize() {
   }
}
