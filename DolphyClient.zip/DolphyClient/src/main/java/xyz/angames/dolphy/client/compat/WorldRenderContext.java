package xyz.angames.dolphy.client.compat;

import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import org.joml.Matrix4f;

public class WorldRenderContext {
    private final class_4587 matrixStack;
    private final class_4184 camera;
    private final class_9779 tickCounter;
    private final class_4597 consumers;
    private final class_638 world;
    private final class_761 worldRenderer;
    private final class_757 gameRenderer;
    private final Matrix4f projectionMatrix;
    private final Matrix4f positionMatrix;

    public WorldRenderContext(
        class_4587 matrixStack,
        class_4184 camera,
        class_9779 tickCounter,
        class_4597 consumers,
        class_638 world,
        class_761 worldRenderer,
        class_757 gameRenderer
    ) {
        this.matrixStack = matrixStack;
        this.camera = camera;
        this.tickCounter = tickCounter;
        this.consumers = consumers;
        this.world = world;
        this.worldRenderer = worldRenderer;
        this.gameRenderer = gameRenderer;
        this.projectionMatrix = DolphyCompat.worldProjMat;
        this.positionMatrix = DolphyCompat.worldViewMat;
    }

    public WorldRenderContext(
        class_4587 matrixStack,
        class_9779 tickCounter,
        class_4184 camera,
        class_761 worldRenderer,
        Matrix4f projectionMatrix,
        Matrix4f positionMatrix
    ) {
        class_310 mc = class_310.method_1551();
        this.matrixStack = matrixStack;
        this.camera = camera;
        this.tickCounter = tickCounter;
        this.consumers = mc != null && mc.method_22940() != null ? mc.method_22940().method_23000() : null;
        this.world = mc != null ? mc.field_1687 : null;
        this.worldRenderer = worldRenderer;
        this.gameRenderer = mc != null ? mc.field_1773 : null;
        this.projectionMatrix = projectionMatrix != null ? projectionMatrix : DolphyCompat.worldProjMat;
        this.positionMatrix = positionMatrix != null ? positionMatrix : DolphyCompat.worldViewMat;
    }

    public class_4587 matrixStack() { return matrixStack; }
    public class_4184 camera() { return camera; }
    public class_9779 tickCounter() { return tickCounter; }
    public class_4597 consumers() { return consumers; }
    public class_638 world() { return world; }
    public class_761 worldRenderer() { return worldRenderer; }
    public class_757 gameRenderer() { return gameRenderer; }
    public Matrix4f projectionMatrix() { return projectionMatrix; }
    public Matrix4f positionMatrix() { return positionMatrix; }
}
