package xyz.angames.dolphy.loader;

import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.spec.*;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import javax.crypto.*;
import javax.crypto.spec.*;
import javax.imageio.ImageIO;
import javax.swing.*;

public class DolphyLoader extends JFrame {
    private static final String PUBLIC_KEY_B64 =
        "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEd/+qlBn3X31NnucXJvcoKaG2/cxTw95sO63HGIAthqf8Zkd7CvFDEj6i12KLvKeKhdYuIDD/I4wkFQaZQUGWpQ==";
    private static final String AES_CONTAINER_KEY = "DolphyClient-2.0-AES-Container-2026!";
    private static final long EPOCH_BASE_SEC = 1767225600L; // 2026-01-01 00:00:00 UTC

    private static final int WIN_W = 760;
    private static final int WIN_H = 475;
    private static final int SIDEBAR_W = 62;

    private static final String[] THEME_NAMES = {
        "Белоснежная",
        "Небесная",
        "Мята",
        "Банановая",
        "Виноград",
        "Арбуз",
        "Лаванда",
        "Уголь",
        "Нефрит",
        "Бирюза",
        "Персик"
    };

    private static final Color[] THEME_COLORS = {
        new Color(235, 240, 250), // Белоснежная
        new Color(56, 189, 248),  // Небесная
        new Color(52, 211, 153),  // Мята
        new Color(250, 204, 21),  // Банановая
        new Color(124, 58, 237),  // Виноград (default from video)
        new Color(244, 63, 94),   // Арбуз
        new Color(168, 85, 247),  // Лаванда
        new Color(148, 163, 184), // Уголь
        new Color(16, 185, 129),  // Нефрит
        new Color(45, 212, 191),  // Бирюза
        new Color(251, 146, 60)   // Персик
    };

    private static volatile long accurateTimeMillis = System.currentTimeMillis();

    private final String hwid;
    private BufferedImage dolphinIcon;
    private int activeTab = 0; // 0 = Home, 1 = Versions/License, 2 = Settings

    private String licenseKey;
    private KeyValidationResult cachedValidation;
    private String mcDirPath;
    private int ramGb = 10;
    private int themeIndex = 4; // Виноград
    private boolean hideAfterLaunch = false;
    private int selectedMcVersion = 0; // 0 = 1.21.11 Fabric

    private int focusedInput = 0; // 0 = none, 1 = key, 2 = mcDir
    private boolean themeDropdownOpen = false;
    private int hoveredDropdownItem = -1;
    private boolean draggingRam = false;

    private String statusText = "Готов к установке и запуску • Версия 1.21.11 Fabric";
    private boolean isInjected = false;
    private volatile boolean isInjecting = false;
    private File injectedModFile = null;

    private final LauncherCanvas canvas;

    public DolphyLoader() {
        this.hwid = computeHwid();
        this.licenseKey = loadSavedKey();
        this.mcDirPath = loadSavedMcDir();
        loadLoaderSettings();
        this.cachedValidation = validateKeyFast(this.hwid, this.licenseKey);

        setTitle("DolphyVisuals 2.1 — Launcher");
        setSize(WIN_W, WIN_H);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        try {
            setShape(new RoundRectangle2D.Float(0, 0, WIN_W, WIN_H, 16, 16));
        } catch (Throwable ignored) {
        }

        try (InputStream is = DolphyLoader.class.getResourceAsStream("/icon.png")) {
            if (is != null) {
                dolphinIcon = ImageIO.read(is);
                setIconImage(dolphinIcon);
            }
        } catch (Exception ignored) {
        }

        Runtime.getRuntime().addShutdownHook(new Thread(this::cleanInjectedMod));

        canvas = new LauncherCanvas();
        canvas.setFocusable(true);
        setContentPane(canvas);

        Thread timeThread = new Thread(() -> {
            long synced = fetchAccurateTimeMillisBlocking();
            accurateTimeMillis = synced;
            KeyValidationResult updated = validateKeyFast(this.hwid, this.licenseKey);
            SwingUtilities.invokeLater(() -> {
                this.cachedValidation = updated;
                canvas.repaint();
            });
        }, "dolphy-time-sync");
        timeThread.setDaemon(true);
        timeThread.start();

        Timer animTimer = new Timer(16, e -> canvas.tickAnimation());
        animTimer.start();
    }

    private Color getAccent() {
        return THEME_COLORS[Math.max(0, Math.min(THEME_COLORS.length - 1, themeIndex))];
    }

    private void refreshKeyValidation() {
        this.cachedValidation = validateKeyFast(this.hwid, this.licenseKey);
    }

    private class LauncherCanvas extends JPanel {
        private Point dragOffset = null;
        private int mouseX = -1, mouseY = -1;
        private float installHover = 0f;
        private float cleanHover = 0f;
        private float pasteHover = 0f;
        private float browseHover = 0f;
        private float copyHwidHover = 0f;
        private float closeHover = 0f;
        private float minHover = 0f;
        private float exitHover = 0f;
        private final float[] tabHovers = new float[3];
        private int caretTick = 0;
        private boolean caretVisible = true;

        public LauncherCanvas() {
            setOpaque(true);
            setDoubleBuffered(true);
            setBackground(new Color(10, 10, 15));

            MouseAdapter ma = new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    requestFocusInWindow();
                    int mx = e.getX(), my = e.getY();

                    if (activeTab == 2 && !themeDropdownOpen && isInRect(mx, my, 114, 110, WIN_W - 156, 20)) {
                        draggingRam = true;
                        updateRamFromMouse(mx);
                        repaint();
                        return;
                    }

                    if (my <= 38 && mx > SIDEBAR_W && mx < WIN_W - 80) {
                        dragOffset = e.getPoint();
                        return;
                    }
                    handleClick(mx, my);
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    dragOffset = null;
                    if (draggingRam) {
                        draggingRam = false;
                        saveLoaderSettings();
                    }
                }

                @Override
                public void mouseDragged(MouseEvent e) {
                    if (draggingRam) {
                        updateRamFromMouse(e.getX());
                        repaint();
                        return;
                    }
                    if (dragOffset != null) {
                        Point loc = DolphyLoader.this.getLocation();
                        DolphyLoader.this.setLocation(loc.x + e.getX() - dragOffset.x, loc.y + e.getY() - dragOffset.y);
                    }
                }

                @Override
                public void mouseMoved(MouseEvent e) {
                    mouseX = e.getX();
                    mouseY = e.getY();
                    int oldDrop = hoveredDropdownItem;
                    hoveredDropdownItem = -1;
                    if (activeTab == 2 && themeDropdownOpen) {
                        int dropX = 114, dropY = 362, dropW = WIN_W - 156, itemH = 22;
                        if (isInRect(mouseX, mouseY, dropX, dropY, dropW, THEME_NAMES.length * itemH)) {
                            hoveredDropdownItem = (mouseY - dropY) / itemH;
                        }
                    }
                    if (oldDrop != hoveredDropdownItem) {
                        repaint();
                    }
                    updateCursor(mouseX, mouseY);
                }
            };
            addMouseListener(ma);
            addMouseMotionListener(ma);

            addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    if (focusedInput == 0) return;
                    if ((e.isControlDown() || e.isMetaDown()) && e.getKeyCode() == KeyEvent.VK_V) {
                        if (focusedInput == 1) {
                            pasteClipboardToKey();
                        } else if (focusedInput == 2) {
                            try {
                                String clip = (String) Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
                                if (clip != null && !clip.trim().isEmpty()) {
                                    mcDirPath = clip.trim();
                                    saveMcDir(mcDirPath);
                                    statusText = "Путь к папке игры сохранён: " + mcDirPath;
                                }
                            } catch (Exception ignored) {
                            }
                        }
                        repaint();
                        return;
                    }
                    if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
                        if (focusedInput == 1 && !licenseKey.isEmpty()) {
                            licenseKey = licenseKey.substring(0, licenseKey.length() - 1);
                            saveKey(licenseKey);
                            refreshKeyValidation();
                        } else if (focusedInput == 2 && !mcDirPath.isEmpty()) {
                            mcDirPath = mcDirPath.substring(0, mcDirPath.length() - 1);
                            saveMcDir(mcDirPath);
                        }
                        repaint();
                    } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                        focusedInput = 0;
                        if (activeTab == 0) onInject();
                        repaint();
                    }
                }

                @Override
                public void keyTyped(KeyEvent e) {
                    if (focusedInput == 0 || e.isControlDown() || e.isMetaDown()) return;
                    char c = e.getKeyChar();
                    if (c >= 32 && c != 127) {
                        if (focusedInput == 1) {
                            licenseKey += c;
                            saveKey(licenseKey);
                            refreshKeyValidation();
                        } else if (focusedInput == 2) {
                            mcDirPath += c;
                            saveMcDir(mcDirPath);
                        }
                        repaint();
                    }
                }
            });
        }

        private void updateRamFromMouse(int mx) {
            int trackX = 114;
            int trackW = WIN_W - 156;
            float ratio = (mx - trackX) / (float) trackW;
            ratio = Math.max(0f, Math.min(1f, ratio));
            ramGb = Math.round(2 + ratio * 14);
        }

        private void updateCursor(int mx, int my) {
            boolean hand = isOverClose(mx, my) || isOverMin(mx, my) || isOverExit(mx, my) || getHoveredTab(mx, my) != -1;
            if (activeTab == 0) {
                hand |= isInRect(mx, my, 96, 240, 340, 34)
                     || isInRect(mx, my, 444, 240, 88, 34)
                     || isInRect(mx, my, 96, 292, 164, 42)
                     || (isInjected && isInRect(mx, my, 272, 292, 138, 42));
            } else if (activeTab == 1) {
                hand |= isInRect(mx, my, 96, 94, 296, 74)
                     || isInRect(mx, my, 406, 94, 296, 74)
                     || isInRect(mx, my, 114, 232, WIN_W - 252, 34)
                     || isInRect(mx, my, WIN_W - 130, 232, 88, 34)
                     || isInRect(mx, my, WIN_W - 148, 344, 106, 34);
            } else if (activeTab == 2) {
                if (themeDropdownOpen) {
                    int dropX = 114, dropY = 362, dropW = WIN_W - 156, itemH = 22;
                    hand |= isInRect(mx, my, dropX, dropY, dropW, THEME_NAMES.length * itemH);
                }
                hand |= isInRect(mx, my, 114, 110, WIN_W - 156, 20)
                     || isInRect(mx, my, 114, 226, WIN_W - 198, 34)
                     || isInRect(mx, my, WIN_W - 76, 226, 34, 34)
                     || isInRect(mx, my, 114, 326, WIN_W - 156, 34)
                     || isInRect(mx, my, 96, 392, WIN_W - 124, 42);
            }
            setCursor(Cursor.getPredefinedCursor(hand ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
        }

        private void handleClick(int mx, int my) {
            if (isOverClose(mx, my) || isOverExit(mx, my)) {
                cleanInjectedMod();
                System.exit(0);
                return;
            }
            if (isOverMin(mx, my)) {
                DolphyLoader.this.setState(Frame.ICONIFIED);
                return;
            }

            // Handle open theme dropdown first
            if (activeTab == 2 && themeDropdownOpen) {
                int dropX = 114, dropY = 362, dropW = WIN_W - 156, itemH = 22;
                if (isInRect(mx, my, dropX, dropY, dropW, THEME_NAMES.length * itemH)) {
                    int idx = (my - dropY) / itemH;
                    if (idx >= 0 && idx < THEME_NAMES.length) {
                        themeIndex = idx;
                        saveLoaderSettings();
                    }
                    themeDropdownOpen = false;
                    repaint();
                    return;
                }
                themeDropdownOpen = false;
                repaint();
                return;
            }

            int t = getHoveredTab(mx, my);
            if (t != -1) {
                activeTab = t;
                focusedInput = 0;
                themeDropdownOpen = false;
                repaint();
                return;
            }

            focusedInput = 0;

            if (activeTab == 0) {
                if (isInRect(mx, my, 96, 240, 340, 34)) {
                    focusedInput = 1;
                    repaint();
                    return;
                }
                if (isInRect(mx, my, 444, 240, 88, 34)) {
                    pasteClipboardToKey();
                    repaint();
                    return;
                }
                if (isInRect(mx, my, 96, 292, 164, 42)) {
                    onInject();
                    repaint();
                    return;
                }
                if (isInjected && isInRect(mx, my, 272, 292, 138, 42)) {
                    cleanInjectedMod();
                    isInjected = false;
                    statusText = "Мод выгружен из папки mods и следы сессии очищены.";
                    repaint();
                    return;
                }
            } else if (activeTab == 1) {
                if (isInRect(mx, my, 96, 94, 296, 74)) {
                    selectedMcVersion = 0;
                    saveLoaderSettings();
                    repaint();
                    return;
                }
                if (isInRect(mx, my, 406, 94, 296, 74)) {
                    selectedMcVersion = 1;
                    saveLoaderSettings();
                    repaint();
                    return;
                }
                if (isInRect(mx, my, 114, 232, WIN_W - 252, 34)) {
                    focusedInput = 1;
                    repaint();
                    return;
                }
                if (isInRect(mx, my, WIN_W - 130, 232, 88, 34)) {
                    pasteClipboardToKey();
                    repaint();
                    return;
                }
                if (isInRect(mx, my, WIN_W - 148, 344, 106, 34)) {
                    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(hwid), null);
                    statusText = "Ваш HWID скопирован в буфер обмена!";
                    repaint();
                    return;
                }
            } else if (activeTab == 2) {
                if (isInRect(mx, my, 114, 226, WIN_W - 198, 34)) {
                    focusedInput = 2;
                    repaint();
                    return;
                }
                if (isInRect(mx, my, WIN_W - 76, 226, 34, 34)) {
                    JFileChooser chooser = new JFileChooser(mcDirPath);
                    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                    if (chooser.showOpenDialog(DolphyLoader.this) == JFileChooser.APPROVE_OPTION) {
                        mcDirPath = chooser.getSelectedFile().getAbsolutePath();
                        saveMcDir(mcDirPath);
                        statusText = "Путь к папке игры сохранён: " + mcDirPath;
                        repaint();
                    }
                    return;
                }
                if (isInRect(mx, my, 114, 326, WIN_W - 156, 34)) {
                    themeDropdownOpen = !themeDropdownOpen;
                    repaint();
                    return;
                }
                if (isInRect(mx, my, 96, 392, WIN_W - 124, 42)) {
                    hideAfterLaunch = !hideAfterLaunch;
                    saveLoaderSettings();
                    repaint();
                    return;
                }
            }
            repaint();
        }

        private void pasteClipboardToKey() {
            try {
                String clip = (String) Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
                if (clip != null && !clip.trim().isEmpty()) {
                    licenseKey = clip.trim();
                    saveKey(licenseKey);
                    refreshKeyValidation();
                    KeyValidationResult res = cachedValidation;
                    statusText = res.valid ? "Ключ активирован: " + res.message : "Ошибка: " + res.message;
                }
            } catch (Exception ignored) {
            }
        }

        private boolean isOverClose(int mx, int my) {
            return isInRect(mx, my, WIN_W - 40, 10, 26, 22);
        }

        private boolean isOverMin(int mx, int my) {
            return isInRect(mx, my, WIN_W - 70, 10, 26, 22);
        }

        private boolean isOverExit(int mx, int my) {
            return isInRect(mx, my, 13, WIN_H - 52, 36, 36);
        }

        private int getHoveredTab(int mx, int my) {
            for (int i = 0; i < 3; i++) {
                int ty = 86 + i * 48;
                if (isInRect(mx, my, 13, ty, 36, 36)) {
                    return i;
                }
            }
            return -1;
        }

        private boolean isInRect(int mx, int my, int x, int y, int w, int h) {
            return mx >= x && mx <= x + w && my >= y && my <= y + h;
        }

        private float stepToward(float current, float target, float speed) {
            float diff = target - current;
            if (Math.abs(diff) < 0.004f) {
                return target;
            }
            return current + diff * speed;
        }

        public void tickAnimation() {
            boolean dirty = false;

            for (int i = 0; i < 3; i++) {
                float target = (getHoveredTab(mouseX, mouseY) == i || activeTab == i) ? 1f : 0f;
                float next = stepToward(tabHovers[i], target, 0.25f);
                if (next != tabHovers[i]) {
                    tabHovers[i] = next;
                    dirty = true;
                }
            }

            float nextInstall = stepToward(installHover, (activeTab == 0 && isInRect(mouseX, mouseY, 96, 292, 164, 42)) ? 1f : 0f, 0.25f);
            if (nextInstall != installHover) { installHover = nextInstall; dirty = true; }

            float nextClean = stepToward(cleanHover, (activeTab == 0 && isInjected && isInRect(mouseX, mouseY, 272, 292, 138, 42)) ? 1f : 0f, 0.25f);
            if (nextClean != cleanHover) { cleanHover = nextClean; dirty = true; }

            float nextPaste = stepToward(pasteHover, ((activeTab == 0 && isInRect(mouseX, mouseY, 444, 240, 88, 34))
                || (activeTab == 1 && isInRect(mouseX, mouseY, WIN_W - 130, 232, 88, 34))) ? 1f : 0f, 0.25f);
            if (nextPaste != pasteHover) { pasteHover = nextPaste; dirty = true; }

            float nextBrowse = stepToward(browseHover, (activeTab == 2 && isInRect(mouseX, mouseY, WIN_W - 76, 226, 34, 34)) ? 1f : 0f, 0.25f);
            if (nextBrowse != browseHover) { browseHover = nextBrowse; dirty = true; }

            float nextCopy = stepToward(copyHwidHover, (activeTab == 1 && isInRect(mouseX, mouseY, WIN_W - 148, 344, 106, 34)) ? 1f : 0f, 0.25f);
            if (nextCopy != copyHwidHover) { copyHwidHover = nextCopy; dirty = true; }

            float nextClose = stepToward(closeHover, isOverClose(mouseX, mouseY) ? 1f : 0f, 0.28f);
            if (nextClose != closeHover) { closeHover = nextClose; dirty = true; }

            float nextMin = stepToward(minHover, isOverMin(mouseX, mouseY) ? 1f : 0f, 0.28f);
            if (nextMin != minHover) { minHover = nextMin; dirty = true; }

            float nextExit = stepToward(exitHover, isOverExit(mouseX, mouseY) ? 1f : 0f, 0.25f);
            if (nextExit != exitHover) { exitHover = nextExit; dirty = true; }

            if (focusedInput != 0) {
                caretTick++;
                if (caretTick >= 30) {
                    caretTick = 0;
                    caretVisible = !caretVisible;
                    dirty = true;
                }
            }

            if (dirty) {
                repaint();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);

            Color accent = getAccent();

            // 1. Main Obsidian Background (#0A0A0F)
            g2.setColor(new Color(10, 10, 15));
            g2.fillRect(0, 0, WIN_W, WIN_H);

            // Subtle ambient radial glow on Home tab
            if (activeTab == 0) {
                RadialGradientPaint rgp = new RadialGradientPaint(
                    new Point2D.Float(180f, 220f),
                    240f,
                    new float[]{0f, 1f},
                    new Color[]{new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 24), new Color(10, 10, 15, 0)}
                );
                g2.setPaint(rgp);
                g2.fillRect(SIDEBAR_W, 0, WIN_W - SIDEBAR_W, WIN_H);
            }

            // 2. Left Narrow Icon Sidebar (#0D0D14)
            g2.setColor(new Color(13, 13, 20));
            g2.fillRect(0, 0, SIDEBAR_W, WIN_H);
            g2.setColor(new Color(255, 255, 255, 14));
            g2.drawLine(SIDEBAR_W, 0, SIDEBAR_W, WIN_H);

            drawNarrowSidebar(g2, accent);
            drawTopWindowButtons(g2);

            // Right-edge vertical accent bar (exact match to video)
            g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 210));
            g2.fillRoundRect(WIN_W - 4, 42, 3, WIN_H - 84, 3, 3);

            // 3. Content Area
            if (activeTab == 0) {
                drawHomeTab(g2, accent);
            } else if (activeTab == 1) {
                drawVersionsTab(g2, accent);
            } else {
                drawSettingsTab(g2, accent);
            }

            // Outer border
            g2.setColor(new Color(255, 255, 255, 20));
            g2.setStroke(new BasicStroke(1f));
            g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, WIN_W - 1f, WIN_H - 1f, 16, 16));

            g2.dispose();
        }

        private void drawNarrowSidebar(Graphics2D g2, Color accent) {
            // Top Logo Square (x=13, y=18, 36x36)
            int lx = 13, ly = 18, ls = 36;
            g2.setColor(accent);
            g2.fillRoundRect(lx, ly, ls, ls, 10, 10);

            boolean darkText = (accent.getRed() * 0.299 + accent.getGreen() * 0.587 + accent.getBlue() * 0.114) > 185;
            g2.setColor(darkText ? new Color(15, 15, 22) : Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 18));
            FontMetrics fm = g2.getFontMetrics();
            String letter = "D";
            g2.drawString(letter, lx + (ls - fm.stringWidth(letter)) / 2, ly + (ls + fm.getAscent() - fm.getDescent()) / 2 - 1);

            // 3 Navigation Icon Buttons
            for (int i = 0; i < 3; i++) {
                int bx = 13;
                int by = 86 + i * 48;
                float hov = tabHovers[i];
                if (activeTab == i) {
                    g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 48));
                    g2.fillRoundRect(bx, by, 36, 36, 10, 10);
                } else if (hov > 0.02f) {
                    g2.setColor(new Color(255, 255, 255, (int) (22 * hov)));
                    g2.fillRoundRect(bx, by, 36, 36, 10, 10);
                }

                Color iconCol = activeTab == i
                    ? accent
                    : new Color(145 + (int) (70 * hov), 145 + (int) (70 * hov), 165 + (int) (60 * hov));
                g2.setColor(iconCol);
                g2.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

                int cx = bx + 18, cy = by + 18;
                if (i == 0) {
                    // Home icon (house outline)
                    int[] px = {cx - 7, cx, cx + 7};
                    int[] py = {cy - 1, cy - 7, cy - 1};
                    g2.drawPolyline(px, py, 3);
                    g2.drawRect(cx - 5, cy - 1, 10, 8);
                } else if (i == 1) {
                    // Versions / List card icon
                    g2.drawRoundRect(cx - 7, cy - 7, 14, 14, 3, 3);
                    g2.drawLine(cx - 4, cy - 2, cx + 4, cy - 2);
                    g2.drawLine(cx - 4, cy + 2, cx + 4, cy + 2);
                } else {
                    // Settings gear icon
                    g2.drawOval(cx - 4, cy - 4, 8, 8);
                    for (int a = 0; a < 8; a++) {
                        double rad = a * Math.PI / 4.0;
                        int x1 = cx + (int) Math.round(Math.cos(rad) * 5.0);
                        int y1 = cy + (int) Math.round(Math.sin(rad) * 5.0);
                        int x2 = cx + (int) Math.round(Math.cos(rad) * 7.2);
                        int y2 = cy + (int) Math.round(Math.sin(rad) * 7.2);
                        g2.drawLine(x1, y1, x2, y2);
                    }
                }
            }

            // Bottom Exit Icon (x=13, y=WIN_H - 52)
            int ex = 13, ey = WIN_H - 52;
            if (exitHover > 0.02f) {
                g2.setColor(new Color(239, 68, 68, (int) (40 * exitHover)));
                g2.fillRoundRect(ex, ey, 36, 36, 10, 10);
            }
            g2.setColor(exitHover > 0.1f ? new Color(248, 113, 113) : new Color(135, 135, 155));
            g2.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            int ecx = ex + 18, ecy = ey + 18;
            g2.drawLine(ecx - 2, ecy - 6, ecx - 6, ecy - 6);
            g2.drawLine(ecx - 6, ecy - 6, ecx - 6, ecy + 6);
            g2.drawLine(ecx - 6, ecy + 6, ecx - 2, ecy + 6);
            g2.drawLine(ecx - 2, ecy, ecx + 6, ecy);
            g2.drawLine(ecx + 3, ecy - 3, ecx + 6, ecy);
            g2.drawLine(ecx + 3, ecy + 3, ecx + 6, ecy);
        }

        private void drawTopWindowButtons(Graphics2D g2) {
            int minX = WIN_W - 70, btnY = 10;
            if (minHover > 0.02f) {
                g2.setColor(new Color(255, 255, 255, (int) (28 * minHover)));
                g2.fillRoundRect(minX, btnY, 26, 22, 6, 6);
            }
            g2.setColor(new Color(180, 180, 200));
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawLine(minX + 8, btnY + 11, minX + 18, btnY + 11);

            int clsX = WIN_W - 40;
            if (closeHover > 0.02f) {
                g2.setColor(new Color(239, 68, 68, (int) (190 * closeHover)));
                g2.fillRoundRect(clsX, btnY, 26, 22, 6, 6);
            }
            g2.setColor(closeHover > 0.1f ? Color.WHITE : new Color(180, 180, 200));
            g2.drawLine(clsX + 8, btnY + 6, clsX + 18, btnY + 16);
            g2.drawLine(clsX + 18, btnY + 6, clsX + 8, btnY + 16);
        }

        private void drawHomeTab(Graphics2D g2, Color accent) {
            // Top-left online indicator (like in video)
            g2.setColor(new Color(52, 211, 153));
            g2.fillOval(96, 26, 7, 7);
            g2.setColor(new Color(190, 195, 210));
            g2.setFont(new Font("SansSerif", Font.BOLD, 11));
            g2.drawString("Онлайн • v2.1 (1.21.11)", 110, 34);

            // Subtitle "КЛИЕНТ"
            g2.setColor(accent);
            g2.setFont(new Font("SansSerif", Font.BOLD, 10));
            g2.drawString("КЛИЕНТ", 96, 98);

            // Huge "DOLPHY" Title
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 38));
            g2.drawString("DOLPHY", 94, 138);

            // Description block
            g2.setColor(new Color(160, 165, 182));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawString("Погрузитесь в мир плавного геймплея и премиум визуалов. Запустите клиент,", 96, 166);
            g2.drawString("настройте анимированные обои, 119 3D-мечей, косметику Lunar и модуль", 96, 185);
            g2.drawString("Optimization. Полная поддержка Minecraft 1.21.11 Fabric.", 96, 204);

            // Compact License Key input row
            g2.setColor(new Color(140, 145, 165));
            g2.setFont(new Font("SansSerif", Font.BOLD, 11));
            g2.drawString("Лицензионный ключ доступа:", 96, 232);

            drawMinimalInputBox(g2, 96, 240, 340, 34, licenseKey, "Введите или вставьте ключ DLPH-...", focusedInput == 1, accent);
            drawSecondaryButton(g2, 444, 240, 88, 34, "Вставить", pasteHover, accent);

            // Main Action Button ("УСТАНОВИТЬ" / "ЗАПУСТИТЬ")
            String mainBtnText = isInjecting
                ? "УСТАНОВКА..."
                : (isInjected ? "ОБНОВИТЬ МОД" : "УСТАНОВИТЬ");
            drawPrimaryAccentButton(g2, 96, 292, 164, 42, mainBtnText, installHover, accent);

            if (isInjected) {
                drawSecondaryButton(g2, 272, 292, 138, 42, "Выгрузить мод", cleanHover, new Color(244, 63, 94));
            }

            // Bottom Footer Bar (exact match to video)
            g2.setColor(new Color(255, 255, 255, 12));
            g2.drawLine(SIDEBAR_W + 1, WIN_H - 46, WIN_W - 5, WIN_H - 46);

            g2.setColor(new Color(145, 150, 168));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
            g2.drawString("⚙  Версия: 1.21.11 Fabric  •  RAM: " + ramGb + " GB", 96, WIN_H - 21);

            KeyValidationResult kv = cachedValidation;
            String badge = kv.valid ? kv.tierBadge : "ОЖИДАНИЕ";
            g2.setFont(new Font("SansSerif", Font.BOLD, 10));
            int bw = g2.getFontMetrics().stringWidth(badge) + 16;
            int bx = 370;
            g2.setColor(kv.valid ? accent : new Color(65, 65, 85));
            g2.fillRoundRect(bx, WIN_H - 34, bw, 18, 6, 6);

            boolean darkText = kv.valid && (accent.getRed() * 0.299 + accent.getGreen() * 0.587 + accent.getBlue() * 0.114) > 185;
            g2.setColor(darkText ? new Color(15, 15, 22) : Color.WHITE);
            g2.drawString(badge, bx + 8, WIN_H - 21);

            g2.setColor(new Color(165, 170, 188));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
            String st = statusText;
            if (st.length() > 46) st = st.substring(0, 44) + "...";
            g2.drawString(st, bx + bw + 10, WIN_H - 21);
        }

        private void drawVersionsTab(Graphics2D g2, Color accent) {
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 21));
            g2.drawString("Выбор версии", 96, 52);

            g2.setColor(new Color(150, 155, 175));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawString("Целевая версия Minecraft 1.21.11 Fabric и проверка статуса вашей подписки:", 96, 76);

            // Version Card 1: 1.21.11 Fabric
            drawVersionCard(g2, 96, 94, 296, 74, "Minecraft 1.21.11 Fabric", "Актуальный релиз • Все функции и оптимизация", selectedMcVersion == 0, accent);
            // Version Card 2: 1.21.11 Fabric (Sodium / Iris)
            drawVersionCard(g2, 406, 94, 296, 74, "Minecraft 1.21.11 + Sodium", "Совместимый профиль MRE LiquidGlass 2.1", selectedMcVersion == 1, accent);

            // License Card
            drawOutlineCard(g2, 96, 186, WIN_W - 124, 102);
            g2.setColor(new Color(210, 215, 230));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawString("Лицензионный ключ подписки (ECDSA P-256)", 114, 214);

            drawMinimalInputBox(g2, 114, 232, WIN_W - 252, 34, licenseKey, "DLPH-LT-FFFFFFFF-...", focusedInput == 1, accent);
            drawSecondaryButton(g2, WIN_W - 130, 232, 88, 34, "Вставить", pasteHover, accent);

            KeyValidationResult kv = cachedValidation;
            g2.setColor(kv.valid ? new Color(52, 211, 153) : new Color(248, 113, 113));
            g2.setFont(new Font("SansSerif", Font.BOLD, 11));
            g2.drawString(kv.valid ? "✓ " + kv.message : "✕ " + kv.message, 114, 280);

            // HWID Card
            drawOutlineCard(g2, 96, 304, WIN_W - 124, 92);
            g2.setColor(new Color(210, 215, 230));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawString("Ваш уникальный Hardware ID (HWID)", 114, 332);

            g2.setColor(accent);
            g2.setFont(new Font("Monospaced", Font.BOLD, 16));
            g2.drawString(hwid, 114, 366);

            drawSecondaryButton(g2, WIN_W - 148, 344, 106, 34, "Скопировать", copyHwidHover, accent);
        }

        private void drawVersionCard(Graphics2D g2, int x, int y, int w, int h, String title, String sub, boolean selected, Color accent) {
            g2.setColor(new Color(14, 14, 22));
            g2.fillRoundRect(x, y, w, h, 12, 12);
            g2.setColor(selected ? accent : new Color(255, 255, 255, 22));
            g2.setStroke(new BasicStroke(selected ? 1.5f : 1f));
            g2.drawRoundRect(x, y, w, h, 12, 12);

            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 14));
            g2.drawString(title, x + 16, y + 30);

            g2.setColor(new Color(150, 155, 175));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
            g2.drawString(sub, x + 16, y + 52);

            if (selected) {
                g2.setColor(accent);
                g2.fillOval(x + w - 24, y + 16, 8, 8);
            }
        }

        private void drawSettingsTab(Graphics2D g2, Color accent) {
            // Exact replica of maxres.jpg ("Настройки")
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 21));
            g2.drawString("Настройки", 96, 52);

            int cardX = 96;
            int cardW = WIN_W - 124;

            // Card 1: Выделение RAM (y=74, h=104)
            drawOutlineCard(g2, cardX, 74, cardW, 104);
            g2.setColor(new Color(215, 220, 232));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawString("Выделение RAM", cardX + 18, 100);

            int trackX = cardX + 18;
            int trackW = cardW - 36;
            int sliderY = 120;
            g2.setColor(new Color(28, 28, 40));
            g2.fillRoundRect(trackX, sliderY - 2, trackW, 4, 4, 4);

            float ramRatio = (ramGb - 2) / 14f;
            int thumbX = trackX + Math.round(trackW * ramRatio);
            g2.setColor(accent);
            g2.fillOval(thumbX - 6, sliderY - 6, 12, 12);
            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(1.8f));
            g2.drawOval(thumbX - 6, sliderY - 6, 12, 12);

            g2.setColor(new Color(155, 160, 178));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
            g2.drawString("Память (Рекомендуется)", trackX, 149);

            String ramLabel = ramGb + " GB";
            g2.setColor(accent);
            g2.setFont(new Font("SansSerif", Font.BOLD, 11));
            int rw = g2.getFontMetrics().stringWidth(ramLabel);
            g2.drawString(ramLabel, trackX + trackW - rw, 149);

            // Progress bar under "Память (Рекомендуется)"
            g2.setColor(new Color(24, 24, 35));
            g2.fillRoundRect(trackX, 157, trackW, 6, 6, 6);
            g2.setColor(accent);
            g2.fillRoundRect(trackX, 157, Math.max(8, Math.round(trackW * ramRatio)), 6, 6, 6);

            // Card 2: Путь к папке игры (y=190, h=88)
            drawOutlineCard(g2, cardX, 190, cardW, 88);
            g2.setColor(new Color(215, 220, 232));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawString("Путь к папке игры", cardX + 18, 214);

            drawMinimalInputBox(g2, cardX + 18, 226, cardW - 78, 34, mcDirPath, "C:\\Users\\Admin\\AppData\\Roaming\\.minecraft", focusedInput == 2, accent);

            // Folder Icon Button (x = WIN_W - 76, y = 226, 34x34)
            int fx = WIN_W - 76, fy = 226;
            g2.setColor(new Color(20 + (int) (20 * browseHover), 20 + (int) (20 * browseHover), 30 + (int) (25 * browseHover)));
            g2.fillRoundRect(fx, fy, 34, 34, 8, 8);
            g2.setColor(browseHover > 0.1f ? accent : new Color(255, 255, 255, 28));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(fx, fy, 34, 34, 8, 8);
            // Draw crisp folder outline icon
            g2.setColor(new Color(210, 215, 230));
            g2.setStroke(new BasicStroke(1.4f));
            g2.drawRoundRect(fx + 10, fy + 12, 14, 10, 2, 2);
            g2.drawLine(fx + 10, fy + 12, fx + 15, fy + 12);
            g2.drawLine(fx + 10, fy + 10, fx + 14, fy + 10);
            g2.drawLine(fx + 14, fy + 10, fx + 16, fy + 12);

            // Card 3: Тема интерфейса (y=290, h=88)
            drawOutlineCard(g2, cardX, 290, cardW, 88);
            g2.setColor(new Color(215, 220, 232));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawString("Тема интерфейса", cardX + 18, 314);

            int dropX = cardX + 18, dropY = 326, dropW = cardW - 36, dropH = 34;
            g2.setColor(new Color(14, 14, 21));
            g2.fillRoundRect(dropX, dropY, dropW, dropH, 8, 8);
            g2.setColor(themeDropdownOpen ? accent : new Color(255, 255, 255, 28));
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRoundRect(dropX, dropY, dropW, dropH, 8, 8);

            g2.setColor(new Color(235, 238, 248));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawString(THEME_NAMES[themeIndex], dropX + 12, dropY + 21);

            // Chevron arrow on the right
            int chX = dropX + dropW - 18, chY = dropY + 15;
            g2.setColor(new Color(170, 175, 195));
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawLine(chX - 4, chY, chX, chY + 4);
            g2.drawLine(chX, chY + 4, chX + 4, chY);

            // Card 4: Checkbox "Скрывать лаунчер после запуска" (y=390, h=44)
            drawOutlineCard(g2, cardX, 390, cardW, 44);
            int cbX = cardX + 18, cbY = 404;
            if (hideAfterLaunch) {
                g2.setColor(accent);
                g2.fillRoundRect(cbX, cbY, 16, 16, 4, 4);
                boolean darkText = (accent.getRed() * 0.299 + accent.getGreen() * 0.587 + accent.getBlue() * 0.114) > 185;
                g2.setColor(darkText ? new Color(15, 15, 22) : Color.WHITE);
                g2.setStroke(new BasicStroke(1.8f));
                g2.drawLine(cbX + 4, cbY + 8, cbX + 7, cbY + 11);
                g2.drawLine(cbX + 7, cbY + 11, cbX + 12, cbY + 5);
            } else {
                g2.setColor(new Color(18, 18, 28));
                g2.fillRoundRect(cbX, cbY, 16, 16, 4, 4);
                g2.setColor(new Color(255, 255, 255, 45));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(cbX, cbY, 16, 16, 4, 4);
            }
            g2.setColor(new Color(210, 215, 230));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g2.drawString("Скрывать лаунчер после запуска", cbX + 26, cbY + 13);

            // Render open dropdown menu on top (exact match to maxres.jpg)
            if (themeDropdownOpen) {
                int listY = 200; // Open upwards/centered so all 11 items fit cleanly inside the window
                int itemH = 22;
                int listH = THEME_NAMES.length * itemH;
                int menuY = dropY + dropH + 2;
                if (menuY + listH > WIN_H - 8) {
                    menuY = WIN_H - 8 - listH;
                }
                g2.setColor(new Color(48, 48, 54));
                g2.fillRect(dropX, menuY, dropW, listH);
                g2.setColor(new Color(110, 110, 125));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRect(dropX, menuY, dropW, listH);

                for (int i = 0; i < THEME_NAMES.length; i++) {
                    int iy = menuY + i * itemH;
                    boolean hov = (i == hoveredDropdownItem) || (hoveredDropdownItem == -1 && i == themeIndex);
                    if (hov) {
                        g2.setColor(new Color(142, 192, 248));
                        g2.fillRect(dropX + 1, iy, dropW - 1, itemH);
                        g2.setColor(new Color(15, 20, 30));
                    } else {
                        g2.setColor(new Color(238, 240, 245));
                    }
                    g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
                    g2.drawString(THEME_NAMES[i], dropX + 10, iy + 15);
                }
            }
        }

        private void drawOutlineCard(Graphics2D g2, int x, int y, int w, int h) {
            g2.setColor(new Color(13, 13, 20));
            g2.fillRoundRect(x, y, w, h, 12, 12);
            g2.setColor(new Color(255, 255, 255, 18));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(x, y, w, h, 12, 12);
        }

        private void drawMinimalInputBox(Graphics2D g2, int x, int y, int w, int h, String value, String placeholder, boolean focused, Color accent) {
            g2.setColor(new Color(15, 15, 23));
            g2.fillRoundRect(x, y, w, h, 8, 8);
            g2.setColor(focused ? accent : new Color(255, 255, 255, 28));
            g2.setStroke(new BasicStroke(1.1f));
            g2.drawRoundRect(x, y, w, h, 8, 8);

            Shape oldClip = g2.getClip();
            g2.clipRect(x + 10, y + 2, w - 20, h - 4);
            Font f = new Font("SansSerif", Font.PLAIN, 12);
            g2.setFont(f);
            FontMetrics fm = g2.getFontMetrics(f);

            String display = (value == null || value.isEmpty()) ? placeholder : value;
            g2.setColor((value == null || value.isEmpty()) ? new Color(110, 115, 135) : new Color(238, 240, 248));

            int textW = fm.stringWidth(display);
            int drawX = x + 12;
            if (textW > w - 24 && value != null && !value.isEmpty()) {
                drawX = x + w - 14 - textW;
            }
            int drawY = y + (h + fm.getAscent() - fm.getDescent()) / 2 - 1;
            g2.drawString(display, drawX, drawY);

            if (focused && caretVisible) {
                int caretX = (value == null || value.isEmpty()) ? (x + 12) : (drawX + textW + 2);
                g2.setColor(accent);
                g2.fillRect(caretX, y + 8, 2, h - 16);
            }
            g2.setClip(oldClip);
        }

        private void drawPrimaryAccentButton(Graphics2D g2, int x, int y, int w, int h, String text, float hover, Color accent) {
            if (hover > 0.02f) {
                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), (int) (55 * hover)));
                g2.fillRoundRect(x - 3, y - 3, w + 6, h + 6, 14, 14);
            }
            g2.setColor(accent);
            g2.fillRoundRect(x, y, w, h, 10, 10);

            boolean darkText = (accent.getRed() * 0.299 + accent.getGreen() * 0.587 + accent.getBlue() * 0.114) > 185;
            g2.setColor(darkText ? new Color(15, 15, 22) : Color.WHITE);
            Font f = new Font("SansSerif", Font.BOLD, 12);
            g2.setFont(f);
            FontMetrics fm = g2.getFontMetrics(f);
            g2.drawString(text, x + (w - fm.stringWidth(text)) / 2, y + (h + fm.getAscent() - fm.getDescent()) / 2 - 1);
        }

        private void drawSecondaryButton(Graphics2D g2, int x, int y, int w, int h, String text, float hover, Color accent) {
            g2.setColor(new Color(22 + (int) (18 * hover), 22 + (int) (18 * hover), 34 + (int) (22 * hover)));
            g2.fillRoundRect(x, y, w, h, 8, 8);
            g2.setColor(hover > 0.1f ? accent : new Color(255, 255, 255, 28));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(x, y, w, h, 8, 8);

            g2.setColor(new Color(235, 238, 248));
            Font f = new Font("SansSerif", Font.BOLD, 11);
            g2.setFont(f);
            FontMetrics fm = g2.getFontMetrics(f);
            g2.drawString(text, x + (w - fm.stringWidth(text)) / 2, y + (h + fm.getAscent() - fm.getDescent()) / 2 - 1);
        }
    }

    public static File resolveModsDir(File selectedDir) {
        if (selectedDir.getName().equalsIgnoreCase("mods")) {
            return selectedDir;
        }
        File directMods = new File(selectedDir, "mods");
        if (directMods.isDirectory()) {
            return directMods;
        }
        File dotMcMods = new File(new File(selectedDir, ".minecraft"), "mods");
        if (dotMcMods.isDirectory()) {
            return dotMcMods;
        }
        File mcMods = new File(new File(selectedDir, "minecraft"), "mods");
        if (mcMods.isDirectory()) {
            return mcMods;
        }
        return directMods;
    }

    private void onInject() {
        if (isInjecting) return;
        refreshKeyValidation();
        KeyValidationResult validation = this.cachedValidation;
        if (!validation.valid) {
            statusText = "Ошибка: " + validation.message;
            canvas.repaint();
            return;
        }

        saveKey(this.licenseKey);
        saveMcDir(this.mcDirPath);
        saveLoaderSettings();

        File selectedDir = new File(this.mcDirPath);
        File modsDir = resolveModsDir(selectedDir);
        if (!modsDir.exists() && !modsDir.mkdirs()) {
            statusText = "Не удалось открыть или создать папку mods: " + modsDir;
            canvas.repaint();
            return;
        }

        this.isInjecting = true;
        this.statusText = "Установка защищённого клиента...";
        canvas.repaint();

        Thread injectWorker = new Thread(() -> {
            try {
                byte[] rawJarBytes = loadModPayload();
                if (rawJarBytes == null) {
                    SwingUtilities.invokeLater(() -> {
                        this.isInjecting = false;
                        this.statusText = "Ошибка: зашифрованный контейнер не найден!";
                        canvas.repaint();
                    });
                    return;
                }

                File outJar = new File(modsDir, "dolphyclient-2.0.jar");
                File[] existingFiles = modsDir.listFiles();
                if (existingFiles != null) {
                    for (File f : existingFiles) {
                        String ln = f.getName().toLowerCase(Locale.ROOT);
                        if (f.isFile() && ln.endsWith(".jar") && (ln.contains("dolphy") || ln.contains("astolfo"))) {
                            if (!f.delete() && f.exists()) {
                                String lockedName = f.getName();
                                SwingUtilities.invokeLater(() -> {
                                    this.isInjecting = false;
                                    this.statusText = "Закройте Minecraft! Файл " + lockedName + " занят игрой.";
                                    canvas.repaint();
                                });
                                return;
                            }
                        }
                    }
                }

                String token = this.licenseKey.trim() + "\n" + outJar.getAbsolutePath() + "\n";
                byte[] stampedJarBytes = stampLicenseIntoJar(rawJarBytes, token);
                Files.write(outJar.toPath(), stampedJarBytes);
                outJar.deleteOnExit();
                this.injectedModFile = outJar;

                File gameRoot = modsDir.getParentFile() != null ? modsDir.getParentFile() : selectedDir;
                File sessionFile = new File(gameRoot, ".dolphy_session");
                Files.write(sessionFile.toPath(), token.getBytes(StandardCharsets.UTF_8));
                sessionFile.deleteOnExit();

                Path homeAuth = Path.of(System.getProperty("user.home", "."), ".dolphy_auth");
                Files.write(homeAuth, token.getBytes(StandardCharsets.UTF_8));

                SwingUtilities.invokeLater(() -> {
                    this.isInjecting = false;
                    this.isInjected = true;
                    this.statusText = "Установлено в " + modsDir.getAbsolutePath();
                    if (this.hideAfterLaunch) {
                        DolphyLoader.this.setState(Frame.ICONIFIED);
                    }
                    canvas.repaint();
                });
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> {
                    this.isInjecting = false;
                    this.statusText = "Ошибка установки: " + ex.getMessage();
                    canvas.repaint();
                });
            }
        }, "dolphy-inject-worker");
        injectWorker.setDaemon(true);
        injectWorker.start();
    }

    public static byte[] stampLicenseIntoJar(byte[] rawJarBytes, String token) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(rawJarBytes.length + 512);
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(rawJarBytes));
             ZipOutputStream zos = new ZipOutputStream(baos)) {
            byte[] buf = new byte[8192];
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if ("META-INF/.dolphy_auth".equals(entry.getName())) {
                    continue;
                }
                ZipEntry copy = new ZipEntry(entry.getName());
                zos.putNextEntry(copy);
                int n;
                while ((n = zis.read(buf)) > 0) {
                    zos.write(buf, 0, n);
                }
                zos.closeEntry();
            }
            ZipEntry authEntry = new ZipEntry("META-INF/.dolphy_auth");
            zos.putNextEntry(authEntry);
            zos.write(token.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();
        }
        return baos.toByteArray();
    }

    public static byte[] loadModPayload() throws Exception {
        try (InputStream is = DolphyLoader.class.getResourceAsStream("/payload.enc")) {
            if (is != null) {
                byte[] encrypted = is.readAllBytes();
                return decryptAES(encrypted);
            }
        }
        return null;
    }

    private void cleanInjectedMod() {
        try {
            if (injectedModFile != null && injectedModFile.exists()) {
                injectedModFile.delete();
            }
            if (mcDirPath != null && !mcDirPath.isEmpty()) {
                File selected = new File(mcDirPath);
                File modsDir = resolveModsDir(selected);
                File gameRoot = modsDir.getParentFile() != null ? modsDir.getParentFile() : selected;
                File session = new File(gameRoot, ".dolphy_session");
                if (session.exists()) {
                    session.delete();
                }
            }
            Path homeAuth = Path.of(System.getProperty("user.home", "."), ".dolphy_auth");
            Files.deleteIfExists(homeAuth);
        } catch (Throwable ignored) {
        }
    }

    public static KeyValidationResult validateKeyFast(String hwid, String key) {
        if (key == null || key.trim().isEmpty()) {
            return new KeyValidationResult(false, "Введите лицензионный ключ!", "NO KEY");
        }
        String k = key.trim();
        String[] parts = k.split("-", 4);
        if (parts.length != 4 || !"DLPH".equalsIgnoreCase(parts[0])) {
            return new KeyValidationResult(false, "Неверный формат ключа!", "INVALID");
        }
        String type = parts[1].toUpperCase(Locale.ROOT);
        String expHex = parts[2].toUpperCase(Locale.ROOT);
        String sigB64 = parts[3];
        String cleanHwid = hwid.trim().toUpperCase(Locale.ROOT);

        try {
            byte[] pubBytes = Base64.getDecoder().decode(PUBLIC_KEY_B64);
            PublicKey pubKey = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(pubBytes));
            Signature verifier = Signature.getInstance("SHA256withECDSA");
            verifier.initVerify(pubKey);
            String payload = cleanHwid + ":" + type + ":" + expHex;
            verifier.update(payload.getBytes(StandardCharsets.UTF_8));
            byte[] sigBytes = Base64.getUrlDecoder().decode(sigB64);
            if (!verifier.verify(sigBytes)) {
                return new KeyValidationResult(false, "Ключ недействителен или привязан к другому HWID!", "WRONG HWID");
            }
        } catch (Exception e) {
            return new KeyValidationResult(false, "Цифровая подпись ключа повреждена!", "CORRUPT");
        }

        if ("LT".equals(type) || "FFFFFFFF".equals(expHex)) {
            return new KeyValidationResult(true, "Подписка активна • Навсегда (Lifetime)", "ГОТОВ");
        }
        try {
            long expOffsetSec = Long.parseUnsignedLong(expHex, 16);
            long expEpochSec = EPOCH_BASE_SEC + expOffsetSec;
            long nowSec = Math.max(System.currentTimeMillis(), accurateTimeMillis) / 1000L;
            if (nowSec > expEpochSec) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm");
                return new KeyValidationResult(false, "Срок ключа истёк (" + sdf.format(new Date(expEpochSec * 1000L)) + ")!", "EXPIRED");
            }
            long remSec = expEpochSec - nowSec;
            long days = remSec / 86400L;
            long hours = (remSec % 86400L) / 3600L;
            return new KeyValidationResult(true, "Активна • Осталось: " + days + " дн. " + hours + " ч.", "ГОТОВ");
        } catch (Exception e) {
            return new KeyValidationResult(false, "Ошибка чтения срока ключа!", "ERROR");
        }
    }

    public static long fetchAccurateTimeMillisBlocking() {
        long bestTime = System.currentTimeMillis();
        Path clkFile = Path.of(System.getProperty("user.home", "."), ".dolphy_clk");
        try {
            if (Files.exists(clkFile)) {
                long saved = Long.parseLong(Files.readString(clkFile, StandardCharsets.UTF_8).trim());
                if (saved > bestTime) {
                    bestTime = saved;
                }
            }
        } catch (Throwable ignored) {
        }
        String[] urls = new String[]{"https://www.google.com", "https://cloudflare.com"};
        for (String u : urls) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(u).openConnection();
                conn.setRequestMethod("HEAD");
                conn.setConnectTimeout(1500);
                conn.setReadTimeout(1500);
                conn.connect();
                long date = conn.getDate();
                conn.disconnect();
                if (date > 1700000000000L) {
                    bestTime = Math.max(bestTime, date);
                    break;
                }
            } catch (Throwable ignored) {
            }
        }
        try {
            Files.writeString(clkFile, Long.toString(bestTime), StandardCharsets.UTF_8);
        } catch (Throwable ignored) {
        }
        return bestTime;
    }

    public static class KeyValidationResult {
        public final boolean valid;
        public final String message;
        public final String tierBadge;

        public KeyValidationResult(boolean valid, String message, String tierBadge) {
            this.valid = valid;
            this.message = message;
            this.tierBadge = tierBadge;
        }
    }

    public static byte[] decryptAES(byte[] data) throws Exception {
        byte[] salt = new byte[16];
        byte[] iv = new byte[12];
        System.arraycopy(data, 0, salt, 0, 16);
        System.arraycopy(data, 16, iv, 0, 12);
        SecretKeyFactory kf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(AES_CONTAINER_KEY.toCharArray(), salt, 10000, 256);
        SecretKey key = new SecretKeySpec(kf.generateSecret(spec).getEncoded(), "AES");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
        return cipher.doFinal(data, 28, data.length - 28);
    }

    public static String computeHwid() {
        try {
            String raw = System.getProperty("os.name", "") + "|"
                + System.getProperty("os.arch", "") + "|"
                + System.getProperty("user.name", "") + "|"
                + System.getenv("PROCESSOR_IDENTIFIER") + "|"
                + Runtime.getRuntime().availableProcessors();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(raw.getBytes(StandardCharsets.UTF_8));
            return String.format("%02X%02X%02X%02X-%02X%02X%02X%02X", d[0], d[1], d[2], d[3], d[4], d[5], d[6], d[7]);
        } catch (Exception e) {
            return "DOLPHY-0000-0000";
        }
    }

    private static String loadSavedKey() {
        try {
            File f = new File(System.getProperty("user.home", "."), ".dolphy_license");
            if (f.exists()) {
                return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8).trim();
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private static void saveKey(String key) {
        try {
            File f = new File(System.getProperty("user.home", "."), ".dolphy_license");
            Files.write(f.toPath(), key.trim().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
        }
    }

    private static String loadSavedMcDir() {
        try {
            File f = new File(System.getProperty("user.home", "."), ".dolphy_mcdir");
            if (f.exists()) {
                String saved = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8).trim();
                if (!saved.isEmpty()) {
                    return saved;
                }
            }
        } catch (Exception ignored) {
        }
        return detectMinecraftDir().getAbsolutePath();
    }

    private static void saveMcDir(String path) {
        if (path == null || path.trim().isEmpty()) return;
        try {
            File f = new File(System.getProperty("user.home", "."), ".dolphy_mcdir");
            Files.write(f.toPath(), path.trim().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
        }
    }

    private void loadLoaderSettings() {
        try {
            Path p = Path.of(System.getProperty("user.home", "."), ".dolphy_loader_cfg");
            if (Files.exists(p)) {
                List<String> lines = Files.readAllLines(p, StandardCharsets.UTF_8);
                if (lines.size() >= 1) themeIndex = Math.max(0, Math.min(THEME_NAMES.length - 1, Integer.parseInt(lines.get(0).trim())));
                if (lines.size() >= 2) ramGb = Math.max(2, Math.min(16, Integer.parseInt(lines.get(1).trim())));
                if (lines.size() >= 3) hideAfterLaunch = Boolean.parseBoolean(lines.get(2).trim());
                if (lines.size() >= 4) selectedMcVersion = Math.max(0, Math.min(1, Integer.parseInt(lines.get(3).trim())));
            }
        } catch (Throwable ignored) {
        }
    }

    private void saveLoaderSettings() {
        try {
            Path p = Path.of(System.getProperty("user.home", "."), ".dolphy_loader_cfg");
            String data = themeIndex + "\n" + ramGb + "\n" + hideAfterLaunch + "\n" + selectedMcVersion + "\n";
            Files.writeString(p, data, StandardCharsets.UTF_8);
        } catch (Throwable ignored) {
        }
    }

    private static File detectMinecraftDir() {
        String appdata = System.getenv("APPDATA");
        if (appdata != null && !appdata.isEmpty()) {
            File prism12111 = new File(appdata, "PrismLauncher\\instances\\1.21.11\\minecraft");
            if (prism12111.isDirectory()) {
                return prism12111;
            }
            File prism1214 = new File(appdata, "PrismLauncher\\instances\\1.21.4\\minecraft");
            if (prism1214.isDirectory()) {
                return prism1214;
            }
            return new File(appdata, ".minecraft");
        }
        return new File(System.getProperty("user.home", "."), ".minecraft");
    }

    public static void main(String[] args) {
        if (GraphicsEnvironment.isHeadless()) {
            System.out.println("DolphyVisuals 2.1 Client Launcher (1.21.11 / 1.21.4)");
            System.out.println("Your HWID: " + computeHwid());
            return;
        }
        SwingUtilities.invokeLater(() -> new DolphyLoader().setVisible(true));
    }
}
