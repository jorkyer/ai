package xyz.angames.dolphy.client.module.modules.render;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.CustomModelDataComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Identifier;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.setting.BooleanSetting;
import xyz.angames.dolphy.client.module.setting.ModeSetting;

@Environment(EnvType.CLIENT)
public class ItemReplacerModule extends Module {
   private static final String[] MODELS = new String[]{
      "Abominable Blade",
      "Abominable Great Saber",
      "Abominable Scythe",
      "Acidic Cleaver",
      "Amethyst Shuriken",
      "Ancient Royal Great Sword",
      "Aquatic Sacred Blade",
      "Arcanethyst",
      "Ashura's Blade",
      "Awakened Lichblade",
      "Blood Edge",
      "Bloody Death",
      "Bramblethorn",
      "Brimstone Claymore",
      "Carian Knight's Sword",
      "Chrono Blade",
      "Corrupted Mythic Blade",
      "Creation Splitter",
      "Crescent Rose",
      "Cyber Katana",
      "Cyber Mantis Blade",
      "Cyber Sword",
      "Cybernetic Chainsaw Blade",
      "Cybernetic Katana",
      "Cybernetic Knife",
      "Dainsleif",
      "Dark Blade",
      "Dark Cleaver",
      "Death Knight's Dagger",
      "Death Knight's Sword",
      "Demigod's Unholy Blade",
      "Demigod's Unholy Halberd",
      "Demon Lord's Great Axe",
      "Demon Lord's Sword",
      "Demonic Blade",
      "Demonic Cleaver",
      "Divine Axe Rhitta",
      "Divine Justice",
      "Divine Punisher",
      "Divine Reaper",
      "Dragon Slaying blade",
      "Edge Of The Astral Plane",
      "Emberblade",
      "Enigma",
      "Epic Sword",
      "Estoc",
      "Fallen God's Spear",
      "Fallen God's Sword",
      "Floral Longsword",
      "Floral Sabre",
      "Forest Guardian's Glaive",
      "Frost Axe",
      "Frost Blade",
      "Frost Scythe",
      "Hearthflame",
      "Hero Sword",
      "Holy Moonlight Sword",
      "Hornet's Needle",
      "Icewhisper",
      "Jade Halberd",
      "Katana",
      "Legendary Sword",
      "Longsword",
      "Magi Scythe",
      "Masamune",
      "Mjolnir",
      "Molten Blade",
      "Molten Sword",
      "Muramasa",
      "Mystical Spellblade",
      "Mythic Blade",
      "Ocean's Rage",
      "Partisan",
      "Pharaoh's Treasure",
      "Pheonix Grace",
      "Plague Longsword",
      "Power Fuse Hammer",
      "Power Fuse Sword",
      "Requiem of the Ninth Abyss",
      "Ribbon Cleaver",
      "Righteous Relic",
      "Rivers Of Blood",
      "Royal Chakram",
      "Royal Rapier",
      "Sabre",
      "Scissor Blade",
      "Sculk Cleaver",
      "Sculk Scythe",
      "Sculk Sword",
      "Sentinel's Will",
      "Silverine Blade",
      "Soul Claws",
      "Soul Collector",
      "Soul Devourer",
      "Soul Edge",
      "Soul Harvester",
      "Soul Stealer",
      "Soulrender",
      "Star's Edge",
      "Steel Sword",
      "Stop Sign",
      "Storm Bringer",
      "Storm's Edge",
      "Sunbreak",
      "Tengen's Blade",
      "Terra Blade",
      "Thousand Demon Daggers",
      "Thunder Bringer",
      "Thunderbrand",
      "True Excalibur",
      "Vampiric Needle",
      "Wakizashi",
      "Watcher Claymore",
      "Watching Warglaive",
      "Waxweaver",
      "Whisperwind",
      "Wickpiercer",
      "Wraith Scythe",
      "Yoru"
   };
   private static final Map<String, String> MODEL_MAP = new HashMap<>();

   static {
      MODEL_MAP.put("Abominable Blade", "abominableblade");
      MODEL_MAP.put("Abominable Great Saber", "abominablegreatsaber");
      MODEL_MAP.put("Abominable Scythe", "abominablescythe");
      MODEL_MAP.put("Acidic Cleaver", "aciddemon");
      MODEL_MAP.put("Amethyst Shuriken", "amethyst_shuriken");
      MODEL_MAP.put("Ancient Royal Great Sword", "ancient_royal_great_sword");
      MODEL_MAP.put("Aquatic Sacred Blade", "aquantic_sacred_blade");
      MODEL_MAP.put("Arcanethyst", "arcanethyst");
      MODEL_MAP.put("Ashura's Blade", "ashura_blade");
      MODEL_MAP.put("Awakened Lichblade", "awakened_lichblade");
      MODEL_MAP.put("Blood Edge", "bloodedge");
      MODEL_MAP.put("Bloody Death", "bloodydeath");
      MODEL_MAP.put("Bramblethorn", "bramblethorn");
      MODEL_MAP.put("Brimstone Claymore", "brimstone_claymore");
      MODEL_MAP.put("Carian Knight's Sword", "cariansword");
      MODEL_MAP.put("Chrono Blade", "chrono_blade");
      MODEL_MAP.put("Corrupted Mythic Blade", "corruptedmythicblade");
      MODEL_MAP.put("Creation Splitter", "creationsplitter");
      MODEL_MAP.put("Crescent Rose", "crescentrose");
      MODEL_MAP.put("Cyber Katana", "cyberkatana");
      MODEL_MAP.put("Cyber Mantis Blade", "cybermantisblade");
      MODEL_MAP.put("Cyber Sword", "cybersword");
      MODEL_MAP.put("Cybernetic Chainsaw Blade", "cyberneticsawblade");
      MODEL_MAP.put("Cybernetic Katana", "cybernetickatana");
      MODEL_MAP.put("Cybernetic Knife", "cyberneticknife");
      MODEL_MAP.put("Dainsleif", "dainsleif");
      MODEL_MAP.put("Dark Blade", "dark_blade");
      MODEL_MAP.put("Dark Cleaver", "dark_cleaver");
      MODEL_MAP.put("Death Knight's Dagger", "death_knight_dagger");
      MODEL_MAP.put("Death Knight's Sword", "death_knight_sword");
      MODEL_MAP.put("Demigod's Unholy Blade", "demigodsunholyblade");
      MODEL_MAP.put("Demigod's Unholy Halberd", "demigodsunholyhalberd");
      MODEL_MAP.put("Demon Lord's Great Axe", "demonlordsgreataxe");
      MODEL_MAP.put("Demon Lord's Sword", "demonlordsword");
      MODEL_MAP.put("Demonic Blade", "demonicblade");
      MODEL_MAP.put("Demonic Cleaver", "demoniccleaver");
      MODEL_MAP.put("Divine Axe Rhitta", "divineaxerhitta");
      MODEL_MAP.put("Divine Justice", "divine_justice");
      MODEL_MAP.put("Divine Punisher", "divinepunisher");
      MODEL_MAP.put("Divine Reaper", "divine_reaper");
      MODEL_MAP.put("Dragon Slaying blade", "dragonslayingblade");
      MODEL_MAP.put("Edge Of The Astral Plane", "edgeoftheastralplane");
      MODEL_MAP.put("Emberblade", "emberblade");
      MODEL_MAP.put("Enigma", "enigma");
      MODEL_MAP.put("Epic Sword", "epicsword");
      MODEL_MAP.put("Estoc", "estoc");
      MODEL_MAP.put("Fallen God's Spear", "fallengodspear");
      MODEL_MAP.put("Fallen God's Sword", "fallengodsword");
      MODEL_MAP.put("Floral Longsword", "floral_longsword");
      MODEL_MAP.put("Floral Sabre", "floral_sabre");
      MODEL_MAP.put("Forest Guardian's Glaive", "forest_guardian_glaive");
      MODEL_MAP.put("Frost Axe", "frostaxe");
      MODEL_MAP.put("Frost Blade", "frostblade");
      MODEL_MAP.put("Frost Scythe", "frostscythe");
      MODEL_MAP.put("Hearthflame", "hearthflame");
      MODEL_MAP.put("Hero Sword", "herosword");
      MODEL_MAP.put("Holy Moonlight Sword", "holymoonlightsword");
      MODEL_MAP.put("Hornet's Needle", "hornetsneedle");
      MODEL_MAP.put("Icewhisper", "icewhisper");
      MODEL_MAP.put("Jade Halberd", "jadehalberd");
      MODEL_MAP.put("Katana", "katana");
      MODEL_MAP.put("Legendary Sword", "legendarysword");
      MODEL_MAP.put("Longsword", "longsword");
      MODEL_MAP.put("Magi Scythe", "magiscythe");
      MODEL_MAP.put("Masamune", "masamune");
      MODEL_MAP.put("Mjolnir", "mjolnir");
      MODEL_MAP.put("Molten Blade", "moltenblade");
      MODEL_MAP.put("Molten Sword", "moltensword");
      MODEL_MAP.put("Muramasa", "muramasa");
      MODEL_MAP.put("Mystical Spellblade", "mysticalspellblade");
      MODEL_MAP.put("Mythic Blade", "mythicblade");
      MODEL_MAP.put("Ocean's Rage", "aquantictrident");
      MODEL_MAP.put("Partisan", "partisan");
      MODEL_MAP.put("Pharaoh's Treasure", "pharaohs_treasure");
      MODEL_MAP.put("Pheonix Grace", "pheonixgrace");
      MODEL_MAP.put("Plague Longsword", "toxic_longsword");
      MODEL_MAP.put("Power Fuse Hammer", "powerfusehammer");
      MODEL_MAP.put("Power Fuse Sword", "powerfusesword");
      MODEL_MAP.put("Requiem of the Ninth Abyss", "requiem_of_hell");
      MODEL_MAP.put("Ribbon Cleaver", "ribboncleaver");
      MODEL_MAP.put("Righteous Relic", "righteous_relic");
      MODEL_MAP.put("Rivers Of Blood", "riversofblood");
      MODEL_MAP.put("Royal Chakram", "royalchakram");
      MODEL_MAP.put("Royal Rapier", "royalrapier");
      MODEL_MAP.put("Sabre", "sabre");
      MODEL_MAP.put("Scissor Blade", "scissorblade");
      MODEL_MAP.put("Sculk Cleaver", "sculkcleaver");
      MODEL_MAP.put("Sculk Scythe", "sculkscythe");
      MODEL_MAP.put("Sculk Sword", "sculksword");
      MODEL_MAP.put("Sentinel's Will", "sentinels_will");
      MODEL_MAP.put("Silverine Blade", "silverine_blade");
      MODEL_MAP.put("Soul Claws", "soulclaws");
      MODEL_MAP.put("Soul Collector", "soul_collector");
      MODEL_MAP.put("Soul Devourer", "soul_devourer");
      MODEL_MAP.put("Soul Edge", "souledge");
      MODEL_MAP.put("Soul Harvester", "soulharvester");
      MODEL_MAP.put("Soul Stealer", "soulstealer");
      MODEL_MAP.put("Soulrender", "soulrender");
      MODEL_MAP.put("Star's Edge", "stars_edge");
      MODEL_MAP.put("Steel Sword", "steelsword");
      MODEL_MAP.put("Stop Sign", "stop_sign");
      MODEL_MAP.put("Storm Bringer", "stormbringer");
      MODEL_MAP.put("Storm's Edge", "storms_edge");
      MODEL_MAP.put("Sunbreak", "sunbreak");
      MODEL_MAP.put("Tengen's Blade", "tengensblade");
      MODEL_MAP.put("Terra Blade", "terrablade");
      MODEL_MAP.put("Thousand Demon Daggers", "thousanddemondaggers");
      MODEL_MAP.put("Thunder Bringer", "thunderbringer");
      MODEL_MAP.put("Thunderbrand", "thunderbrand");
      MODEL_MAP.put("True Excalibur", "excalibur");
      MODEL_MAP.put("Vampiric Needle", "vampiricneedle");
      MODEL_MAP.put("Wakizashi", "wakizashi");
      MODEL_MAP.put("Watcher Claymore", "watcher_claymore");
      MODEL_MAP.put("Watching Warglaive", "watching_warglaive");
      MODEL_MAP.put("Waxweaver", "waxweaver");
      MODEL_MAP.put("Whisperwind", "whisperwind");
      MODEL_MAP.put("Wickpiercer", "wickpiercer");
      MODEL_MAP.put("Wraith Scythe", "greenscythe");
      MODEL_MAP.put("Yoru", "yoru");
   }

   private static ItemReplacerModule INSTANCE;
   private static final ThreadLocal<LivingEntity> CURRENT_ENTITY = new ThreadLocal<>();
   private static final ThreadLocal<Boolean> IS_NON_LIVING = ThreadLocal.withInitial(() -> Boolean.FALSE);

   public final ModeSetting model = new ModeSetting("Model", "Katana", MODELS);
   public final BooleanSetting onlyMe = new BooleanSetting("Only Me", true);
   public final BooleanSetting replaceAxes = new BooleanSetting("Replace Axes", false);
   public final BooleanSetting replaceMace = new BooleanSetting("Replace Mace", false);

   public ItemReplacerModule() {
      super("ItemReplacer", "Replaces swords with 119 custom 3D blades.", Module.Category.RENDER);
      this.addSettings(this.model, this.onlyMe, this.replaceAxes, this.replaceMace);
      INSTANCE = this;
   }

   public static ItemReplacerModule getInstance() {
      return INSTANCE;
   }

   public static void setCurrentEntity(LivingEntity entity) {
      CURRENT_ENTITY.set(entity);
      IS_NON_LIVING.set(Boolean.FALSE);
   }

   public static void setNonLivingContext() {
      CURRENT_ENTITY.remove();
      IS_NON_LIVING.set(Boolean.TRUE);
   }

   public static void clearContext() {
      CURRENT_ENTITY.remove();
      IS_NON_LIVING.set(Boolean.FALSE);
   }

   public ItemStack getRenderStack(ItemStack stack) {
      if (!this.isEnabled() || stack == null || stack.isEmpty()) {
         return stack;
      }

      Item item = stack.getItem();
      boolean validItem = item instanceof SwordItem
         || (this.replaceAxes.isEnabled() && item instanceof AxeItem)
         || (this.replaceMace.isEnabled() && item instanceof MaceItem);
      if (!validItem) {
         return stack;
      }

      if (this.onlyMe.isEnabled()) {
         if (Boolean.TRUE.equals(IS_NON_LIVING.get())) {
            return stack;
         }
         LivingEntity renderingEntity = CURRENT_ENTITY.get();
         MinecraftClient mc = MinecraftClient.getInstance();
         if (renderingEntity != null && mc != null && mc.player != null && renderingEntity != mc.player) {
            return stack;
         }
      }

      ItemStack copy = stack.copy();
      this.applyModel(copy);
      return copy;
   }

   private void applyModel(ItemStack stack) {
      String selected = this.model.get();
      String modelId = MODEL_MAP.get(selected);
      if (modelId != null) {
         stack.set(DataComponentTypes.ITEM_MODEL, Identifier.of("minecraft", modelId));
      }
      stack.set(
         DataComponentTypes.CUSTOM_MODEL_DATA,
         new CustomModelDataComponent(
            Collections.emptyList(),
            Collections.emptyList(),
            Collections.singletonList(selected),
            Collections.emptyList()
         )
      );
   }
}
