package xyz.angames.dolphy.client.gui;

import dev.sxmurxy.mre.builders.Builder;
import dev.sxmurxy.mre.builders.states.QuadColorState;
import dev.sxmurxy.mre.builders.states.QuadRadiusState;
import dev.sxmurxy.mre.builders.states.SizeState;
import dev.sxmurxy.mre.msdf.MsdfFont;
import java.awt.Color;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.session.Session;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Uuids;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import xyz.angames.dolphy.client.DiscordRpcManager;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.config.ThemeManager;
import xyz.angames.dolphy.client.gui.clickgui.ClickGuiIcons;
import xyz.angames.dolphy.client.gui.clickgui.GuiUtils;
import xyz.angames.dolphy.client.module.modules.render.InterfaceModule;
import xyz.angames.dolphy.client.util.DrawUtil;
import xyz.angames.dolphy.client.util.ModSounds;
import xyz.angames.dolphy.client.util.RandomNameGenerator;

@Environment(EnvType.CLIENT)
public class CustomMainMenuScreen extends Screen {
   private static final int BG_FRAME_COUNT = 16;
   private static final long BG_FRAME_DURATION_MS = 70L;
   private static final Identifier[] BG_FRAMES = new Identifier[BG_FRAME_COUNT];
   private static final Identifier[] BUTTON_ICONS = new Identifier[]{
      Identifier.of("dolphy", "textures/mainmenu/icon_singleplayer.png"),
      Identifier.of("dolphy", "textures/mainmenu/icon_multiplayer.png"),
      Identifier.of("dolphy", "textures/mainmenu/icon_altmanager.png"),
      Identifier.of("dolphy", "textures/mainmenu/icon_settings.png"),
      Identifier.of("dolphy", "textures/mainmenu/icon_exit.png")
   };
   private static final String[] BUTTON_LABELS = new String[]{
      "Singleplayer", "Multiplayer", "Alt Manager", "Settings", "Exit Game"
   };
   private static final String[] WALLPAPER_NAMES = new String[]{
      "Evening Sunset",
      "Cyberpunk Neon",
      "Sakura Night",
      "Aurora Borealis",
      "Crimson Eclipse",
      "Theme Cosmos"
   };
   private static final String[] THEME_LIST = new String[]{
      "iPhone Glass",
      "Dolphy Cyan",
      "Sakura Pink",
      "Cyber Violet",
      "Sunset Gold",
      "Emerald Mint",
      "Crimson Red",
      "Amethyst",
      "Chroma Wave",
      "Custom"
   };
   private static final String[] HUD_STYLE_LIST = new String[]{
      "iPhone Liquid Glass",
      "iPhone Frosted",
      "Theme Translucent",
      "Solid Dark"
   };
   private static final DateTimeFormatter CLOCK_FORMAT = DateTimeFormatter.ofPattern("HH:mm");
   private static final String[] RU_DAYS = new String[]{
      "понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"
   };
   private static final String[] RU_MONTHS = new String[]{
      "января", "февраля", "марта", "апреля", "мая", "июня",
      "июля", "августа", "сентября", "октября", "ноября", "декабря"
   };

   private static final List<String> savedAccounts = new ArrayList<>();
   private static int wallpaperIndex = -1;
   private static final float[][] animParticles = new float[56][5];

   private final float[] hoverAnims = new float[5];
   private final float[] buttonAppearAnims = new float[5];
   private float openAnim = 0.0F;
   private long lastFrameMs = 0L;

   private boolean altModalOpen = false;
   private float altModalAnim = 0.0F;
   private String altInputText = "";
   private boolean altInputFocused = true;
   private float loginBtnHover = 0.0F;
   private float randomBtnHover = 0.0F;
   private float closeBtnHover = 0.0F;

   private boolean themeModalOpen = false;
   private float themeModalAnim = 0.0F;
   private float themePillHover = 0.0F;
   private float wpPillHover = 0.0F;
   private float studioPillHover = 0.0F;
   private float themeModalCloseHover = 0.0F;

   static {
      for (int i = 0; i < BG_FRAME_COUNT; i++) {
         BG_FRAMES[i] = Identifier.of("dolphy", "textures/mainmenu/bg_" + i + ".png");
      }
      Random rng = new Random(1337L);
      for (int i = 0; i < animParticles.length; i++) {
         animParticles[i][0] = rng.nextFloat(); // x (0..1)
         animParticles[i][1] = rng.nextFloat(); // y (0..1)
         animParticles[i][2] = 0.15F + rng.nextFloat() * 0.85F; // speed
         animParticles[i][3] = 1.2F + rng.nextFloat() * 3.2F;   // size
         animParticles[i][4] = rng.nextFloat() * 6.28F;         // phase
      }
   }

   public CustomMainMenuScreen() {
      super(Text.literal("DolphyVisuals"));
      if (wallpaperIndex == -1) {
         loadMainMenuPrefs();
      }
   }

   private static void loadMainMenuPrefs() {
      wallpaperIndex = 0;
      try {
         Path p = Path.of(System.getProperty("user.home", "."), ".dolphy_mainmenu");
         if (Files.exists(p)) {
            List<String> lines = Files.readAllLines(p, StandardCharsets.UTF_8);
            if (!lines.isEmpty()) {
               int idx = Integer.parseInt(lines.get(0).trim());
               if (idx >= 0 && idx < WALLPAPER_NAMES.length) {
                  wallpaperIndex = idx;
               }
            }
            if (lines.size() > 1 && DolphyClient.moduleManager != null) {
               String savedTheme = lines.get(1).trim();
               if (DolphyClient.moduleManager.getModuleByName("Interface") instanceof InterfaceModule && !savedTheme.isEmpty()) {
                  InterfaceModule im = (InterfaceModule) DolphyClient.moduleManager.getModuleByName("Interface");
                  im.colorTheme.set(savedTheme);
               }
            }
         }
      } catch (Throwable ignored) {
      }
   }

   private static void saveMainMenuPrefs() {
      try {
         String themeName = getCurrentThemeName();
         Path p = Path.of(System.getProperty("user.home", "."), ".dolphy_mainmenu");
         Files.writeString(p, wallpaperIndex + "\n" + themeName + "\n", StandardCharsets.UTF_8);
      } catch (Throwable ignored) {
      }
   }

   private static InterfaceModule getInterfaceModule() {
      if (DolphyClient.moduleManager != null && DolphyClient.moduleManager.getModuleByName("Interface") instanceof InterfaceModule) {
         InterfaceModule im = (InterfaceModule) DolphyClient.moduleManager.getModuleByName("Interface");
         return im;
      }
      return null;
   }

   private static String getCurrentThemeName() {
      InterfaceModule im = getInterfaceModule();
      return im != null ? im.colorTheme.get() : "iPhone Glass";
   }

   private static void cycleTheme(int dir) {
      InterfaceModule im = getInterfaceModule();
      if (im == null) return;
      String cur = im.colorTheme.get();
      int idx = 0;
      for (int i = 0; i < THEME_LIST.length; i++) {
         if (THEME_LIST[i].equalsIgnoreCase(cur)) {
            idx = i;
            break;
         }
      }
      idx = (idx + dir + THEME_LIST.length) % THEME_LIST.length;
      im.colorTheme.set(THEME_LIST[idx]);
      saveMainMenuPrefs();
      if (DolphyClient.configManager != null) {
         DolphyClient.configManager.saveConfig("default");
      }
   }

   private static void cycleWallpaper(int dir) {
      wallpaperIndex = (wallpaperIndex + dir + WALLPAPER_NAMES.length) % WALLPAPER_NAMES.length;
      saveMainMenuPrefs();
   }

   @Override
   protected void init() {
      super.init();
      if (this.client != null && this.client.getSession() != null) {
         String currentName = this.client.getSession().getUsername();
         if (currentName != null && !currentName.isEmpty() && !savedAccounts.contains(currentName)) {
            savedAccounts.add(0, currentName);
         }
         if (this.altInputText.isEmpty() && currentName != null) {
            this.altInputText = currentName;
         }
      }
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   @Override
   public boolean shouldCloseOnEsc() {
      return false;
   }

   @Override
   public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
   }

   private static String getRussianDateString() {
      LocalDate now = LocalDate.now();
      DayOfWeek dow = now.getDayOfWeek();
      int dayIdx = Math.max(0, Math.min(6, dow.getValue() - 1));
      int monthIdx = Math.max(0, Math.min(11, now.getMonthValue() - 1));
      return RU_DAYS[dayIdx] + ", " + now.getDayOfMonth() + " " + RU_MONTHS[monthIdx];
   }

   private String getDisplayUsername() {
      if (this.client != null && this.client.getSession() != null) {
         String sessionName = this.client.getSession().getUsername();
         if (sessionName != null && !sessionName.trim().isEmpty()) {
            return sessionName;
         }
      }
      if (DiscordRpcManager.discordUsername != null
         && !DiscordRpcManager.discordUsername.trim().isEmpty()
         && !DiscordRpcManager.discordUsername.equals("Connecting...")) {
         return DiscordRpcManager.discordUsername;
      }
      return "Player";
   }

   private void renderAnimatedWallpaper(Matrix4f matrix, float scaledW, float scaledH, long now, Color themeColor, Color primaryColor, Color secondaryColor) {
      float t = (now % 3600000L) / 1000.0F;
      int frameIdx = (int)((now / BG_FRAME_DURATION_MS) % BG_FRAME_COUNT);
      Identifier bgIdent = BG_FRAMES[frameIdx];

      if (wallpaperIndex <= 2) {
         // Modes 0, 1, 2 use the animated GIF frames with distinct atmospheric grading & particle physics
         try {
            AbstractTexture bgTex = this.client.getTextureManager().getTexture(bgIdent);
            if (bgTex != null) {
               Color texTint = Color.WHITE;
               if (wallpaperIndex == 1) {
                  texTint = new Color(195, 145, 255); // Cyberpunk Neon
               } else if (wallpaperIndex == 2) {
                  texTint = new Color(255, 195, 225); // Sakura Night
               }
               Builder.texture()
                  .size(new SizeState(scaledW, scaledH))
                  .radius(new QuadRadiusState(0.0F))
                  .texture(0.0F, 0.0F, 1.0F, 1.0F, bgTex)
                  .color(new QuadColorState(texTint))
                  .build()
                  .render(matrix, 0.0F, 0.0F);
            }
         } catch (Exception ignored) {
         }

         if (wallpaperIndex == 0) {
            // Evening Sunset: warm dusk overlay + floating golden fireflies
            Builder.rectangle()
               .size(new SizeState(scaledW, scaledH))
               .radius(new QuadRadiusState(0.0F))
               .color(new QuadColorState(new Color(16, 12, 26, 62), new Color(10, 8, 18, 95), new Color(10, 8, 18, 95), new Color(16, 12, 26, 62)))
               .build()
               .render(matrix, 0.0F, 0.0F);

            for (int i = 0; i < 24; i++) {
               float[] p = animParticles[i];
               float px = ((p[0] + t * 0.012F * p[2]) % 1.0F) * scaledW;
               float py = ((p[1] - t * 0.018F * p[2] + 100.0F) % 1.0F) * scaledH;
               float pulse = MathHelper.clamp(0.5F + 0.5F * MathHelper.sin(t * 2.4F + p[4]), 0.0F, 1.0F);
               Color fc = new Color(255, 205, 125, MathHelper.clamp((int)(120.0F * pulse), 0, 255));
               Builder.rectangle()
                  .size(new SizeState(p[3], p[3]))
                  .radius(new QuadRadiusState(p[3] * 0.5F))
                  .color(new QuadColorState(fc))
                  .build()
                  .render(matrix, px, py);
            }
         } else if (wallpaperIndex == 1) {
            // Cyberpunk Neon: deep cyber violet/cyan overlay + diagonal neon rain streaks
            Builder.rectangle()
               .size(new SizeState(scaledW, scaledH))
               .radius(new QuadRadiusState(0.0F))
               .color(new QuadColorState(new Color(22, 8, 48, 115), new Color(8, 24, 52, 135), new Color(18, 6, 38, 135), new Color(36, 10, 68, 115)))
               .build()
               .render(matrix, 0.0F, 0.0F);

            for (int i = 0; i < 42; i++) {
               float[] p = animParticles[i];
               float px = ((p[0] - t * 0.08F * p[2] + 100.0F) % 1.0F) * scaledW;
               float py = ((p[1] + t * 0.38F * p[2]) % 1.0F) * scaledH;
               Color rc = (i % 2 == 0) ? new Color(0, 240, 255, 110) : new Color(255, 50, 190, 110);
               Builder.rectangle()
                  .size(new SizeState(1.1F, 9.0F + p[3] * 2.5F))
                  .radius(new QuadRadiusState(0.5F))
                  .color(new QuadColorState(rc))
                  .build()
                  .render(matrix, px, py);
            }
         } else {
            // Sakura Night: romantic rose twilight + swaying falling sakura petals
            Builder.rectangle()
               .size(new SizeState(scaledW, scaledH))
               .radius(new QuadRadiusState(0.0F))
               .color(new QuadColorState(new Color(38, 12, 32, 95), new Color(18, 8, 24, 120), new Color(24, 10, 28, 120), new Color(46, 16, 38, 95)))
               .build()
               .render(matrix, 0.0F, 0.0F);

            for (int i = 0; i < 45; i++) {
               float[] p = animParticles[i];
               float sway = MathHelper.sin(t * 1.8F + p[4]) * 14.0F;
               float px = ((p[0] + t * 0.025F * p[2]) % 1.0F) * scaledW + sway;
               float py = ((p[1] + t * 0.055F * p[2]) % 1.0F) * scaledH;
               float sz = 2.2F + p[3] * 0.75F;
               Color sc = new Color(255, 175 + (i % 4) * 15, 210, 185);
               Builder.rectangle()
                  .size(new SizeState(sz * 1.3F, sz * 0.85F))
                  .radius(new QuadRadiusState(sz * 0.4F))
                  .color(new QuadColorState(sc))
                  .build()
                  .render(matrix, px, py);
            }
         }
      } else if (wallpaperIndex == 3) {
         // Aurora Borealis: deep arctic night sky + waving northern lights curtains + stars
         Color skyTop = new Color(5, 9, 22);
         Color skyBot = new Color(10, 26, 42);
         Builder.rectangle()
            .size(new SizeState(scaledW, scaledH))
            .radius(new QuadRadiusState(0.0F))
            .color(new QuadColorState(skyTop, skyBot, skyBot, skyTop))
            .build()
            .render(matrix, 0.0F, 0.0F);

         int bands = 28;
         float bandW = scaledW / bands + 2.0F;
         for (int i = 0; i < bands; i++) {
            float nx = (float)i / bands;
            float wave1 = MathHelper.sin(nx * 5.5F + t * 0.9F) * 26.0F;
            float wave2 = MathHelper.cos(nx * 9.0F - t * 1.3F) * 14.0F;
            float ay = scaledH * 0.18F + wave1 + wave2;
            float ah = scaledH * 0.38F + MathHelper.sin(nx * 4.0F + t) * 24.0F;
            Color cTop = new Color(20, 235, 165, 0);
            Color cMid = new Color(35, 245, 185, 62);
            Color cBot = new Color(120, 75, 255, 0);
            Builder.rectangle()
               .size(new SizeState(bandW, ah * 0.5F))
               .radius(new QuadRadiusState(0.0F))
               .color(new QuadColorState(cTop, cMid, cMid, cTop))
               .build()
               .render(matrix, i * (scaledW / bands), ay);
            Builder.rectangle()
               .size(new SizeState(bandW, ah * 0.5F))
               .radius(new QuadRadiusState(0.0F))
               .color(new QuadColorState(cMid, cBot, cBot, cMid))
               .build()
               .render(matrix, i * (scaledW / bands), ay + ah * 0.5F);
         }

         for (int i = 0; i < animParticles.length; i++) {
            float[] p = animParticles[i];
            float tw = MathHelper.clamp(0.5F + 0.5F * MathHelper.sin(t * 2.8F * p[2] + p[4]), 0.0F, 1.0F);
            Builder.rectangle()
               .size(new SizeState(p[3] * 0.7F, p[3] * 0.7F))
               .radius(new QuadRadiusState(p[3] * 0.35F))
               .color(new QuadColorState(new Color(210, 255, 245, MathHelper.clamp((int)(175.0F * tw), 0, 255))))
               .build()
               .render(matrix, p[0] * scaledW, p[1] * scaledH);
         }
      } else if (wallpaperIndex == 4) {
         // Crimson Eclipse: dark obsidian crimson sky + glowing solar eclipse corona + rising embers
         Color top = new Color(12, 5, 10);
         Color bot = new Color(42, 8, 16);
         Builder.rectangle()
            .size(new SizeState(scaledW, scaledH))
            .radius(new QuadRadiusState(0.0F))
            .color(new QuadColorState(top, bot, bot, top))
            .build()
            .render(matrix, 0.0F, 0.0F);

         float sunR = 68.0F + MathHelper.sin(t * 1.5F) * 3.5F;
         float cx = scaledW * 0.5F;
         float cy = scaledH * 0.44F;
         GuiUtils.drawIconGlowShadow(matrix, cx, cy, sunR * 1.45F, new Color(255, 55, 45), 0.32F, 28.0F);
         Builder.border()
            .size(new SizeState(sunR * 2.0F, sunR * 2.0F))
            .radius(new QuadRadiusState(sunR))
            .thickness(2.4F)
            .smoothness(1.2F, 1.2F)
            .color(new QuadColorState(new Color(255, 115, 65, 210)))
            .build()
            .render(matrix, cx - sunR, cy - sunR);
         Builder.rectangle()
            .size(new SizeState(sunR * 1.92F, sunR * 1.92F))
            .radius(new QuadRadiusState(sunR * 0.96F))
            .color(new QuadColorState(new Color(8, 4, 8, 245)))
            .build()
            .render(matrix, cx - sunR * 0.96F, cy - sunR * 0.96F);

         for (int i = 0; i < 40; i++) {
            float[] p = animParticles[i];
            float px = ((p[0] + MathHelper.sin(t + p[4]) * 0.02F + 1.0F) % 1.0F) * scaledW;
            float py = ((p[1] - t * 0.065F * p[2] + 100.0F) % 1.0F) * scaledH;
            Color ec = new Color(255, 90 + (i % 5) * 25, 35, 185);
            Builder.rectangle()
               .size(new SizeState(p[3], p[3]))
               .radius(new QuadRadiusState(p[3] * 0.5F))
               .color(new QuadColorState(ec))
               .build()
               .render(matrix, px, py);
         }
      } else {
         // Theme Cosmos: dynamic animated wallpaper synced to the active client Theme
         Color top = new Color(
            Math.max(6, primaryColor.getRed() / 9),
            Math.max(6, primaryColor.getGreen() / 9),
            Math.max(12, primaryColor.getBlue() / 9)
         );
         Color bot = new Color(
            Math.max(12, secondaryColor.getRed() / 4),
            Math.max(10, secondaryColor.getGreen() / 4),
            Math.max(18, secondaryColor.getBlue() / 4)
         );
         Builder.rectangle()
            .size(new SizeState(scaledW, scaledH))
            .radius(new QuadRadiusState(0.0F))
            .color(new QuadColorState(top, bot, bot, top))
            .build()
            .render(matrix, 0.0F, 0.0F);

         GuiUtils.drawIconGlowShadow(
            matrix,
            scaledW * 0.3F + MathHelper.sin(t * 0.7F) * 35.0F,
            scaledH * 0.35F + MathHelper.cos(t * 0.5F) * 22.0F,
            110.0F,
            primaryColor,
            0.24F,
            32.0F
         );
         GuiUtils.drawIconGlowShadow(
            matrix,
            scaledW * 0.72F + MathHelper.cos(t * 0.6F) * 35.0F,
            scaledH * 0.65F + MathHelper.sin(t * 0.8F) * 22.0F,
            115.0F,
            secondaryColor,
            0.24F,
            32.0F
         );

         for (int i = 0; i < animParticles.length; i++) {
            float[] p = animParticles[i];
            float px = ((p[0] + t * 0.016F * p[2]) % 1.0F) * scaledW;
            float py = ((p[1] - t * 0.025F * p[2] + 100.0F) % 1.0F) * scaledH;
            Color pc = (i % 2 == 0) ? primaryColor : secondaryColor;
            float alpha = MathHelper.clamp(0.45F + 0.45F * MathHelper.sin(t * 2.0F + p[4]), 0.0F, 1.0F);
            Builder.rectangle()
               .size(new SizeState(p[3] * 1.2F, p[3] * 1.2F))
               .radius(new QuadRadiusState(p[3] * 0.6F))
               .color(new QuadColorState(GuiUtils.withAlpha(pc, alpha)))
               .build()
               .render(matrix, px, py);
         }
      }
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      if (this.client == null) {
         return;
      }

      long now = System.currentTimeMillis();
      if (this.lastFrameMs == 0L) {
         this.lastFrameMs = now;
      }
      float dt = MathHelper.clamp((float)(now - this.lastFrameMs) / 1000.0F, 0.001F, 0.1F);
      this.lastFrameMs = now;

      this.openAnim = GuiUtils.animate(this.openAnim, 1.0F, 9.5F, dt);
      this.altModalAnim = GuiUtils.animate(this.altModalAnim, this.altModalOpen ? 1.0F : 0.0F, 14.0F, dt);
      this.themeModalAnim = GuiUtils.animate(this.themeModalAnim, this.themeModalOpen ? 1.0F : 0.0F, 14.0F, dt);

      float sm = GuiUtils.getScaleModifier(this.client);
      float scaledW = this.width / sm;
      float scaledH = this.height / sm;
      float mxPos = mouseX / sm;
      float myPos = mouseY / sm;

      context.getMatrices().push();
      context.getMatrices().scale(sm, sm, 1.0F);
      Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();

      Color themeColor = new Color(ThemeManager.getThemedColor(now / 10L));
      Color primaryColor = ThemeManager.getPrimaryColor();
      Color secondaryColor = ThemeManager.getSecondaryColor();

      // 1. Render selected animated wallpaper
      this.renderAnimatedWallpaper(matrix, scaledW, scaledH, now, themeColor, primaryColor, secondaryColor);

      MsdfFont boldFont = ClickGuiIcons.BOLD_FONT.get();
      MsdfFont semiboldFont = ClickGuiIcons.SEMIBOLD_FONT.get();
      MsdfFont mediumFont = ClickGuiIcons.MEDIUM_FONT.get();
      MsdfFont regularFont = ClickGuiIcons.REGULAR_FONT.get();

      float contentAlpha = MathHelper.clamp(this.openAnim, 0.02F, 1.0F);
      float centerX = scaledW * 0.5F;
      float centerY = scaledH * 0.5F;
      float slideOffset = (1.0F - contentAlpha) * 12.0F;

      // 1.5 Top-Right Theme & Animated Wallpaper Quick Studio Bar
      this.renderTopRightThemeBar(matrix, scaledW, mxPos, myPos, dt, contentAlpha, boldFont, semiboldFont, themeColor);

      // 2. Large Clock (HH:mm) & Russian Date Subtitle
      String timeStr = LocalTime.now().format(CLOCK_FORMAT);
      String dateStr = getRussianDateString();
      float clockSize = 36.0F;
      float clockY = centerY - 106.0F + slideOffset;
      if (boldFont != null) {
         float clockW = boldFont.getWidth(timeStr, clockSize);
         float clockX = centerX - clockW * 0.5F;
         Builder.text()
            .font(boldFont)
            .text(timeStr)
            .size(clockSize)
            .color(new Color(0, 0, 0, (int)(95.0F * contentAlpha)))
            .build()
            .render(matrix, clockX + 0.8F, clockY + 1.4F);
         Builder.text()
            .font(boldFont)
            .text(timeStr)
            .size(clockSize)
            .color(GuiUtils.withAlpha(Color.WHITE, contentAlpha))
            .build()
            .render(matrix, clockX, clockY);
      }

      float dateSize = 8.5F;
      float dateY = clockY + 38.0F;
      MsdfFont dateFont = mediumFont != null ? mediumFont : semiboldFont;
      if (dateFont != null) {
         float dateW = dateFont.getWidth(dateStr, dateSize);
         float dateX = centerX - dateW * 0.5F;
         Builder.text()
            .font(dateFont)
            .text(dateStr)
            .size(dateSize)
            .color(new Color(0, 0, 0, (int)(80.0F * contentAlpha)))
            .build()
            .render(matrix, dateX + 0.5F, dateY + 0.8F);
         Builder.text()
            .font(dateFont)
            .text(dateStr)
            .size(dateSize)
            .color(new Color(228, 230, 240, (int)(220.0F * contentAlpha)))
            .build()
            .render(matrix, dateX, dateY);
      }

      // 3. Welcome Glass Card
      float cardW = 182.0F;
      float cardH = 44.0F;
      float cardRadius = 10.0F;
      float cardX = centerX - cardW * 0.5F;
      float cardY = dateY + 21.0F;

      for (int i = 6; i >= 0; i--) {
         float p = i / 6.0F;
         float sp = p * 6.0F;
         int sa = (int)(56.0F * (1.0F - p) * (1.0F - p) * contentAlpha);
         if (sa > 0) {
            Builder.rectangle()
               .size(new SizeState(cardW + sp * 2.0F, cardH + sp * 2.0F))
               .radius(new QuadRadiusState(cardRadius + sp))
               .color(new QuadColorState(new Color(0, 0, 0, sa)))
               .build()
               .render(matrix, cardX - sp, cardY - sp + 1.2F);
         }
      }

      Builder.blur()
         .size(new SizeState(cardW, cardH))
         .radius(new QuadRadiusState(cardRadius))
         .blurRadius(10.0F)
         .color(new QuadColorState(new Color(22, 20, 30, (int)(110.0F * contentAlpha))))
         .build()
         .render(matrix, cardX, cardY);

      Color cardTL = new Color(46, 42, 58, (int)(115.0F * contentAlpha));
      Color cardBL = new Color(28, 26, 38, (int)(130.0F * contentAlpha));
      Color cardBR = new Color(
         (themeColor.getRed() + 36 * 3) / 4,
         (themeColor.getGreen() + 32 * 3) / 4,
         (themeColor.getBlue() + 48 * 3) / 4,
         (int)(125.0F * contentAlpha)
      );
      Color cardTR = new Color(38, 34, 50, (int)(115.0F * contentAlpha));
      Builder.rectangle()
         .size(new SizeState(cardW, cardH))
         .radius(new QuadRadiusState(cardRadius))
         .color(new QuadColorState(cardTL, cardBL, cardBR, cardTR))
         .build()
         .render(matrix, cardX, cardY);

      Builder.border()
         .size(new SizeState(cardW, cardH))
         .radius(new QuadRadiusState(cardRadius))
         .thickness(0.65F)
         .smoothness(0.8F, 0.8F)
         .color(
            new QuadColorState(
               new Color(255, 255, 255, (int)(58.0F * contentAlpha)),
               new Color(255, 255, 255, (int)(20.0F * contentAlpha)),
               new Color(themeColor.getRed(), themeColor.getGreen(), themeColor.getBlue(), (int)(52.0F * contentAlpha)),
               new Color(255, 255, 255, (int)(28.0F * contentAlpha))
            )
         )
         .build()
         .render(matrix, cardX, cardY);

      float avSize = 31.0F;
      float avRadius = avSize * 0.5F;
      float avX = cardX + 9.0F;
      float avY = cardY + (cardH - avSize) * 0.5F;
      GuiUtils.drawIconGlowShadow(matrix, avX + avRadius, avY + avRadius, avRadius, themeColor, 0.14F * contentAlpha, 5.0F);
      DrawUtil.drawDolphyAvatar(matrix, avX, avY, avSize, avRadius, contentAlpha);
      Builder.border()
         .size(new SizeState(avSize, avSize))
         .radius(new QuadRadiusState(avRadius))
         .thickness(0.75F)
         .smoothness(0.8F, 0.8F)
         .color(new QuadColorState(GuiUtils.withAlpha(Color.WHITE, 0.45F * contentAlpha)))
         .build()
         .render(matrix, avX, avY);

      float textLeft = avX + avSize + 9.0F;
      if (dateFont != null) {
         Builder.text()
            .font(dateFont)
            .text("Добро пожаловать")
            .size(6.6F)
            .color(new Color(195, 198, 212, (int)(205.0F * contentAlpha)))
            .build()
            .render(matrix, textLeft, cardY + 7.5F);
      }

      String username = this.getDisplayUsername();
      if (boldFont != null) {
         Builder.text()
            .font(boldFont)
            .text(username)
            .size(9.6F)
            .color(GuiUtils.withAlpha(Color.WHITE, contentAlpha))
            .build()
            .render(matrix, textLeft, cardY + 16.5F);
      }

      float dotX = textLeft + 0.5F;
      float dotY = cardY + 31.2F;
      Color dotAccent = GuiUtils.withAlpha(themeColor, 0.95F * contentAlpha);
      Builder.border()
         .size(new SizeState(4.2F, 4.2F))
         .radius(new QuadRadiusState(2.1F))
         .thickness(0.8F)
         .smoothness(0.7F, 0.7F)
         .color(new QuadColorState(dotAccent))
         .build()
         .render(matrix, dotX, dotY);
      Builder.rectangle()
         .size(new SizeState(1.8F, 1.8F))
         .radius(new QuadRadiusState(0.9F))
         .color(new QuadColorState(dotAccent))
         .build()
         .render(matrix, dotX + 1.2F, dotY + 1.2F);

      if (dateFont != null) {
         Builder.text()
            .font(dateFont)
            .text("Клиент готов • 1.21.11")
            .size(6.5F)
            .color(new Color(205, 208, 220, (int)(210.0F * contentAlpha)))
            .build()
            .render(matrix, dotX + 6.8F, cardY + 29.5F);
      }

      // 4. Horizontal Row of 5 Action Buttons
      float slotW = 54.0F;
      float slotH = 38.0F;
      float slotGap = 9.0F;
      float totalRowW = BUTTON_LABELS.length * slotW + (BUTTON_LABELS.length - 1) * slotGap;
      float rowStartX = centerX - totalRowW * 0.5F;
      float rowBaseY = cardY + cardH + 34.0F;

      for (int i = 0; i < BUTTON_LABELS.length; i++) {
         this.buttonAppearAnims[i] = GuiUtils.animate(this.buttonAppearAnims[i], 1.0F, 7.5F + i * 1.2F, dt);
         float btnX = rowStartX + i * (slotW + slotGap);
         float staggerOffset = (1.0F - this.buttonAppearAnims[i]) * 14.0F;
         float btnY = rowBaseY + staggerOffset;

         boolean hovered = !this.altModalOpen
            && !this.themeModalOpen
            && mxPos >= btnX
            && mxPos <= btnX + slotW
            && myPos >= btnY - 4.0F
            && myPos <= btnY + slotH + 4.0F;
         this.hoverAnims[i] = GuiUtils.animate(this.hoverAnims[i], hovered ? 1.0F : 0.0F, 14.0F, dt);
         float hov = this.hoverAnims[i];
         float liftY = -4.5F * hov;
         float drawY = btnY + liftY;
         float btnAlpha = MathHelper.clamp(contentAlpha * this.buttonAppearAnims[i], 0.02F, 1.0F);

         float iconSize = 16.5F + 1.5F * hov;
         float iconX = btnX + (slotW - iconSize) * 0.5F;
         float iconY = drawY + 2.0F - 0.75F * hov;

         if (hov > 0.01F) {
            GuiUtils.drawIconGlowShadow(
               matrix,
               btnX + slotW * 0.5F,
               iconY + iconSize * 0.5F,
               iconSize * 0.65F,
               themeColor,
               0.22F * hov * btnAlpha,
               6.0F
            );
         }

         try {
            AbstractTexture iconTex = this.client.getTextureManager().getTexture(BUTTON_ICONS[i]);
            if (iconTex != null) {
               Color baseIconCol = new Color(242, 244, 250, (int)(235.0F * btnAlpha));
               Color hovIconCol = GuiUtils.withAlpha(Color.WHITE, btnAlpha);
               Color iconCol = GuiUtils.interpolateColor(baseIconCol, hovIconCol, hov);
               Builder.texture()
                  .size(new SizeState(iconSize, iconSize))
                  .radius(new QuadRadiusState(0.0F))
                  .texture(0.0F, 0.0F, 1.0F, 1.0F, iconTex)
                  .color(new QuadColorState(new Color(0, 0, 0, (int)(90.0F * btnAlpha))))
                  .build()
                  .render(matrix, iconX + 0.5F, iconY + 0.8F);
               Builder.texture()
                  .size(new SizeState(iconSize, iconSize))
                  .radius(new QuadRadiusState(0.0F))
                  .texture(0.0F, 0.0F, 1.0F, 1.0F, iconTex)
                  .color(new QuadColorState(iconCol))
                  .build()
                  .render(matrix, iconX, iconY);
            }
         } catch (Exception ignored) {
         }

         String label = BUTTON_LABELS[i];
         MsdfFont lblFont = semiboldFont != null ? semiboldFont : dateFont;
         if (lblFont != null) {
            float lblSize = 6.8F;
            float lblW = lblFont.getWidth(label, lblSize);
            float lblX = btnX + (slotW - lblW) * 0.5F;
            float lblY = drawY + 24.0F;
            Color baseTxtCol = new Color(228, 230, 240, (int)(215.0F * btnAlpha));
            Color hovTxtCol = new Color(255, 255, 255, (int)(255.0F * btnAlpha));
            Color txtCol = GuiUtils.interpolateColor(baseTxtCol, hovTxtCol, hov);
            Builder.text()
               .font(lblFont)
               .text(label)
               .size(lblSize)
               .color(new Color(0, 0, 0, (int)(95.0F * btnAlpha)))
               .build()
               .render(matrix, lblX + 0.4F, lblY + 0.7F);
            Builder.text()
               .font(lblFont)
               .text(label)
               .size(lblSize)
               .color(txtCol)
               .build()
               .render(matrix, lblX, lblY);
         }
      }

      // 5. Bottom-center branding
      String brandLeft = "DolphyVisuals";
      String brandRight = " • 1.21.11 Edition";
      float brandSize = 7.0F;
      MsdfFont rightFont = regularFont != null ? regularFont : dateFont;
      if (boldFont != null && rightFont != null) {
         float wLeft = boldFont.getWidth(brandLeft, brandSize);
         float wRight = rightFont.getWidth(brandRight, brandSize);
         float totalBrandW = wLeft + wRight;
         float brandX = centerX - totalBrandW * 0.5F;
         float brandY = scaledH - 14.5F;
         Builder.text()
            .font(boldFont)
            .text(brandLeft)
            .size(brandSize)
            .color(GuiUtils.withAlpha(Color.WHITE, 0.92F * contentAlpha))
            .build()
            .render(matrix, brandX, brandY);
         Builder.text()
            .font(rightFont)
            .text(brandRight)
            .size(brandSize)
            .color(new Color(185, 188, 202, (int)(195.0F * contentAlpha)))
            .build()
            .render(matrix, brandX + wLeft, brandY);
      }

      // 6. Optional Built-in Alt Manager Modal
      if (this.altModalAnim > 0.01F) {
         this.renderAltManagerModal(context, matrix, scaledW, scaledH, mxPos, myPos, dt, boldFont, semiboldFont, dateFont, themeColor, primaryColor, secondaryColor);
      }

      // 7. Theme & Animated Wallpaper Studio Modal
      if (this.themeModalAnim > 0.01F) {
         this.renderThemeStudioModal(context, matrix, scaledW, scaledH, mxPos, myPos, dt, boldFont, semiboldFont, dateFont, themeColor, primaryColor, secondaryColor);
      }

      context.getMatrices().pop();
   }

   private void renderTopRightThemeBar(
      Matrix4f matrix,
      float scaledW,
      float mxPos,
      float myPos,
      float dt,
      float contentAlpha,
      MsdfFont boldFont,
      MsdfFont semiboldFont,
      Color themeColor
   ) {
      float pillH = 18.0F;
      float topY = 10.0F;
      float rightEdge = scaledW - 10.0F;

      String studioTxt = "Темы и Обои";
      String wpTxt = "Обои: " + WALLPAPER_NAMES[wallpaperIndex];
      String thTxt = "Тема: " + getCurrentThemeName();

      float studioW = 68.0F;
      float wpW = 106.0F;
      float thW = 98.0F;

      float studioX = rightEdge - studioW;
      float wpX = studioX - 6.0F - wpW;
      float thX = wpX - 6.0F - thW;

      boolean modalBlocked = this.altModalOpen || this.themeModalOpen;
      boolean hovTh = !modalBlocked && mxPos >= thX && mxPos <= thX + thW && myPos >= topY && myPos <= topY + pillH;
      boolean hovWp = !modalBlocked && mxPos >= wpX && mxPos <= wpX + wpW && myPos >= topY && myPos <= topY + pillH;
      boolean hovSt = !modalBlocked && mxPos >= studioX && mxPos <= studioX + studioW && myPos >= topY && myPos <= topY + pillH;

      this.themePillHover = GuiUtils.animate(this.themePillHover, hovTh ? 1.0F : 0.0F, 14.0F, dt);
      this.wpPillHover = GuiUtils.animate(this.wpPillHover, hovWp ? 1.0F : 0.0F, 14.0F, dt);
      this.studioPillHover = GuiUtils.animate(this.studioPillHover, hovSt ? 1.0F : 0.0F, 14.0F, dt);

      DrawUtil.drawHudPill(matrix, thX, topY, thW, pillH, 6.0F, contentAlpha);
      DrawUtil.drawHudPill(matrix, wpX, topY, wpW, pillH, 6.0F, contentAlpha);

      Color stCol1 = GuiUtils.withAlpha(themeColor, (0.55F + 0.25F * this.studioPillHover) * contentAlpha);
      Color stCol2 = GuiUtils.withAlpha(ThemeManager.getSecondaryColor(), (0.55F + 0.25F * this.studioPillHover) * contentAlpha);
      Builder.rectangle()
         .size(new SizeState(studioW, pillH))
         .radius(new QuadRadiusState(6.0F))
         .color(new QuadColorState(stCol1, stCol1, stCol2, stCol2))
         .build()
         .render(matrix, studioX, topY);
      Builder.border()
         .size(new SizeState(studioW, pillH))
         .radius(new QuadRadiusState(6.0F))
         .thickness(0.65F)
         .smoothness(0.8F, 0.8F)
         .color(new QuadColorState(GuiUtils.withAlpha(Color.WHITE, 0.45F * contentAlpha)))
         .build()
         .render(matrix, studioX, topY);

      if (semiboldFont != null) {
         float tw1 = semiboldFont.getWidth(thTxt, 6.5F);
         Builder.text()
            .font(semiboldFont)
            .text(thTxt)
            .size(6.5F)
            .color(GuiUtils.withAlpha(Color.WHITE, contentAlpha))
            .build()
            .render(matrix, thX + (thW - tw1) * 0.5F, topY + 5.2F);

         float tw2 = semiboldFont.getWidth(wpTxt, 6.5F);
         Builder.text()
            .font(semiboldFont)
            .text(wpTxt)
            .size(6.5F)
            .color(GuiUtils.withAlpha(Color.WHITE, contentAlpha))
            .build()
            .render(matrix, wpX + (wpW - tw2) * 0.5F, topY + 5.2F);

         float tw3 = semiboldFont.getWidth(studioTxt, 6.6F);
         Builder.text()
            .font(semiboldFont)
            .text(studioTxt)
            .size(6.6F)
            .color(GuiUtils.withAlpha(Color.WHITE, contentAlpha))
            .build()
            .render(matrix, studioX + (studioW - tw3) * 0.5F, topY + 5.2F);
      }
   }

   private void renderThemeStudioModal(
      DrawContext context,
      Matrix4f matrix,
      float scaledW,
      float scaledH,
      float mxPos,
      float myPos,
      float dt,
      MsdfFont boldFont,
      MsdfFont semiboldFont,
      MsdfFont mediumFont,
      Color themeColor,
      Color primaryColor,
      Color secondaryColor
   ) {
      float a = MathHelper.clamp(this.themeModalAnim, 0.01F, 1.0F);
      Builder.rectangle()
         .size(new SizeState(scaledW, scaledH))
         .radius(new QuadRadiusState(0.0F))
         .color(new QuadColorState(new Color(0, 0, 0, (int)(145.0F * a))))
         .build()
         .render(matrix, 0.0F, 0.0F);

      float modalW = 296.0F;
      float modalH = 208.0F;
      float modalX = (scaledW - modalW) * 0.5F;
      float modalY = (scaledH - modalH) * 0.5F;

      context.getMatrices().push();
      float scale = 0.92F + 0.08F * a;
      if (scale < 0.999F) {
         float cx = modalX + modalW * 0.5F;
         float cy = modalY + modalH * 0.5F;
         context.getMatrices().translate(cx, cy, 0.0F);
         context.getMatrices().scale(scale, scale, 1.0F);
         context.getMatrices().translate(-cx, -cy, 0.0F);
      }
      Matrix4f mMat = context.getMatrices().peek().getPositionMatrix();

      DrawUtil.drawHudBackground(mMat, modalX, modalY, modalW, modalH, 12.0F, a);

      if (boldFont != null) {
         Builder.text()
            .font(boldFont)
            .text("Настройки тем и анимированных обоев")
            .size(9.2F)
            .color(GuiUtils.withAlpha(Color.WHITE, a))
            .build()
            .render(mMat, modalX + 12.0F, modalY + 11.0F);
      }

      float closeX = modalX + modalW - 22.0F;
      float closeY = modalY + 9.0F;
      boolean closeHov = mxPos >= closeX && mxPos <= closeX + 14.0F && myPos >= closeY && myPos <= closeY + 14.0F;
      this.themeModalCloseHover = GuiUtils.animate(this.themeModalCloseHover, closeHov ? 1.0F : 0.0F, 14.0F, dt);
      DrawUtil.drawHudPill(mMat, closeX, closeY, 14.0F, 14.0F, 4.5F, a);
      if (boldFont != null) {
         float xw = boldFont.getWidth("x", 7.5F);
         Builder.text()
            .font(boldFont)
            .text("x")
            .size(7.5F)
            .color(GuiUtils.interpolateColor(new Color(200, 205, 220, (int)(220 * a)), new Color(255, 100, 100, (int)(255 * a)), this.themeModalCloseHover))
            .build()
            .render(mMat, closeX + (14.0F - xw) * 0.5F, closeY + 2.2F);
      }

      // Section 1: Color Themes (2 rows of 5)
      if (mediumFont != null) {
         Builder.text()
            .font(mediumFont)
            .text("Цветовая тема клиента:")
            .size(7.0F)
            .color(new Color(195, 200, 218, (int)(220 * a)))
            .build()
            .render(mMat, modalX + 12.0F, modalY + 29.0F);
      }

      String activeTheme = getCurrentThemeName();
      float cellW = (modalW - 24.0F - 4 * 5.0F) / 5.0F;
      float cellH = 19.0F;
      for (int i = 0; i < THEME_LIST.length; i++) {
         int col = i % 5;
         int row = i / 5;
         float cx = modalX + 12.0F + col * (cellW + 5.0F);
         float cy = modalY + 40.0F + row * (cellH + 5.0F);
         boolean selected = THEME_LIST[i].equalsIgnoreCase(activeTheme);
         DrawUtil.drawHudPill(mMat, cx, cy, cellW, cellH, 5.0F, a);
         if (selected) {
            Builder.border()
               .size(new SizeState(cellW, cellH))
               .radius(new QuadRadiusState(5.0F))
               .thickness(0.85F)
               .smoothness(0.8F, 0.8F)
               .color(new QuadColorState(GuiUtils.withAlpha(themeColor, 0.95F * a)))
               .build()
               .render(mMat, cx, cy);
         }
         if (semiboldFont != null) {
            float tw = semiboldFont.getWidth(THEME_LIST[i], 6.0F);
            Builder.text()
               .font(semiboldFont)
               .text(THEME_LIST[i])
               .size(6.0F)
               .color(selected ? GuiUtils.withAlpha(themeColor, a) : GuiUtils.withAlpha(Color.WHITE, 0.88F * a))
               .build()
               .render(mMat, cx + (cellW - tw) * 0.5F, cy + 5.8F);
         }
      }

      // Section 2: Animated Wallpapers (2 rows of 3)
      if (mediumFont != null) {
         Builder.text()
            .font(mediumFont)
            .text("Анимированные обои главного меню:")
            .size(7.0F)
            .color(new Color(195, 200, 218, (int)(220 * a)))
            .build()
            .render(mMat, modalX + 12.0F, modalY + 91.0F);
      }

      float wpCellW = (modalW - 24.0F - 2 * 6.0F) / 3.0F;
      float wpCellH = 21.0F;
      for (int i = 0; i < WALLPAPER_NAMES.length; i++) {
         int col = i % 3;
         int row = i / 3;
         float cx = modalX + 12.0F + col * (wpCellW + 6.0F);
         float cy = modalY + 102.0F + row * (wpCellH + 5.0F);
         boolean selected = (i == wallpaperIndex);
         DrawUtil.drawHudPill(mMat, cx, cy, wpCellW, wpCellH, 5.5F, a);
         if (selected) {
            Builder.border()
               .size(new SizeState(wpCellW, wpCellH))
               .radius(new QuadRadiusState(5.5F))
               .thickness(0.9F)
               .smoothness(0.8F, 0.8F)
               .color(new QuadColorState(GuiUtils.withAlpha(themeColor, 0.95F * a)))
               .build()
               .render(mMat, cx, cy);
         }
         if (semiboldFont != null) {
            float tw = semiboldFont.getWidth(WALLPAPER_NAMES[i], 6.5F);
            Builder.text()
               .font(semiboldFont)
               .text(WALLPAPER_NAMES[i])
               .size(6.5F)
               .color(selected ? GuiUtils.withAlpha(themeColor, a) : GuiUtils.withAlpha(Color.WHITE, 0.9F * a))
               .build()
               .render(mMat, cx + (wpCellW - tw) * 0.5F, cy + 6.5F);
         }
      }

      // Section 3: HUD Style row (4 options)
      if (mediumFont != null) {
         Builder.text()
            .font(mediumFont)
            .text("Стиль прозрачности HUD:")
            .size(7.0F)
            .color(new Color(195, 200, 218, (int)(220 * a)))
            .build()
            .render(mMat, modalX + 12.0F, modalY + 157.0F);
      }

      InterfaceModule im = getInterfaceModule();
      String activeStyle = im != null ? im.hudStyle.get() : "iPhone Liquid Glass";
      float stCellW = (modalW - 24.0F - 3 * 5.0F) / 4.0F;
      float stCellH = 20.0F;
      for (int i = 0; i < HUD_STYLE_LIST.length; i++) {
         float cx = modalX + 12.0F + i * (stCellW + 5.0F);
         float cy = modalY + 169.0F;
         boolean selected = HUD_STYLE_LIST[i].equalsIgnoreCase(activeStyle);
         DrawUtil.drawHudPill(mMat, cx, cy, stCellW, stCellH, 5.0F, a);
         if (selected) {
            Builder.border()
               .size(new SizeState(stCellW, stCellH))
               .radius(new QuadRadiusState(5.0F))
               .thickness(0.85F)
               .smoothness(0.8F, 0.8F)
               .color(new QuadColorState(GuiUtils.withAlpha(themeColor, 0.95F * a)))
               .build()
               .render(mMat, cx, cy);
         }
         if (semiboldFont != null) {
            float tw = semiboldFont.getWidth(HUD_STYLE_LIST[i], 5.6F);
            Builder.text()
               .font(semiboldFont)
               .text(HUD_STYLE_LIST[i])
               .size(5.6F)
               .color(selected ? GuiUtils.withAlpha(themeColor, a) : GuiUtils.withAlpha(Color.WHITE, 0.88F * a))
               .build()
               .render(mMat, cx + (stCellW - tw) * 0.5F, cy + 6.5F);
         }
      }

      context.getMatrices().pop();
   }

   private void renderAltManagerModal(
      DrawContext context,
      Matrix4f matrix,
      float scaledW,
      float scaledH,
      float mxPos,
      float myPos,
      float dt,
      MsdfFont boldFont,
      MsdfFont semiboldFont,
      MsdfFont mediumFont,
      Color themeColor,
      Color primaryColor,
      Color secondaryColor
   ) {
      float a = MathHelper.clamp(this.altModalAnim, 0.01F, 1.0F);
      Builder.rectangle()
         .size(new SizeState(scaledW, scaledH))
         .radius(new QuadRadiusState(0.0F))
         .color(new QuadColorState(new Color(0, 0, 0, (int)(135.0F * a))))
         .build()
         .render(matrix, 0.0F, 0.0F);

      float modalW = 220.0F;
      float modalH = 162.0F;
      float modalX = (scaledW - modalW) * 0.5F;
      float modalY = (scaledH - modalH) * 0.5F;

      context.getMatrices().push();
      float scale = 0.92F + 0.08F * a;
      if (scale < 0.999F) {
         float cx = modalX + modalW * 0.5F;
         float cy = modalY + modalH * 0.5F;
         context.getMatrices().translate(cx, cy, 0.0F);
         context.getMatrices().scale(scale, scale, 1.0F);
         context.getMatrices().translate(-cx, -cy, 0.0F);
      }
      Matrix4f mMat = context.getMatrices().peek().getPositionMatrix();

      DrawUtil.drawHudBackground(mMat, modalX, modalY, modalW, modalH, 11.0F, a);

      if (boldFont != null) {
         Builder.text()
            .font(boldFont)
            .text("Alt Manager")
            .size(10.0F)
            .color(GuiUtils.withAlpha(Color.WHITE, a))
            .build()
            .render(mMat, modalX + 12.0F, modalY + 11.0F);
      }

      float closeX = modalX + modalW - 22.0F;
      float closeY = modalY + 9.0F;
      boolean closeHov = mxPos >= closeX && mxPos <= closeX + 14.0F && myPos >= closeY && myPos <= closeY + 14.0F;
      this.closeBtnHover = GuiUtils.animate(this.closeBtnHover, closeHov ? 1.0F : 0.0F, 14.0F, dt);
      DrawUtil.drawHudPill(mMat, closeX, closeY, 14.0F, 14.0F, 4.5F, a);
      if (boldFont != null) {
         float xw = boldFont.getWidth("x", 7.5F);
         Builder.text()
            .font(boldFont)
            .text("x")
            .size(7.5F)
            .color(GuiUtils.interpolateColor(new Color(200, 205, 220, (int)(220 * a)), new Color(255, 100, 100, (int)(255 * a)), this.closeBtnHover))
            .build()
            .render(mMat, closeX + (14.0F - xw) * 0.5F, closeY + 2.2F);
      }

      float inX = modalX + 12.0F;
      float inY = modalY + 30.0F;
      float inW = modalW - 24.0F;
      float inH = 22.0F;
      DrawUtil.drawHudPill(mMat, inX, inY, inW, inH, 6.0F, a);
      if (this.altInputFocused) {
         Builder.border()
            .size(new SizeState(inW, inH))
            .radius(new QuadRadiusState(6.0F))
            .thickness(0.75F)
            .smoothness(0.8F, 0.8F)
            .color(new QuadColorState(GuiUtils.withAlpha(themeColor, 0.85F * a)))
            .build()
            .render(mMat, inX, inY);
      }

      String cursor = this.altInputFocused && (System.currentTimeMillis() / 500L) % 2L == 0L ? "|" : "";
      String shown = (this.altInputText.isEmpty() && !this.altInputFocused) ? "Введите никнейм..." : (this.altInputText + cursor);
      Color inCol = (this.altInputText.isEmpty() && !this.altInputFocused)
         ? new Color(160, 165, 180, (int)(180 * a))
         : GuiUtils.withAlpha(Color.WHITE, a);
      if (semiboldFont != null) {
         Builder.text()
            .font(semiboldFont)
            .text(shown)
            .size(8.0F)
            .color(inCol)
            .build()
            .render(mMat, inX + 8.0F, inY + 6.5F);
      }

      float btnY = inY + inH + 7.0F;
      float btnW = (inW - 6.0F) * 0.5F;
      float btnH = 20.0F;
      float loginX = inX;
      float randX = inX + btnW + 6.0F;

      boolean loginHov = mxPos >= loginX && mxPos <= loginX + btnW && myPos >= btnY && myPos <= btnY + btnH;
      boolean randHov = mxPos >= randX && mxPos <= randX + btnW && myPos >= btnY && myPos <= btnY + btnH;
      this.loginBtnHover = GuiUtils.animate(this.loginBtnHover, loginHov ? 1.0F : 0.0F, 14.0F, dt);
      this.randomBtnHover = GuiUtils.animate(this.randomBtnHover, randHov ? 1.0F : 0.0F, 14.0F, dt);

      Color loginBg1 = new Color(primaryColor.getRed(), primaryColor.getGreen(), primaryColor.getBlue(), (int)((150 + 55 * this.loginBtnHover) * a));
      Color loginBg2 = new Color(secondaryColor.getRed(), secondaryColor.getGreen(), secondaryColor.getBlue(), (int)((150 + 55 * this.loginBtnHover) * a));
      Builder.rectangle()
         .size(new SizeState(btnW, btnH))
         .radius(new QuadRadiusState(5.5F))
         .color(new QuadColorState(loginBg1, loginBg1, loginBg2, loginBg2))
         .build()
         .render(mMat, loginX, btnY);

      DrawUtil.drawHudPill(mMat, randX, btnY, btnW, btnH, 5.5F, a);

      if (semiboldFont != null) {
         String lTxt = "Сменить ник";
         float lw = semiboldFont.getWidth(lTxt, 7.5F);
         Builder.text()
            .font(semiboldFont)
            .text(lTxt)
            .size(7.5F)
            .color(GuiUtils.withAlpha(Color.WHITE, a))
            .build()
            .render(mMat, loginX + (btnW - lw) * 0.5F, btnY + 5.8F);

         String rTxt = "Рандомный";
         float rw = semiboldFont.getWidth(rTxt, 7.5F);
         Builder.text()
            .font(semiboldFont)
            .text(rTxt)
            .size(7.5F)
            .color(GuiUtils.withAlpha(Color.WHITE, a))
            .build()
            .render(mMat, randX + (btnW - rw) * 0.5F, btnY + 5.8F);
      }

      float listY = btnY + btnH + 9.0F;
      if (mediumFont != null) {
         Builder.text()
            .font(mediumFont)
            .text("Сохранённые аккаунты:")
            .size(6.8F)
            .color(new Color(190, 195, 210, (int)(200 * a)))
            .build()
            .render(mMat, inX, listY);
      }

      float itemY = listY + 11.0F;
      int maxItems = Math.min(3, savedAccounts.size());
      String activeUser = this.getDisplayUsername();
      for (int i = 0; i < maxItems; i++) {
         String acc = savedAccounts.get(i);
         float rowH = 17.0F;
         DrawUtil.drawHudPill(mMat, inX, itemY, inW, rowH, 4.5F, a);
         boolean isCurrent = acc.equalsIgnoreCase(activeUser);
         if (isCurrent) {
            Builder.border()
               .size(new SizeState(inW, rowH))
               .radius(new QuadRadiusState(4.5F))
               .thickness(0.65F)
               .smoothness(0.8F, 0.8F)
               .color(new QuadColorState(GuiUtils.withAlpha(themeColor, 0.75F * a)))
               .build()
               .render(mMat, inX, itemY);
         }
         if (semiboldFont != null) {
            Builder.text()
               .font(semiboldFont)
               .text(acc)
               .size(7.2F)
               .color(isCurrent ? GuiUtils.withAlpha(themeColor, a) : GuiUtils.withAlpha(Color.WHITE, 0.9F * a))
               .build()
               .render(mMat, inX + 7.0F, itemY + 4.5F);
         }
         itemY += rowH + 3.5F;
      }

      context.getMatrices().pop();
   }

   private void applyOfflineUsername(String username) {
      if (username == null) {
         return;
      }
      String clean = username.trim();
      if (clean.length() < 3) {
         return;
      }
      if (clean.length() > 16) {
         clean = clean.substring(0, 16);
      }
      try {
         Session newSession = new Session(
            clean,
            Uuids.getOfflinePlayerUuid(clean),
            "",
            Optional.empty(),
            Optional.empty(),
            Session.AccountType.MOJANG
         );
         for (Field field : MinecraftClient.class.getDeclaredFields()) {
            if (field.getType() == Session.class) {
               field.setAccessible(true);
               field.set(this.client, newSession);
               break;
            }
         }
         savedAccounts.remove(clean);
         savedAccounts.add(0, clean);
         this.altInputText = clean;
         ModSounds.playEnable();
      } catch (Throwable t) {
         t.printStackTrace();
      }
   }

   private boolean tryOpenExternalIAS() {
      try {
         Class<?> iasScreenClass = Class.forName("ru.vidtu.ias.screen.AccountScreen");
         Constructor<?> ctor = iasScreenClass.getConstructor(Screen.class);
         Screen iasScreen = (Screen)ctor.newInstance(this);
         if (this.client != null) {
            this.client.setScreen(iasScreen);
            return true;
         }
      } catch (Throwable ignored) {
      }
      return false;
   }

   @Override
   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (this.client == null) {
         return super.mouseClicked(mouseX, mouseY, button);
      }

      float sm = GuiUtils.getScaleModifier(this.client);
      float scaledW = this.width / sm;
      float scaledH = this.height / sm;
      float mxPos = (float)(mouseX / sm);
      float myPos = (float)(mouseY / sm);

      if (this.themeModalOpen) {
         float modalW = 296.0F;
         float modalH = 208.0F;
         float modalX = (scaledW - modalW) * 0.5F;
         float modalY = (scaledH - modalH) * 0.5F;
         float closeX = modalX + modalW - 22.0F;
         float closeY = modalY + 9.0F;

         if ((mxPos >= closeX && mxPos <= closeX + 14.0F && myPos >= closeY && myPos <= closeY + 14.0F)
            || mxPos < modalX || mxPos > modalX + modalW || myPos < modalY || myPos > modalY + modalH) {
            this.themeModalOpen = false;
            ModSounds.playDisable();
            return true;
         }

         InterfaceModule im = getInterfaceModule();
         float cellW = (modalW - 24.0F - 4 * 5.0F) / 5.0F;
         float cellH = 19.0F;
         for (int i = 0; i < THEME_LIST.length; i++) {
            int col = i % 5;
            int row = i / 5;
            float cx = modalX + 12.0F + col * (cellW + 5.0F);
            float cy = modalY + 40.0F + row * (cellH + 5.0F);
            if (mxPos >= cx && mxPos <= cx + cellW && myPos >= cy && myPos <= cy + cellH) {
               if (im != null) {
                  im.colorTheme.set(THEME_LIST[i]);
                  saveMainMenuPrefs();
                  if (DolphyClient.configManager != null) DolphyClient.configManager.saveConfig("default");
               }
               ModSounds.playModuleSelect();
               return true;
            }
         }

         float wpCellW = (modalW - 24.0F - 2 * 6.0F) / 3.0F;
         float wpCellH = 21.0F;
         for (int i = 0; i < WALLPAPER_NAMES.length; i++) {
            int col = i % 3;
            int row = i / 3;
            float cx = modalX + 12.0F + col * (wpCellW + 6.0F);
            float cy = modalY + 102.0F + row * (wpCellH + 5.0F);
            if (mxPos >= cx && mxPos <= cx + wpCellW && myPos >= cy && myPos <= cy + wpCellH) {
               wallpaperIndex = i;
               saveMainMenuPrefs();
               ModSounds.playModuleSelect();
               return true;
            }
         }

         float stCellW = (modalW - 24.0F - 3 * 5.0F) / 4.0F;
         float stCellH = 20.0F;
         for (int i = 0; i < HUD_STYLE_LIST.length; i++) {
            float cx = modalX + 12.0F + i * (stCellW + 5.0F);
            float cy = modalY + 169.0F;
            if (mxPos >= cx && mxPos <= cx + stCellW && myPos >= cy && myPos <= cy + stCellH) {
               if (im != null) {
                  im.hudStyle.set(HUD_STYLE_LIST[i]);
                  if (DolphyClient.configManager != null) DolphyClient.configManager.saveConfig("default");
               }
               ModSounds.playModuleSelect();
               return true;
            }
         }

         return true;
      }

      if (this.altModalOpen) {
         float modalW = 220.0F;
         float modalH = 162.0F;
         float modalX = (scaledW - modalW) * 0.5F;
         float modalY = (scaledH - modalH) * 0.5F;

         float closeX = modalX + modalW - 22.0F;
         float closeY = modalY + 9.0F;
         if ((mxPos >= closeX && mxPos <= closeX + 14.0F && myPos >= closeY && myPos <= closeY + 14.0F)
            || mxPos < modalX || mxPos > modalX + modalW || myPos < modalY || myPos > modalY + modalH) {
            this.altModalOpen = false;
            ModSounds.playDisable();
            return true;
         }

         float inX = modalX + 12.0F;
         float inY = modalY + 30.0F;
         float inW = modalW - 24.0F;
         float inH = 22.0F;
         this.altInputFocused = mxPos >= inX && mxPos <= inX + inW && myPos >= inY && myPos <= inY + inH;

         float btnY = inY + inH + 7.0F;
         float btnW = (inW - 6.0F) * 0.5F;
         float btnH = 20.0F;
         float loginX = inX;
         float randX = inX + btnW + 6.0F;

         if (mxPos >= loginX && mxPos <= loginX + btnW && myPos >= btnY && myPos <= btnY + btnH) {
            this.applyOfflineUsername(this.altInputText);
            return true;
         }

         if (mxPos >= randX && mxPos <= randX + btnW && myPos >= btnY && myPos <= btnY + btnH) {
            String randName = RandomNameGenerator.generateUniqueName();
            this.applyOfflineUsername(randName);
            return true;
         }

         float itemY = btnY + btnH + 20.0F;
         int maxItems = Math.min(3, savedAccounts.size());
         for (int i = 0; i < maxItems; i++) {
            float rowH = 17.0F;
            if (mxPos >= inX && mxPos <= inX + inW && myPos >= itemY && myPos <= itemY + rowH) {
               this.applyOfflineUsername(savedAccounts.get(i));
               return true;
            }
            itemY += rowH + 3.5F;
         }

         return true;
      }

      // Check Top-Right Studio Bar clicks
      float pillH = 18.0F;
      float topY = 10.0F;
      float rightEdge = scaledW - 10.0F;
      float studioW = 68.0F;
      float wpW = 106.0F;
      float thW = 98.0F;
      float studioX = rightEdge - studioW;
      float wpX = studioX - 6.0F - wpW;
      float thX = wpX - 6.0F - thW;

      if (myPos >= topY && myPos <= topY + pillH) {
         int dir = (button == 1) ? -1 : 1;
         if (mxPos >= thX && mxPos <= thX + thW) {
            cycleTheme(dir);
            ModSounds.playModuleSelect();
            return true;
         }
         if (mxPos >= wpX && mxPos <= wpX + wpW) {
            cycleWallpaper(dir);
            ModSounds.playModuleSelect();
            return true;
         }
         if (mxPos >= studioX && mxPos <= studioX + studioW) {
            this.themeModalOpen = true;
            ModSounds.playEnable();
            return true;
         }
      }

      if (button != 0) {
         return super.mouseClicked(mouseX, mouseY, button);
      }

      float centerX = scaledW * 0.5F;
      float centerY = scaledH * 0.5F;
      float clockY = centerY - 106.0F;
      float dateY = clockY + 38.0F;
      float cardY = dateY + 21.0F;
      float cardH = 44.0F;

      float slotW = 54.0F;
      float slotH = 38.0F;
      float slotGap = 9.0F;
      float totalRowW = BUTTON_LABELS.length * slotW + (BUTTON_LABELS.length - 1) * slotGap;
      float rowStartX = centerX - totalRowW * 0.5F;
      float rowBaseY = cardY + cardH + 34.0F;

      for (int i = 0; i < BUTTON_LABELS.length; i++) {
         float btnX = rowStartX + i * (slotW + slotGap);
         if (mxPos >= btnX && mxPos <= btnX + slotW && myPos >= rowBaseY - 6.0F && myPos <= rowBaseY + slotH + 6.0F) {
            ModSounds.playModuleSelect();
            switch (i) {
               case 0: this.client.setScreen(new SelectWorldScreen(this)); break;
               case 1: this.client.setScreen(new MultiplayerScreen(this)); break;
               case 2:
                  if (!this.tryOpenExternalIAS()) {
                     this.altModalOpen = true;
                     this.altInputFocused = true;
                  }
                  break;
               case 3: this.client.setScreen(new OptionsScreen(this, this.client.options)); break;
               case 4: this.client.scheduleStop(); break;
            }
            return true;
         }
      }

      return super.mouseClicked(mouseX, mouseY, button);
   }

   @Override
   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      if (this.themeModalOpen) {
         if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            this.themeModalOpen = false;
            return true;
         }
         return true;
      }
      if (this.altModalOpen) {
         if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            this.altModalOpen = false;
            return true;
         }
         if (this.altInputFocused) {
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
               this.applyOfflineUsername(this.altInputText);
               return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !this.altInputText.isEmpty()) {
               this.altInputText = this.altInputText.substring(0, this.altInputText.length() - 1);
               return true;
            }
         }
         return true;
      }
      return super.keyPressed(keyCode, scanCode, modifiers);
   }

   @Override
   public boolean charTyped(char chr, int modifiers) {
      if (this.altModalOpen && this.altInputFocused) {
         if (this.altInputText.length() < 16 && (Character.isLetterOrDigit(chr) || chr == '_')) {
            this.altInputText = this.altInputText + chr;
            return true;
         }
      }
      return super.charTyped(chr, modifiers);
   }
}
