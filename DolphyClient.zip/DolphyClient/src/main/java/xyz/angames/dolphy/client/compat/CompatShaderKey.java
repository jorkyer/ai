package xyz.angames.dolphy.client.compat;

import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.class_10149;
import net.minecraft.class_2960;

public class CompatShaderKey {
    public static final CompatShaderKey field_53992 = new CompatShaderKey("position");
    public static final CompatShaderKey field_53993 = new CompatShaderKey("position_color");
    public static final CompatShaderKey field_53995 = new CompatShaderKey("position_tex");
    public static final CompatShaderKey field_53996 = new CompatShaderKey("position_tex_color");
    public static final CompatShaderKey field_54002 = new CompatShaderKey("rendertype_lines");

    public static final CompatShaderKey field_53876 = field_53993;
    public static final CompatShaderKey field_53880 = field_53996;

    public final String id;

    public CompatShaderKey(String id) {
        this.id = id;
    }

    public CompatShaderKey(class_2960 id, VertexFormat format, class_10149 defines) {
        this.id = id != null ? id.toString() : "position_color";
    }

    public static CompatShaderKey register(String name, VertexFormat format) {
        return new CompatShaderKey(name);
    }

    public static CompatShaderKey register(String name, VertexFormat format, class_10149 defines) {
        return new CompatShaderKey(name);
    }

    @Override
    public String toString() {
        return id;
    }
}
