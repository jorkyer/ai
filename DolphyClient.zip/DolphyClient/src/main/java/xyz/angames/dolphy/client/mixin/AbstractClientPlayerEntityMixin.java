package xyz.angames.dolphy.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.angames.dolphy.client.module.modules.render.CapeModule;
import xyz.angames.dolphy.client.util.FriendManager;

@Environment(EnvType.CLIENT)
@Mixin(AbstractClientPlayerEntity.class)
public class AbstractClientPlayerEntityMixin {
   private static final Identifier DEFAULT_CAPE = Identifier.of("dolphy", "textures/dolphy_cape.png");

   @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
   private void onGetSkinTextures(CallbackInfoReturnable<SkinTextures> cir) {
      CapeModule capeMod = CapeModule.INSTANCE;
      if (capeMod != null && !capeMod.isEnabled()) {
         return;
      }

      AbstractClientPlayerEntity player = (AbstractClientPlayerEntity)(Object)this;
      MinecraftClient mc = MinecraftClient.getInstance();
      boolean isSelf = mc.player != null && player.getUuid().equals(mc.player.getUuid());
      boolean isFriend = player.getName() != null && FriendManager.isFriend(player.getName().getString())
         || player.getGameProfile() != null && FriendManager.isFriend(player.getGameProfile().getName());
      boolean allowSelf = capeMod == null || capeMod.self.get();
      boolean allowFriends = capeMod == null || capeMod.friends.get();
      if ((isSelf && allowSelf) || (isFriend && allowFriends)) {
         SkinTextures original = (SkinTextures)cir.getReturnValue();
         if (original == null) {
            return;
         }

         Identifier capeTex = capeMod != null ? capeMod.getCapeTexture() : DEFAULT_CAPE;
         SkinTextures customTextures = new SkinTextures(
            original.texture(), original.textureUrl(), capeTex, capeTex, original.model(), original.secure()
         );
         cir.setReturnValue(customTextures);
      }
   }
}
