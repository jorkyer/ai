package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.SwingAnimationModule;
import xyz.angames.dolphy.client.module.modules.render.ViewModelModule;

@Mixin(class_759.class)
public class HeldItemRendererMixin {
    @Inject(method = "method_3228", at = @At(value = "INVOKE", target = "Lnet/minecraft/class_759;method_3233(Lnet/minecraft/class_1309;Lnet/minecraft/class_1799;Lnet/minecraft/class_811;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;I)V"))
    private void onBeforeRenderItem(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_11659 queue, int light, CallbackInfo ci) {
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return;
        boolean mainHand = (hand == class_1268.field_5808);
        ViewModelModule vm = DolphyClient.getInstance().getModuleManager().getModule(ViewModelModule.class);
        if (vm != null && vm.isEnabled()) {
            vm.applyTransform(matrices, mainHand);
        }
        SwingAnimationModule sa = DolphyClient.getInstance().getModuleManager().getModule(SwingAnimationModule.class);
        if (sa != null && sa.isEnabled() && sa.shouldAffectHand(mainHand)) {
            if (sa.isCustomSpeed() && player != null) {
                swingProgress = sa.getCustomSwingProgress(tickDelta);
            }
            sa.applySwingTransform(matrices, swingProgress, equipProgress, mainHand);
        }
    }
}
