package xyz.angames.dolphy.client.module.modules.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.setting.BooleanSetting;

@Environment(EnvType.CLIENT)
public class ChinaHatModule extends Module {
   public final BooleanSetting self = new BooleanSetting("Self", true);
   public final BooleanSetting friends = new BooleanSetting("Friends", false);

   public ChinaHatModule() {
      super("ChinaHat", "Glowing conical shader hat", Module.Category.COSMETIC);
      this.addSettings(this.self, this.friends);
   }
}
