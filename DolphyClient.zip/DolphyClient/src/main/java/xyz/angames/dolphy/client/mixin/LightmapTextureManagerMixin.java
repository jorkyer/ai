package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.FullbrightModule;

@Mixin(class_765.class)
public class LightmapTextureManagerMixin {
    @Inject(method = "method_3313", at = @At("HEAD"), cancellable = true)
    private void onUpdate(float delta, CallbackInfo ci) {
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return;
        FullbrightModule fb = DolphyClient.getInstance().getModuleManager().getModule(FullbrightModule.class);
        if (fb != null && fb.isEnabled() && fb.isGammaMode()) {
        }
    }
}
