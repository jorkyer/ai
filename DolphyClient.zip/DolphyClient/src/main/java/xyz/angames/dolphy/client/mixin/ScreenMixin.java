package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.compat.DolphyCompat;
import xyz.angames.dolphy.client.gui.CustomMainMenuScreen;
import xyz.angames.dolphy.client.util.IASAccountHelper;

@Mixin(class_437.class)
public class ScreenMixin {
    @Inject(method = "method_25423(II)V", at = @At("RETURN"))
    private void onInit(int width, int height, CallbackInfo ci) {
        class_437 self = (class_437) (Object) this;
        if (self instanceof class_442 && !(self instanceof CustomMainMenuScreen)) {
            class_310 mc = class_310.method_1551();
            if (mc != null) {
                mc.execute(() -> {
                    if (mc.field_1755 instanceof class_442 && !(mc.field_1755 instanceof CustomMainMenuScreen)) {
                        mc.method_1507(new CustomMainMenuScreen());
                    }
                });
            }
            return;
        }
        if (self.getClass().getName().equals("ru.vidtu.ias.screen.AccountScreen")) {
            IASAccountHelper.saveFromIASConfig();
        }
    }

    @Inject(method = "method_47413", at = @At("HEAD"))
    private void onRenderWithTooltipHead(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        DolphyCompat.guiStateDirty = true;
    }
}
