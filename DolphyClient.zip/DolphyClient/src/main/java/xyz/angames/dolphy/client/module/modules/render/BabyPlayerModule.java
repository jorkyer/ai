package xyz.angames.dolphy.client.module.modules.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.setting.BooleanSetting;

@Environment(EnvType.CLIENT)
public class BabyPlayerModule extends Module {
   public static BabyPlayerModule INSTANCE;
   public BooleanSetting self = new BooleanSetting("Self", true);
   public BooleanSetting friends = new BooleanSetting("Friends", true);

   public BabyPlayerModule() {
      super("BabyPlayer", "Chibi / baby player model scale", Module.Category.COSMETIC);
      INSTANCE = this;
      this.addSettings(this.self, this.friends);
   }
}
