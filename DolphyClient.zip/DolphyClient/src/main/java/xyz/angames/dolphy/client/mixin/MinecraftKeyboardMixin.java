package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_11908;
import net.minecraft.class_309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;

@Mixin(class_309.class)
public class MinecraftKeyboardMixin {
    @Inject(method = "method_1466", at = @At("HEAD"))
    private void onKey(long window, int action, class_11908 input, CallbackInfo ci) {
        if (input != null && DolphyClient.getInstance() != null) {
            DolphyClient.getInstance().onKeyPress(input.comp_4795(), action);
        }
    }
}
