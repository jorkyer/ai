package xyz.angames.dolphy.client.util;

import dev.sxmurxy.mre.builders.Builder;
import dev.sxmurxy.mre.builders.states.QuadColorState;
import dev.sxmurxy.mre.builders.states.QuadRadiusState;
import dev.sxmurxy.mre.builders.states.SizeState;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.config.ThemeManager;
import xyz.angames.dolphy.client.gui.HudEditorScreen;
import xyz.angames.dolphy.client.module.modules.render.InterfaceModule;

@Environment(EnvType.CLIENT)
public final class DrawUtil {
   public static final Identifier DOLPHY_AVATAR_TEXTURE = Identifier.of("dolphy", "textures/gui/dolphy_avatar.png");
   private static SimpleFramebuffer sharedBgFbo = null;
   private static long lastBgCaptureNs = 0L;
   private static final Vector4f TMP_VEC0 = new Vector4f();
   private static final Vector4f TMP_VEC1 = new Vector4f();
   private static float hudAppearProgress = 0.0F;
   private static long lastAppearUpdateNs = -1L;
   private static boolean lastEditingState = false;
   private static boolean wasInMenu = false;

   public static void notifyScreenOpen() {
      hudAppearProgress = 0.0F;
      wasInMenu = true;
   }

   public static float getHudAppearAnim() {
      MinecraftClient mc = MinecraftClient.getInstance();
      boolean isEditing = mc != null && mc.currentScreen instanceof HudEditorScreen;
      if (mc != null && mc.currentScreen != null && !isEditing) {
         hudAppearProgress = 0.0F;
         wasInMenu = true;
         lastAppearUpdateNs = System.nanoTime();
         return 0.0F;
      }

      long nowNs = System.nanoTime();
      if (lastAppearUpdateNs == -1L) {
         lastAppearUpdateNs = nowNs;
         hudAppearProgress = 0.0F;
      }

      long elapsedNs = nowNs - lastAppearUpdateNs;
      if (wasInMenu || lastEditingState != isEditing || elapsedNs > 90_000_000L) {
         hudAppearProgress = 0.0F;
         wasInMenu = false;
         lastEditingState = isEditing;
         lastAppearUpdateNs = nowNs;
         elapsedNs = 16_000_000L;
      }

      if (elapsedNs > 400_000L) {
         double dt = elapsedNs / 1.0E9;
         if (dt > 0.05) {
            dt = 0.05;
         }
         if (dt < 0.001) {
            dt = 0.001;
         }
         lastAppearUpdateNs = nowNs;
         hudAppearProgress += (1.0F - hudAppearProgress) * (float)(1.0 - Math.exp(-12.0 * dt));
      }

      return Math.max(0.01F, Math.min(1.0F, hudAppearProgress));
   }

   private static InterfaceModule getInterfaceModule() {
      if (DolphyClient.moduleManager != null) {
         if (DolphyClient.moduleManager.getModuleByName("Interface") instanceof InterfaceModule mod) {
            return mod;
         }
      }
      return null;
   }

   public static boolean isGlassHud() {
      InterfaceModule mod = getInterfaceModule();
      if (mod == null || mod.hudStyle == null) {
         return true;
      }
      return !"Solid Dark".equalsIgnoreCase(mod.hudStyle.get());
   }

   public static void drawHudBackground(Matrix4f matrix, float x, float y, float width, float height, float radius, float alpha) {
      drawHudBackground(matrix, x, y, width, height, new QuadRadiusState(radius), alpha);
   }

   public static void drawHudBackground(Matrix4f matrix, float x, float y, float width, float height, QuadRadiusState radiusState, float alpha) {
      alpha = Math.max(0.0F, Math.min(1.0F, alpha));
      if (alpha <= 0.005F || width <= 0.5F || height <= 0.5F) {
         return;
      }

      InterfaceModule mod = getInterfaceModule();
      String style = mod != null && mod.hudStyle != null ? mod.hudStyle.get() : "iPhone Liquid Glass";
      float opacity = mod != null && mod.glassOpacity != null ? mod.glassOpacity.getFloat() : 0.18F;
      float blurRadius = mod != null && mod.glassBlur != null ? mod.glassBlur.getFloat() : 10.0F;
      float refraction = mod != null && mod.glassRefraction != null ? mod.glassRefraction.getFloat() : 0.055F;

      if ("Solid Dark".equalsIgnoreCase(style)) {
         Builder.rectangle()
            .size(new SizeState(width, height))
            .radius(radiusState)
            .color(new QuadColorState(new Color(0, 0, 0, clamp255(250.0F * alpha))))
            .build()
            .render(matrix, x, y);
         return;
      }

      Color primary = ThemeManager.getPrimaryColor();
      Color secondary = ThemeManager.getSecondaryColor();
      Color themed = new Color(ThemeManager.getThemedColor(System.currentTimeMillis() / 10L));

      if ("iPhone Frosted".equalsIgnoreCase(style)) {
         if (blurRadius > 0.5F) {
            int blurTintA = clamp255((opacity * 185.0F + 42.0F) * alpha);
            Builder.blur()
               .size(new SizeState(width, height))
               .radius(radiusState)
               .blurRadius(blurRadius * 1.15F)
               .color(new QuadColorState(new Color(16, 20, 28, blurTintA)))
               .build()
               .render(matrix, x, y);
         }

         Color tl = new Color(235, 245, 255, clamp255((opacity * 125.0F + 18.0F) * alpha));
         Color bl = new Color(18, 22, 32, clamp255((opacity * 195.0F + 48.0F) * alpha));
         Color br = new Color(
            (themed.getRed() + 40) / 3,
            (themed.getGreen() + 50) / 3,
            (themed.getBlue() + 65) / 3,
            clamp255((opacity * 175.0F + 42.0F) * alpha)
         );
         Color tr = new Color(24, 28, 40, clamp255((opacity * 185.0F + 42.0F) * alpha));
         Builder.rectangle()
            .size(new SizeState(width, height))
            .radius(radiusState)
            .color(new QuadColorState(tl, bl, br, tr))
            .build()
            .render(matrix, x, y);

         drawTopSheen(matrix, x, y, width, height, radiusState, alpha * 0.85F);
         drawSpecularRim(matrix, x, y, width, height, radiusState, primary, secondary, alpha * 0.9F);
         return;
      }

      if ("Theme Translucent".equalsIgnoreCase(style)) {
         if (blurRadius > 0.5F) {
            int blurTintA = clamp255((opacity * 175.0F + 38.0F) * alpha);
            Builder.blur()
               .size(new SizeState(width, height))
               .radius(radiusState)
               .blurRadius(blurRadius)
               .color(new QuadColorState(new Color(12, 14, 22, blurTintA)))
               .build()
               .render(matrix, x, y);
         }

         Color tl = new Color(primary.getRed(), primary.getGreen(), primary.getBlue(), clamp255((opacity * 165.0F + 26.0F) * alpha));
         Color bl = new Color(14, 16, 24, clamp255((opacity * 205.0F + 45.0F) * alpha));
         Color br = new Color(secondary.getRed(), secondary.getGreen(), secondary.getBlue(), clamp255((opacity * 165.0F + 26.0F) * alpha));
         Color tr = new Color(18, 20, 30, clamp255((opacity * 195.0F + 40.0F) * alpha));
         Builder.rectangle()
            .size(new SizeState(width, height))
            .radius(radiusState)
            .color(new QuadColorState(tl, bl, br, tr))
            .build()
            .render(matrix, x, y);

         Color rimTL = new Color(primary.getRed(), primary.getGreen(), primary.getBlue(), clamp255(210.0F * alpha));
         Color rimBL = new Color(255, 255, 255, clamp255(75.0F * alpha));
         Color rimBR = new Color(secondary.getRed(), secondary.getGreen(), secondary.getBlue(), clamp255(195.0F * alpha));
         Color rimTR = new Color(255, 255, 255, clamp255(65.0F * alpha));
         Builder.border()
            .size(new SizeState(width, height))
            .radius(radiusState)
            .thickness(0.85F)
            .smoothness(0.8F, 0.8F)
            .color(new QuadColorState(rimTL, rimBL, rimBR, rimTR))
            .build()
            .render(matrix, x, y);
         return;
      }

      // Default: "iPhone Liquid Glass" (iOS 26 real optical refraction + single-pass frosted blur + Fresnel rim)
      int frostAlpha = clamp255((opacity * 145.0F + 28.0F) * alpha);
      Builder.rectangle()
         .size(new SizeState(width, height))
         .radius(radiusState)
         .color(new QuadColorState(new Color(14, 18, 26, frostAlpha)))
         .build()
         .render(matrix, x, y);

      int tintAlpha = clamp255((opacity * 215.0F + 18.0F) * alpha);
      Color glassTL = new Color(235, 248, 255, tintAlpha);
      Color glassBL = new Color(195, 225, 250, Math.max(8, (int)(tintAlpha * 0.65F)));
      Color glassBR = new Color(
         (themed.getRed() + 225) / 2,
         (themed.getGreen() + 238) / 2,
         (themed.getBlue() + 255) / 2,
         Math.max(10, (int)(tintAlpha * 0.88F))
      );
      Color glassTR = new Color(210, 235, 255, Math.max(8, (int)(tintAlpha * 0.72F)));

      Color fresnelColor = new Color(
         Math.min(255, (themed.getRed() + 255 * 2) / 3),
         Math.min(255, (themed.getGreen() + 255 * 2) / 3),
         Math.min(255, (themed.getBlue() + 255 * 2) / 3),
         255
      );

      renderCachedLiquidGlass(
         matrix,
         x,
         y,
         width,
         height,
         radiusState,
         new QuadColorState(glassTL, glassBL, glassBR, glassTR),
         1.0F,
         2.1F,
         alpha,
         Math.min(0.85F, opacity + 0.04F),
         3.2F,
         fresnelColor.getRGB(),
         0.76F * alpha,
         0.45F,
         false,
         refraction
      );

      drawTopSheen(matrix, x, y, width, height, radiusState, alpha);
      drawSpecularRim(matrix, x, y, width, height, radiusState, primary, secondary, alpha);
   }

   public static void renderCachedLiquidGlass(
      Matrix4f matrix,
      float x,
      float y,
      float width,
      float height,
      QuadRadiusState radiusState,
      QuadColorState colorState,
      float smoothness,
      float cornerSmoothness,
      float globalAlpha,
      float baseAlpha,
      float fresnelPower,
      int fresnelColorRgb,
      float fresnelAlpha,
      float fresnelMix,
      boolean fresnelInvert,
      float distortStrength
   ) {
      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.getFramebuffer() != null && mc.getWindow() != null) {
            Framebuffer mainFbo = mc.getFramebuffer();
            int fbW = mainFbo.textureWidth;
            int fbH = mainFbo.textureHeight;
            if (fbW > 0 && fbH > 0) {
               if (sharedBgFbo == null) {
                  sharedBgFbo = new SimpleFramebuffer(fbW, fbH, false);
               } else if (sharedBgFbo.textureWidth != fbW || sharedBgFbo.textureHeight != fbH) {
                  sharedBgFbo.resize(fbW, fbH);
               }
               long nowNs = System.nanoTime();
               if (nowNs - lastBgCaptureNs > 3_500_000L) {
                  lastBgCaptureNs = nowNs;
                  sharedBgFbo.beginWrite(false);
                  mainFbo.draw(fbW, fbH);
                  mainFbo.beginWrite(false);
               }
               float scaledW = Math.max(1.0F, (float)mc.getWindow().getScaledWidth());
               float scaledH = Math.max(1.0F, (float)mc.getWindow().getScaledHeight());
               matrix.transform(TMP_VEC0.set(x, y, 0.0F, 1.0F));
               matrix.transform(TMP_VEC1.set(x + width, y + height, 0.0F, 1.0F));
               float u = TMP_VEC0.x / scaledW;
               float v = (scaledH - TMP_VEC1.y) / scaledH;
               float uw = (TMP_VEC1.x - TMP_VEC0.x) / scaledW;
               float vh = (TMP_VEC1.y - TMP_VEC0.y) / scaledH;
               Builder.liquidGlass()
                  .size(new SizeState(width, height))
                  .radius(radiusState)
                  .color(colorState)
                  .smoothness(smoothness, cornerSmoothness)
                  .alpha(globalAlpha, baseAlpha)
                  .fresnel(fresnelPower, fresnelColorRgb, fresnelAlpha, fresnelMix, fresnelInvert)
                  .distortStrength(distortStrength)
                  .texture(u, v, uw, vh, sharedBgFbo.getColorAttachment())
                  .build()
                  .render(matrix, x, y);
               return;
            }
         }
      } catch (Exception ignored) {
      }
      Builder.liquidGlass()
         .size(new SizeState(width, height))
         .radius(radiusState)
         .color(colorState)
         .smoothness(smoothness, cornerSmoothness)
         .alpha(globalAlpha, baseAlpha)
         .fresnel(fresnelPower, fresnelColorRgb, fresnelAlpha, fresnelMix, fresnelInvert)
         .distortStrength(distortStrength)
         .captureBackground()
         .build()
         .render(matrix, x, y);
   }

   private static void drawTopSheen(Matrix4f matrix, float x, float y, float width, float height, QuadRadiusState radiusState, float alpha) {
      float sheenH = Math.min(height * 0.42F, 14.0F);
      if (sheenH >= 2.0F && width > 3.0F) {
         Color sheenTop = new Color(255, 255, 255, clamp255(34.0F * alpha));
         Color sheenBot = new Color(255, 255, 255, 0);
         QuadRadiusState topRad = new QuadRadiusState(radiusState.radius1(), 0.0F, 0.0F, radiusState.radius4());
         Builder.rectangle()
            .size(new SizeState(width - 1.2F, sheenH))
            .radius(topRad)
            .color(new QuadColorState(sheenTop, sheenBot, sheenBot, sheenTop))
            .build()
            .render(matrix, x + 0.6F, y + 0.5F);
      }
   }

   private static void drawSpecularRim(
      Matrix4f matrix, float x, float y, float width, float height, QuadRadiusState radiusState, Color primary, Color secondary, float alpha
   ) {
      Color rimTL = new Color(255, 255, 255, clamp255(205.0F * alpha));
      Color rimBL = new Color(
         (primary.getRed() + 255) / 2,
         (primary.getGreen() + 255) / 2,
         (primary.getBlue() + 255) / 2,
         clamp255(78.0F * alpha)
      );
      Color rimBR = new Color(
         (secondary.getRed() + 255) / 2,
         (secondary.getGreen() + 255) / 2,
         (secondary.getBlue() + 255) / 2,
         clamp255(170.0F * alpha)
      );
      Color rimTR = new Color(255, 255, 255, clamp255(52.0F * alpha));
      Builder.border()
         .size(new SizeState(width, height))
         .radius(radiusState)
         .thickness(0.8F)
         .smoothness(0.8F, 0.8F)
         .color(new QuadColorState(rimTL, rimBL, rimBR, rimTR))
         .build()
         .render(matrix, x, y);
   }

   public static void drawHudPill(Matrix4f matrix, float x, float y, float width, float height, float radius, float alpha) {
      drawHudPill(matrix, x, y, width, height, new QuadRadiusState(radius), alpha);
   }

   public static void drawHudPill(Matrix4f matrix, float x, float y, float width, float height, QuadRadiusState radiusState, float alpha) {
      alpha = Math.max(0.0F, Math.min(1.0F, alpha));
      if (alpha <= 0.005F || width <= 0.5F || height <= 0.5F) {
         return;
      }

      if (!isGlassHud()) {
         Builder.rectangle()
            .size(new SizeState(width, height))
            .radius(radiusState)
            .color(new QuadColorState(new Color(14, 14, 20, clamp255(225.0F * alpha))))
            .build()
            .render(matrix, x, y);
         return;
      }

      Color themed = new Color(ThemeManager.getThemedColor(System.currentTimeMillis() / 10L));
      Color pillTL = new Color(255, 255, 255, clamp255(28.0F * alpha));
      Color pillBL = new Color(16, 20, 28, clamp255(44.0F * alpha));
      Color pillBR = new Color(
         (themed.getRed() + 220) / 2,
         (themed.getGreen() + 235) / 2,
         (themed.getBlue() + 255) / 2,
         clamp255(24.0F * alpha)
      );
      Color pillTR = new Color(220, 238, 255, clamp255(20.0F * alpha));

      Builder.rectangle()
         .size(new SizeState(width, height))
         .radius(radiusState)
         .color(new QuadColorState(pillTL, pillBL, pillBR, pillTR))
         .build()
         .render(matrix, x, y);

      Color rimTL = new Color(255, 255, 255, clamp255(72.0F * alpha));
      Color rimSub = new Color(255, 255, 255, clamp255(20.0F * alpha));
      Color rimBR = new Color(
         (themed.getRed() + 255) / 2,
         (themed.getGreen() + 255) / 2,
         (themed.getBlue() + 255) / 2,
         clamp255(52.0F * alpha)
      );
      Builder.border()
         .size(new SizeState(width, height))
         .radius(radiusState)
         .thickness(0.55F)
         .smoothness(0.7F, 0.7F)
         .color(new QuadColorState(rimTL, rimSub, rimBR, rimSub))
         .build()
         .render(matrix, x, y);
   }

   private static int clamp255(float val) {
      return Math.max(0, Math.min(255, Math.round(val)));
   }

   public static boolean drawDolphyAvatar(Matrix4f matrix, float x, float y, float size, float radius, float alpha) {
      alpha = Math.max(0.0F, Math.min(1.0F, alpha));
      if (alpha <= 0.005F || size <= 0.5F) {
         return false;
      }
      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc != null && mc.getTextureManager() != null) {
            AbstractTexture tex = mc.getTextureManager().getTexture(DOLPHY_AVATAR_TEXTURE);
            if (tex != null) {
               long step = System.currentTimeMillis() / 10L;
               Color c1 = new Color(ThemeManager.getThemedColor(step));
               Color c2 = new Color(ThemeManager.getThemedColor(step + 90L));
               Color c3 = new Color(ThemeManager.getThemedColor(step + 180L));
               Color c4 = new Color(ThemeManager.getThemedColor(step + 270L));
               int a = clamp255(255.0F * alpha);
               Color tl = new Color(c1.getRed(), c1.getGreen(), c1.getBlue(), a);
               Color bl = new Color(c2.getRed(), c2.getGreen(), c2.getBlue(), a);
               Color br = new Color(c3.getRed(), c3.getGreen(), c3.getBlue(), a);
               Color tr = new Color(c4.getRed(), c4.getGreen(), c4.getBlue(), a);
               Builder.texture()
                  .size(new SizeState(size, size))
                  .radius(new QuadRadiusState(radius))
                  .texture(0.0F, 0.0F, 1.0F, 1.0F, tex)
                  .color(new QuadColorState(tl, bl, br, tr))
                  .build()
                  .render(matrix, x, y);
               return true;
            }
         }
      } catch (Exception ignored) {
      }
      return false;
   }

   public static void drawLiquidRect(
      MatrixStack matrices,
      float x,
      float y,
      float width,
      float height,
      BorderRadius borderRadius,
      ColorRGBA color,
      float cornerSmoothness,
      float fresnelPower,
      float fresnelAlpha,
      float baseAlpha,
      boolean fresnelInvert,
      float fresnelMix,
      float distortStrength,
      float blurRadius
   ) {
      Matrix4f matrix = matrices.peek().getPositionMatrix();
      Color awtColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
      QuadRadiusState radiusState = new QuadRadiusState(
         borderRadius.topLeftRadius(), borderRadius.topRightRadius(), borderRadius.bottomLeftRadius(), borderRadius.bottomRightRadius()
      );
      QuadRadiusState liquidRadiusState = new QuadRadiusState(
         borderRadius.topLeftRadius() * cornerSmoothness / 2.0F,
         borderRadius.topRightRadius() * cornerSmoothness / 2.0F,
         borderRadius.bottomLeftRadius() * cornerSmoothness / 2.0F,
         borderRadius.bottomRightRadius() * cornerSmoothness / 2.0F
      );
      Builder.blur()
         .size(new SizeState(width, height))
         .radius(radiusState)
         .blurRadius(blurRadius)
         .color(new QuadColorState(new Color(255, 255, 255, 45)))
         .build()
         .render(matrix, x, y);
      Builder.blur()
         .size(new SizeState(width, height))
         .radius(liquidRadiusState)
         .color(new QuadColorState(awtColor))
         .smoothness(1.0F)
         .build()
         .render(matrix, x, y);
   }
}
