package xyz.angames.dolphy.client.module.modules.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents.Last;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import xyz.angames.dolphy.client.config.ThemeManager;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.setting.BooleanSetting;
import xyz.angames.dolphy.client.module.setting.ModeSetting;
import xyz.angames.dolphy.client.module.setting.NumberSetting;
import xyz.angames.dolphy.client.util.FriendManager;

@Environment(EnvType.CLIENT)
public class WingsModule extends Module {
   private final MinecraftClient mc = MinecraftClient.getInstance();
   private static final WingsModule.WingPoint[] CYBER_SHAPE = new WingsModule.WingPoint[]{
      new WingsModule.WingPoint(0.08F, 0.1F, 0.88F),
      new WingsModule.WingPoint(0.28F, 0.34F, 0.78F),
      new WingsModule.WingPoint(0.56F, 0.82F, 0.62F),
      new WingsModule.WingPoint(0.86F, 0.3F, 0.52F),
      new WingsModule.WingPoint(1.14F, 0.46F, 0.4F),
      new WingsModule.WingPoint(1.24F, 0.04F, 0.3F),
      new WingsModule.WingPoint(1.02F, -0.18F, 0.28F),
      new WingsModule.WingPoint(1.18F, -0.64F, 0.22F),
      new WingsModule.WingPoint(0.86F, -0.46F, 0.2F),
      new WingsModule.WingPoint(0.8F, -0.98F, 0.14F),
      new WingsModule.WingPoint(0.54F, -0.74F, 0.16F),
      new WingsModule.WingPoint(0.3F, -1.16F, 0.12F),
      new WingsModule.WingPoint(0.1F, -0.54F, 0.18F)
   };

   public final ModeSetting style = new ModeSetting(
      "Style", "Lunar Dragon", "Lunar Dragon", "Angel", "Demon", "Crystal", "Cyber"
   );
   public final ModeSetting colorMode = new ModeSetting(
      "Color", "Theme", "Theme", "Chroma", "Crimson", "Gold & White", "Obsidian"
   );
   public final BooleanSetting self = new BooleanSetting("Self", true);
   public final BooleanSetting players = new BooleanSetting("Players", false);
   public final NumberSetting size = new NumberSetting("Size", 1.0, 0.65, 1.45, 0.05);
   public final NumberSetting flapSpeed = new NumberSetting("FlapSpeed", 1.0, 0.3, 2.5, 0.1);

   private float selfBodyYaw;
   private boolean selfBodyYawInitialized;

   public WingsModule() {
      super("Wings", "Lunar Client 3D wings (Dragon, Angel, Demon, Crystal, Cyber)", Module.Category.COSMETIC);
      this.addSettings(this.style, this.colorMode, this.self, this.players, this.size, this.flapSpeed);
      WorldRenderEvents.LAST
         .register(
            (Last)context -> {
               if (this.isEnabled() && this.mc.player != null && this.mc.world != null && this.mc.gameRenderer != null) {
                  MatrixStack stack = context.matrixStack();
                  float tickDelta = context.tickCounter().getTickDelta(true);
                  Vec3d camera = this.mc.gameRenderer.getCamera().getPos();
                  stack.push();
                  RenderSystem.enableBlend();
                  RenderSystem.disableCull();
                  RenderSystem.enableDepthTest();
                  RenderSystem.depthMask(false);
                  RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
                  if (this.self.get()
                     && !this.mc.options.getPerspective().isFirstPerson()
                     && this.mc.player.isAlive()
                     && !this.hasElytra(this.mc.player)) {
                     try {
                        this.renderWings(stack, this.mc.player, tickDelta, camera);
                     } catch (Exception var10) {
                     }
                  }

                  if (this.players.get()) {
                     for (Entity entity : this.mc.world.getEntities()) {
                        if (entity instanceof PlayerEntity player && player != this.mc.player && player.isAlive() && !this.hasElytra(player)) {
                           try {
                              this.renderWings(stack, player, tickDelta, camera);
                           } catch (Exception var9) {
                           }
                        }
                     }
                  }

                  RenderSystem.depthMask(true);
                  RenderSystem.enableCull();
                  RenderSystem.disableBlend();
                  RenderSystem.blendFuncSeparate(
                     GlStateManager.SrcFactor.SRC_ALPHA,
                     GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA,
                     GlStateManager.SrcFactor.ONE,
                     GlStateManager.DstFactor.ZERO
                  );
                  RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
                  stack.pop();
               }
            }
         );
   }

   @Override
   public void onDisable() {
      this.selfBodyYawInitialized = false;
   }

   private void renderWings(MatrixStack stack, PlayerEntity player, float tickDelta, Vec3d camera) {
      double x = MathHelper.lerp(tickDelta, player.prevX, player.getX()) - camera.x;
      double y = MathHelper.lerp(tickDelta, player.prevY, player.getY()) - camera.y;
      double z = MathHelper.lerp(tickDelta, player.prevZ, player.getZ()) - camera.z;
      float bodyYaw = this.resolveBodyYaw(player, tickDelta);
      float move = MathHelper.clamp(player.limbAnimator.getSpeed(tickDelta), 0.0F, 1.0F);
      WingsModule.WingPose pose = this.resolvePose(player, tickDelta);
      if (pose != null) {
         float speedMul = (float)this.flapSpeed.get();
         float animTime = (player.age + tickDelta) * pose.flapSpeed * speedMul;
         float flap = (float)Math.sin(animTime) * pose.flapAmplitude;
         float open = (22.0F + flap + move * pose.motionSpreadBoost) * pose.openMultiplier;
         float wingScale = (float)this.size.get() * pose.scaleMultiplier;
         int baseColor = this.resolveBaseColor(0);
         int accentColor = this.resolveBaseColor(70);
         int glowColor = this.resolveGlowColor(baseColor);
         int coreColor = this.resolveCoreColor(baseColor);
         boolean isBaby = false;
         if (BabyPlayerModule.INSTANCE != null && BabyPlayerModule.INSTANCE.isEnabled()) {
            if (player == this.mc.player && BabyPlayerModule.INSTANCE.self.get()) {
               isBaby = true;
            } else if (player != this.mc.player && BabyPlayerModule.INSTANCE.friends.get() && FriendManager.isFriend(player.getName().getString())) {
               isBaby = true;
            }
         }

         stack.push();
         stack.translate(x, y, z);
         if (isBaby) {
            stack.scale(0.5F, 0.5F, 0.5F);
         }

         stack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F - bodyYaw));
         if (pose.preTranslateY != 0.0F || pose.preTranslateZ != 0.0F) {
            stack.translate(0.0F, pose.preTranslateY, pose.preTranslateZ);
         }

         if (pose.pitchRotation != 0.0F) {
            stack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pose.pitchRotation));
         }

         if (pose.rollRotation != 0.0F) {
            stack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(pose.rollRotation));
         }

         stack.translate(0.0F, pose.anchorY, pose.anchorZ);
         stack.scale(wingScale, wingScale, wingScale);
         this.renderWingSide(stack, -1.0F, open, animTime, baseColor, accentColor, glowColor, coreColor, pose);
         this.renderWingSide(stack, 1.0F, open, animTime, baseColor, accentColor, glowColor, coreColor, pose);
         stack.pop();
      }
   }

   private void renderWingSide(
      MatrixStack stack,
      float side,
      float open,
      float animTime,
      int baseColor,
      int accentColor,
      int glowColor,
      int coreColor,
      WingsModule.WingPose pose
   ) {
      stack.push();
      stack.translate(side * pose.sideOffset, pose.sideYOffset, pose.sideZOffset);
      stack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * open));
      stack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * pose.sideRoll));
      stack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pose.sidePitch));

      String mode = this.style.get();
      if ("Lunar Dragon".equalsIgnoreCase(mode) || "Demon".equalsIgnoreCase(mode)) {
         this.renderLunarDragonWing(stack, side, animTime, baseColor, accentColor, glowColor, "Demon".equalsIgnoreCase(mode));
      } else if ("Angel".equalsIgnoreCase(mode)) {
         this.renderAngelWing(stack, side, animTime, baseColor, accentColor, glowColor);
      } else if ("Crystal".equalsIgnoreCase(mode)) {
         this.renderCrystalWing(stack, side, animTime, baseColor, accentColor, glowColor);
      } else {
         RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
         this.drawWingLayer(stack, side, 1.22F, setAlpha(glowColor, 48), setAlpha(glowColor, 0));
         this.drawWingLayer(stack, side, 0.84F, setAlpha(coreColor, 57), setAlpha(coreColor, 0));
         RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
         this.drawWingLayer(stack, side, 1.0F, setAlpha(baseColor, 220), setAlpha(baseColor, 10));
         RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
         this.drawWingOutline(stack, side, 1.0F, setAlpha(baseColor, 136));
         this.drawWingRibs(stack, side, 0.96F, setAlpha(glowColor, 44));
      }

      stack.pop();
   }

   private void renderLunarDragonWing(
      MatrixStack stack, float side, float animTime, int baseColor, int accentColor, int glowColor, boolean demonMode
   ) {
      // Articulated outer wing joint flap (Lunar Client style two-stage wing fold)
      float outerFlap = (float)Math.sin(animTime - 0.55F) * 14.0F;
      Matrix4f m = stack.peek().getPositionMatrix();

      // Bone color (dark obsidian/charcoal with theme highlight) and membrane colors
      int boneDark = demonMode ? packARGB(32, 12, 16, 245) : interpolateColor(packARGB(26, 26, 34, 245), baseColor, 0.35F);
      int boneHighlight = interpolateColor(baseColor, packARGB(255, 255, 255, 255), 0.35F);
      int memInner = setAlpha(demonMode ? interpolateColor(baseColor, packARGB(180, 15, 25, 255), 0.5F) : baseColor, 195);
      int memOuter = setAlpha(accentColor, 85);

      // Shoulder -> Elbow/Apex -> Wrist coordinates
      float sx = 0.0F, sy = 0.04F;
      float ex = side * 0.42F, ey = 0.38F;
      float wx = side * 0.92F, wy = 0.46F + (outerFlap * 0.004F);

      // 5 Dragon finger tips (from outer tip to inner lower tip)
      float[][] tips = new float[][]{
         {side * 1.44F, 0.18F + outerFlap * 0.008F, -0.04F},
         {side * 1.28F, -0.26F + outerFlap * 0.006F, -0.03F},
         {side * 0.98F, -0.62F + outerFlap * 0.004F, -0.02F},
         {side * 0.62F, -0.82F + outerFlap * 0.002F, -0.01F},
         {side * 0.24F, -0.68F, 0.0F}
      };
      float[][] origins = new float[][]{
         {wx, wy, 0.0F},
         {wx, wy, 0.0F},
         {(ex + wx) * 0.5F, (ey + wy) * 0.5F, 0.0F},
         {ex, ey, 0.0F},
         {ex, ey, 0.0F}
      };

      // 1. Render webbed leathery membrane between finger bones with scalloped curves
      RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
      BufferBuilder memBuf = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);

      // Inner shoulder-to-elbow-to-finger4 membrane
      this.vertex(memBuf, m, sx, sy, 0.0F, memInner);
      this.vertex(memBuf, m, ex, ey, 0.0F, memInner);
      this.vertex(memBuf, m, tips[4][0], tips[4][1], tips[4][2], memOuter);

      this.vertex(memBuf, m, sx, sy, 0.0F, memInner);
      this.vertex(memBuf, m, tips[4][0], tips[4][1], tips[4][2], memOuter);
      this.vertex(memBuf, m, side * 0.05F, -0.36F, 0.0F, memInner);

      // Webbing between the 5 fingers (subdivided for concave bat/dragon scallop)
      for (int i = 0; i < tips.length - 1; i++) {
         float ox0 = origins[i][0], oy0 = origins[i][1];
         float ox1 = origins[i + 1][0], oy1 = origins[i + 1][1];
         float tx0 = tips[i][0], ty0 = tips[i][1], tz0 = tips[i][2];
         float tx1 = tips[i + 1][0], ty1 = tips[i + 1][1], tz1 = tips[i + 1][2];

         // Midpoint pulled inward toward origin for realistic curved dragon wing webbing
         float mxMid = (tx0 + tx1) * 0.5F * 0.84F + (ox0 + ox1) * 0.5F * 0.16F;
         float myMid = (ty0 + ty1) * 0.5F * 0.84F + (oy0 + oy1) * 0.5F * 0.16F;
         float mzMid = (tz0 + tz1) * 0.5F;

         this.vertex(memBuf, m, ox0, oy0, 0.0F, memInner);
         this.vertex(memBuf, m, tx0, ty0, tz0, memOuter);
         this.vertex(memBuf, m, mxMid, myMid, mzMid, memOuter);

         this.vertex(memBuf, m, ox0, oy0, 0.0F, memInner);
         this.vertex(memBuf, m, mxMid, myMid, mzMid, memOuter);
         this.vertex(memBuf, m, ox1, oy1, 0.0F, memInner);

         this.vertex(memBuf, m, ox1, oy1, 0.0F, memInner);
         this.vertex(memBuf, m, mxMid, myMid, mzMid, memOuter);
         this.vertex(memBuf, m, tx1, ty1, tz1, memOuter);
      }
      BufferRenderer.drawWithGlobalProgram(memBuf.end());

      // 2. Soft additive glow along membrane & bones
      RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
      BufferBuilder glowBuf = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
      for (int i = 0; i < tips.length - 1; i++) {
         this.vertex(glowBuf, m, origins[i][0], origins[i][1], 0.0F, setAlpha(glowColor, 65));
         this.vertex(glowBuf, m, tips[i][0], tips[i][1], tips[i][2], setAlpha(glowColor, 0));
         this.vertex(glowBuf, m, tips[i + 1][0], tips[i + 1][1], tips[i + 1][2], setAlpha(glowColor, 0));
      }
      BufferRenderer.drawWithGlobalProgram(glowBuf.end());

      // 3. Thick 3D Dragon Arm & Finger Bones + Apex Thumb Claw
      RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
      BufferBuilder boneBuf = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
      this.drawBoneStrut(boneBuf, m, sx, sy, ex, ey, 0.055F, 0.048F, boneDark, boneHighlight);
      this.drawBoneStrut(boneBuf, m, ex, ey, wx, wy, 0.046F, 0.035F, boneDark, boneHighlight);
      // Apex claw spike at elbow
      this.drawBoneStrut(boneBuf, m, ex, ey, ex + side * 0.09F, ey + 0.20F, 0.036F, 0.004F, boneHighlight, setAlpha(glowColor, 255));
      if (demonMode) {
         // Extra wrist horn in Demon mode
         this.drawBoneStrut(boneBuf, m, wx, wy, wx + side * 0.12F, wy + 0.18F, 0.030F, 0.004F, boneHighlight, setAlpha(glowColor, 255));
      }
      // 5 Finger bones tapering to sharp claw tips
      for (int i = 0; i < tips.length; i++) {
         this.drawBoneStrut(
            boneBuf,
            m,
            origins[i][0],
            origins[i][1],
            tips[i][0],
            tips[i][1],
            0.030F,
            0.005F,
            boneDark,
            setAlpha(boneHighlight, 240)
         );
      }
      BufferRenderer.drawWithGlobalProgram(boneBuf.end());
   }

   private void drawBoneStrut(
      BufferBuilder buf, Matrix4f m, float x0, float y0, float x1, float y1, float w0, float w1, int colCore, int colEdge
   ) {
      float dx = x1 - x0;
      float dy = y1 - y0;
      float len = MathHelper.sqrt(dx * dx + dy * dy);
      if (len < 1.0E-4F) {
         return;
      }
      float nx = -dy / len;
      float ny = dx / len;

      // Upper half of strut
      this.vertex(buf, m, x0, y0, 0.008F, colEdge);
      this.vertex(buf, m, x0 + nx * w0, y0 + ny * w0, 0.0F, colCore);
      this.vertex(buf, m, x1 + nx * w1, y1 + ny * w1, 0.0F, colCore);

      this.vertex(buf, m, x0, y0, 0.008F, colEdge);
      this.vertex(buf, m, x1 + nx * w1, y1 + ny * w1, 0.0F, colCore);
      this.vertex(buf, m, x1, y1, 0.004F, colEdge);

      // Lower half of strut
      this.vertex(buf, m, x0, y0, -0.008F, colEdge);
      this.vertex(buf, m, x1 - nx * w1, y1 - ny * w1, 0.0F, colCore);
      this.vertex(buf, m, x0 - nx * w0, y0 - ny * w0, 0.0F, colCore);

      this.vertex(buf, m, x0, y0, -0.008F, colEdge);
      this.vertex(buf, m, x1, y1, -0.004F, colEdge);
      this.vertex(buf, m, x1 - nx * w1, y1 - ny * w1, 0.0F, colCore);
   }

   private void renderAngelWing(MatrixStack stack, float side, float animTime, int baseColor, int accentColor, int glowColor) {
      Matrix4f m = stack.peek().getPositionMatrix();
      int white = packARGB(252, 252, 255, 240);
      int goldCrest = interpolateColor(baseColor, packARGB(255, 225, 130, 255), 0.55F);
      int featherTip = setAlpha(interpolateColor(white, baseColor, 0.45F), 165);

      RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
      BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);

      // 3 overlapping tiers of angel feathers (Primary outer, Secondary middle, Covert inner)
      int primaryCount = 9;
      for (int i = 0; i < primaryCount; i++) {
         float t = (float)i / (primaryCount - 1);
         float ox = side * (0.14F + t * 0.72F);
         float oy = 0.24F + (float)Math.sin(t * Math.PI) * 0.26F - t * 0.12F;
         float ripple = (float)Math.sin(animTime * 1.3F - i * 0.45F) * 0.04F;
         float angle = (-12.0F - t * 68.0F) * (float)(Math.PI / 180.0);
         float len = 0.58F + (1.0F - Math.abs(t - 0.35F)) * 0.36F;
         float tx = ox + side * (float)Math.cos(angle) * len;
         float ty = oy + (float)Math.sin(angle) * len + ripple;
         this.drawFeatherBlade(buf, m, ox, oy, tx, ty, 0.068F, white, featherTip);
      }

      int secondaryCount = 7;
      for (int i = 0; i < secondaryCount; i++) {
         float t = (float)i / (secondaryCount - 1);
         float ox = side * (0.10F + t * 0.54F);
         float oy = 0.22F + (float)Math.sin(t * Math.PI) * 0.18F - t * 0.08F;
         float angle = (-18.0F - t * 62.0F) * (float)(Math.PI / 180.0);
         float len = 0.36F + (1.0F - t * 0.4F) * 0.18F;
         float tx = ox + side * (float)Math.cos(angle) * len;
         float ty = oy + (float)Math.sin(angle) * len;
         this.drawFeatherBlade(buf, m, ox, oy, tx, ty, 0.056F, setAlpha(goldCrest, 235), setAlpha(white, 210));
      }

      // Golden/theme upper arch crest
      this.drawBoneStrut(buf, m, 0.0F, 0.08F, side * 0.44F, 0.42F, 0.048F, 0.040F, goldCrest, white);
      this.drawBoneStrut(buf, m, side * 0.44F, 0.42F, side * 0.88F, 0.22F, 0.040F, 0.015F, goldCrest, white);
      BufferRenderer.drawWithGlobalProgram(buf.end());

      // Soft celestial bloom
      RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
      BufferBuilder glowBuf = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
      this.vertex(glowBuf, m, 0.0F, 0.15F, 0.0F, setAlpha(glowColor, 70));
      this.vertex(glowBuf, m, side * 1.25F, 0.25F, 0.0F, setAlpha(glowColor, 0));
      this.vertex(glowBuf, m, side * 0.55F, -0.75F, 0.0F, setAlpha(glowColor, 0));
      BufferRenderer.drawWithGlobalProgram(glowBuf.end());
   }

   private void drawFeatherBlade(BufferBuilder buf, Matrix4f m, float x0, float y0, float x1, float y1, float width, int rootCol, int tipCol) {
      float dx = x1 - x0;
      float dy = y1 - y0;
      float len = MathHelper.sqrt(dx * dx + dy * dy);
      if (len < 1.0E-4F) {
         return;
      }
      float nx = -dy / len * width;
      float ny = dx / len * width;
      float mx = x0 + dx * 0.55F;
      float my = y0 + dy * 0.55F;

      this.vertex(buf, m, x0, y0, 0.0F, rootCol);
      this.vertex(buf, m, mx + nx, my + ny, 0.005F, rootCol);
      this.vertex(buf, m, x1, y1, 0.0F, tipCol);

      this.vertex(buf, m, x0, y0, 0.0F, rootCol);
      this.vertex(buf, m, x1, y1, 0.0F, tipCol);
      this.vertex(buf, m, mx - nx, my - ny, -0.005F, rootCol);
   }

   private void renderCrystalWing(MatrixStack stack, float side, float animTime, int baseColor, int accentColor, int glowColor) {
      Matrix4f m = stack.peek().getPositionMatrix();
      int core = interpolateColor(baseColor, packARGB(255, 255, 255, 255), 0.65F);

      float[][] shards = new float[][]{
         {0.28F, 0.34F, 0.72F, 0.58F, 0.075F},
         {0.34F, 0.24F, 1.08F, 0.42F, 0.085F},
         {0.38F, 0.12F, 1.28F, 0.08F, 0.080F},
         {0.34F, 0.00F, 1.16F, -0.28F, 0.072F},
         {0.28F, -0.10F, 0.92F, -0.58F, 0.065F},
         {0.20F, -0.18F, 0.58F, -0.78F, 0.058F}
      };

      RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
      BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
      for (int i = 0; i < shards.length; i++) {
         float bob = (float)Math.sin(animTime * 1.4F + i * 0.7F) * 0.035F;
         float x0 = side * shards[i][0];
         float y0 = shards[i][1] + bob;
         float x1 = side * shards[i][2];
         float y1 = shards[i][3] + bob * 1.4F;
         float w = shards[i][4];
         int col = i % 2 == 0 ? setAlpha(baseColor, 210) : setAlpha(accentColor, 200);
         this.drawFeatherBlade(buf, m, x0, y0, x1, y1, w, setAlpha(core, 240), col);
      }
      BufferRenderer.drawWithGlobalProgram(buf.end());

      RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
      BufferBuilder glowBuf = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
      for (int i = 0; i < shards.length; i++) {
         float bob = (float)Math.sin(animTime * 1.4F + i * 0.7F) * 0.035F;
         this.drawFeatherBlade(
            glowBuf,
            m,
            side * shards[i][0],
            shards[i][1] + bob,
            side * shards[i][2],
            shards[i][3] + bob * 1.4F,
            shards[i][4] * 1.45F,
            setAlpha(glowColor, 75),
            setAlpha(glowColor, 0)
         );
      }
      BufferRenderer.drawWithGlobalProgram(glowBuf.end());
   }

   private void drawWingLayer(MatrixStack stack, float side, float scale, int rootColor, int edgeColor) {
      Matrix4f matrix = stack.peek().getPositionMatrix();
      BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);

      for (int i = 0; i < CYBER_SHAPE.length; i++) {
         WingsModule.WingPoint cur = CYBER_SHAPE[i];
         WingsModule.WingPoint next = CYBER_SHAPE[(i + 1) % CYBER_SHAPE.length];
         this.vertex(buffer, matrix, 0.0F, 0.0F, 0.0F, rootColor);
         this.vertex(buffer, matrix, side * cur.x * scale, cur.y * scale, 0.0F, this.applyPointAlpha(edgeColor, cur.alphaMul));
         this.vertex(buffer, matrix, side * next.x * scale, next.y * scale, 0.0F, this.applyPointAlpha(edgeColor, next.alphaMul));
      }

      BufferRenderer.drawWithGlobalProgram(buffer.end());
   }

   private void drawWingOutline(MatrixStack stack, float side, float scale, int color) {
      Matrix4f matrix = stack.peek().getPositionMatrix();
      RenderSystem.lineWidth(1.35F);
      GL11.glEnable(2848);
      BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);

      for (WingsModule.WingPoint point : CYBER_SHAPE) {
         this.vertex(buffer, matrix, side * point.x * scale, point.y * scale, 0.0F, color);
      }

      this.vertex(buffer, matrix, side * CYBER_SHAPE[0].x * scale, CYBER_SHAPE[0].y * scale, 0.0F, color);
      BufferRenderer.drawWithGlobalProgram(buffer.end());
      GL11.glDisable(2848);
   }

   private void drawWingRibs(MatrixStack stack, float side, float scale, int color) {
      Matrix4f matrix = stack.peek().getPositionMatrix();
      int[] ribIndices = new int[]{2, 4, 7, 9, 11};
      RenderSystem.lineWidth(0.9F);
      BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.LINES, VertexFormats.POSITION_COLOR);

      for (int idx : ribIndices) {
         WingsModule.WingPoint point = CYBER_SHAPE[idx];
         this.vertex(buffer, matrix, 0.0F, 0.0F, 0.0F, setAlpha(color, Math.max(8, (int)(alpha(color) * 0.75F))));
         this.vertex(buffer, matrix, side * point.x * scale, point.y * scale, 0.0F, this.applyPointAlpha(color, point.alphaMul));
      }

      BufferRenderer.drawWithGlobalProgram(buffer.end());
   }

   private int resolveBaseColor(int offset) {
      String cm = this.colorMode.get();
      long now = System.currentTimeMillis();
      if ("Chroma".equalsIgnoreCase(cm)) {
         float hue = (float)((now / 12L + offset) % 360L) / 360.0F;
         int rgb = Color.HSBtoRGB(hue, 0.85F, 1.0F);
         return setAlpha(rgb, 255);
      } else if ("Crimson".equalsIgnoreCase(cm)) {
         return offset == 0 ? packARGB(215, 22, 42, 255) : packARGB(135, 10, 22, 255);
      } else if ("Gold & White".equalsIgnoreCase(cm)) {
         return offset == 0 ? packARGB(255, 215, 95, 255) : packARGB(245, 245, 255, 255);
      } else if ("Obsidian".equalsIgnoreCase(cm)) {
         return offset == 0 ? packARGB(55, 35, 95, 255) : packARGB(25, 18, 45, 255);
      } else {
         int colorInt = ThemeManager.getThemedColor(now / 10L + offset);
         return setAlpha(colorInt, 255);
      }
   }

   private int resolveGlowColor(int base) {
      return interpolateColor(base, packARGB(255, 255, 255, 255), 0.28F);
   }

   private int resolveCoreColor(int base) {
      return interpolateColor(base, packARGB(255, 255, 255, 255), 0.55F);
   }

   private static int interpolateColor(int a, int b, float t) {
      int ar = a >> 16 & 0xFF;
      int ag = a >> 8 & 0xFF;
      int ab = a & 0xFF;
      int aa = a >> 24 & 0xFF;
      int br = b >> 16 & 0xFF;
      int bg = b >> 8 & 0xFF;
      int bb = b & 0xFF;
      int ba = b >> 24 & 0xFF;
      int r = (int)(ar + (br - ar) * t);
      int g = (int)(ag + (bg - ag) * t);
      int bl2 = (int)(ab + (bb - ab) * t);
      int al = (int)(aa + (ba - aa) * t);
      return packARGB(r, g, bl2, al);
   }

   private static int packARGB(int r, int g, int b, int a) {
      return MathHelper.clamp(a, 0, 255) << 24 | r << 16 | g << 8 | b;
   }

   private static int setAlpha(int color, int a) {
      return MathHelper.clamp(a, 0, 255) << 24 | color & 16777215;
   }

   private static int alpha(int color) {
      return color >> 24 & 0xFF;
   }

   private static int red(int color) {
      return color >> 16 & 0xFF;
   }

   private static int green(int color) {
      return color >> 8 & 0xFF;
   }

   private static int blue(int color) {
      return color & 0xFF;
   }

   private int applyPointAlpha(int color, float multiplier) {
      return setAlpha(color, Math.max(0, Math.min(255, (int)(alpha(color) * multiplier))));
   }

   private void vertex(BufferBuilder buffer, Matrix4f matrix, float x, float y, float z, int color) {
      buffer.vertex(matrix, x, y, z).color(red(color) / 255.0F, green(color) / 255.0F, blue(color) / 255.0F, alpha(color) / 255.0F);
   }

   private float resolveBodyYaw(PlayerEntity player, float tickDelta) {
      float target = MathHelper.lerpAngleDegrees(tickDelta, player.prevBodyYaw, player.bodyYaw);
      if (player != this.mc.player) {
         return target;
      } else if (this.selfBodyYawInitialized && player.age >= 2) {
         this.selfBodyYaw = approachDegrees(this.selfBodyYaw, target, 14.0F);
         return this.selfBodyYaw;
      } else {
         this.selfBodyYaw = target;
         this.selfBodyYawInitialized = true;
         return this.selfBodyYaw;
      }
   }

   private static float approachDegrees(float current, float target, float maxDelta) {
      float delta = MathHelper.wrapDegrees(target - current);
      delta = MathHelper.clamp(delta, -maxDelta, maxDelta);
      return current + delta;
   }

   private WingsModule.WingPose resolvePose(PlayerEntity player, float tickDelta) {
      float pitch = MathHelper.lerp(tickDelta, player.prevPitch, player.getPitch());
      if (player.isGliding()) {
         float flightTicks = player.getGlidingTicks() + tickDelta;
         float flightProgress = MathHelper.clamp(flightTicks * flightTicks / 100.0F, 0.0F, 1.0F);
         float pitchRotation = flightProgress * (-90.0F - pitch);
         return new WingsModule.WingPose(0.34F, 0.46F, 0.0F, 0.0F, pitchRotation, 0.0F, 0.76F, 0.92F, 0.1F, 12.0F, 0.05F, 0.06F, -5.0F, -2.0F, 0.16F);
      } else if (player.isTouchingWater()) {
         return null;
      } else {
         return player.isSneaking()
            ? new WingsModule.WingPose(0.0F, 0.0F, 0.96F, 0.12F, 22.0F, 0.0F, 1.0F, 1.0F, 10.0F, 14.5F, 0.06F, 0.02F, -9.0F, -4.0F, 0.14F)
            : new WingsModule.WingPose(0.0F, 0.0F, 1.36F, 0.12F, 0.0F, 0.0F, 1.0F, 1.0F, 12.0F, 14.5F, 0.06F, 0.02F, -9.0F, -4.0F, 0.14F);
      }
   }

   private boolean hasElytra(PlayerEntity player) {
      return player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
   }

   @Override
   public void onTick() {
   }

   @Environment(EnvType.CLIENT)
   private static final class WingPoint {
      final float x;
      final float y;
      final float alphaMul;

      WingPoint(float x, float y, float alphaMul) {
         this.x = x;
         this.y = y;
         this.alphaMul = alphaMul;
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class WingPose {
      final float preTranslateY;
      final float preTranslateZ;
      final float anchorY;
      final float anchorZ;
      final float pitchRotation;
      final float rollRotation;
      final float openMultiplier;
      final float scaleMultiplier;
      final float motionSpreadBoost;
      final float flapAmplitude;
      final float sideOffset;
      final float sideYOffset;
      final float sideZOffset;
      final float sideRoll;
      final float sidePitch;
      final float flapSpeed;

      WingPose(
         float preTranslateY,
         float preTranslateZ,
         float anchorY,
         float anchorZ,
         float pitchRotation,
         float rollRotation,
         float openMultiplier,
         float scaleMultiplier,
         float motionSpreadBoost,
         float flapAmplitude,
         float sideOffset,
         float sideZOffset,
         float sideRoll,
         float sidePitch,
         float flapSpeed
      ) {
         this.preTranslateY = preTranslateY;
         this.preTranslateZ = preTranslateZ;
         this.anchorY = anchorY;
         this.anchorZ = anchorZ;
         this.pitchRotation = pitchRotation;
         this.rollRotation = rollRotation;
         this.openMultiplier = openMultiplier;
         this.scaleMultiplier = scaleMultiplier;
         this.motionSpreadBoost = motionSpreadBoost;
         this.flapAmplitude = flapAmplitude;
         this.sideOffset = sideOffset;
         this.sideYOffset = 0.0F;
         this.sideZOffset = sideZOffset;
         this.sideRoll = sideRoll;
         this.sidePitch = sidePitch;
         this.flapSpeed = flapSpeed;
      }
   }
}
