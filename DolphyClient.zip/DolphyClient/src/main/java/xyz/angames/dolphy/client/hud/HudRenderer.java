package xyz.angames.dolphy.client.hud;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.modules.render.InterfaceModule;

@Environment(EnvType.CLIENT)
public class HudRenderer {
   private final LogoRenderer logoRenderer = new LogoRenderer();

   public LogoRenderer getLogoRenderer() {
      return this.logoRenderer;
   }

   public void render(DrawContext context, float tickDelta) {
      InterfaceModule interfaceMod = (InterfaceModule)DolphyClient.moduleManager.getModuleByName("Interface");
      if (interfaceMod != null && interfaceMod.isEnabled() && interfaceMod.logo.get()) {
         this.logoRenderer.render(context);
      }

      MinecraftClient client = MinecraftClient.getInstance();
      Module boyKisserModule = DolphyClient.moduleManager.getModuleByName("BoyKisser");
      if (boyKisserModule != null && boyKisserModule.isEnabled() && client.currentScreen == null) {
         DolphyClient.boyKisserManager.render(context, tickDelta);
      }
   }
}
