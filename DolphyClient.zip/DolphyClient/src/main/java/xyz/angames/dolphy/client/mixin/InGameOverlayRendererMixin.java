package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_1058;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.NoRenderModule;

@Mixin(class_4603.class)
public class InGameOverlayRendererMixin {
    @Inject(method = "method_23070", at = @At("HEAD"), cancellable = true)
    private static void onRenderFireOverlay(class_4587 matrices, class_4597 vertexConsumers, class_1058 sprite, CallbackInfo ci) {
        NoRenderModule mod = getModule();
        if (mod != null && mod.isEnabled() && mod.isNoFire()) {
            ci.cancel();
            return;
        }
        if (mod != null && mod.isEnabled() && mod.isLowFire()) {
            matrices.method_46416(0.0f, -mod.getLowFireOffset(), 0.0f);
        }
    }

    @Inject(method = "method_23069", at = @At("HEAD"), cancellable = true)
    private static void onRenderUnderwaterOverlay(net.minecraft.class_310 client, class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        NoRenderModule mod = getModule();
        if (mod != null && mod.isEnabled() && mod.isNoWaterOverlay()) {
            ci.cancel();
        }
    }

    @Inject(method = "method_23068", at = @At("HEAD"), cancellable = true)
    private static void onRenderInWallOverlay(class_1058 sprite, class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        NoRenderModule mod = getModule();
        if (mod != null && mod.isEnabled() && mod.isNoSuffocation()) {
            ci.cancel();
        }
    }

    private static NoRenderModule getModule() {
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return null;
        return DolphyClient.getInstance().getModuleManager().getModule(NoRenderModule.class);
    }
}
