package xyz.angames.dolphy.client.command.commands;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Formatting;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.command.Command;

@Environment(EnvType.CLIENT)
public class HelpCommand extends Command {
   public HelpCommand() {
      super("help", "Lists all commands", "$help");
   }

   @Override
   public void execute(String[] args) {
      sendMessage(Formatting.BOLD + "--- Available Commands ---");

      for (Command c : DolphyClient.commandManager.getCommands()) {
         sendMessage(Formatting.AQUA + c.getName() + Formatting.GRAY + ": " + c.getDescription());
         sendMessage(Formatting.DARK_GRAY + "  " + c.getSyntax());
      }
   }
}
