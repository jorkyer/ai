package xyz.angames.dolphy.client.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.compat.DolphyCompat;
import xyz.angames.dolphy.client.compat.WorldRenderContext;
import xyz.angames.dolphy.client.compat.WorldRenderEvents;
import xyz.angames.dolphy.client.module.modules.render.AmbientsModule;

@Mixin(class_761.class)
public class WorldRendererMixin {
    @Inject(method = "method_62200", at = @At("HEAD"), cancellable = true)
    private void onRenderSky(class_9922 frameGraphBuilder, class_4184 camera, GpuBufferSlice fogBuffer, CallbackInfo ci) {
        AmbientsModule ambients = DolphyClient.getInstance().getModuleManager().getModule(AmbientsModule.class);
        if (ambients != null && ambients.shouldOverrideSky()) {
            ci.cancel();
            DolphyCompat.pendingSkyOverride = true;
        }
    }

    @Inject(method = "method_22710", at = @At("HEAD"))
    private void onRenderHead(class_9922 allocator, class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, Matrix4f positionMatrix, Matrix4f projectionMatrix, Matrix4f frustumMatrix, GpuBufferSlice fogBuffer, Vector4f fogColor, boolean renderSky, CallbackInfo ci) {
        DolphyCompat.pendingSkyOverride = false;
        DolphyCompat.lastWorldPositionMatrix.set((Matrix4fc) positionMatrix);
        DolphyCompat.lastWorldProjectionMatrix.set((Matrix4fc) projectionMatrix);
        DolphyCompat.lastCamera = camera;
        DolphyCompat.lastTickCounter = tickCounter;
    }

    @Inject(method = "method_22710", at = @At("RETURN"))
    private void onRenderReturn(class_9922 allocator, class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, Matrix4f positionMatrix, Matrix4f projectionMatrix, Matrix4f frustumMatrix, GpuBufferSlice fogBuffer, Vector4f fogColor, boolean renderSky, CallbackInfo ci) {
        class_4587 matrices = new class_4587();
        matrices.method_23760().method_23761().set((Matrix4fc) positionMatrix);
        if (DolphyCompat.pendingSkyOverride) {
            DolphyCompat.pendingSkyOverride = false;
            AmbientsModule ambients = DolphyClient.getInstance().getModuleManager().getModule(AmbientsModule.class);
            if (ambients != null && ambients.shouldOverrideSky()) {
                float td = tickCounter != null ? tickCounter.method_60637(false) : 1.0f;
                ambients.renderCustomSky(matrices, projectionMatrix, td);
            }
        }
        WorldRenderContext ctx = new WorldRenderContext(matrices, tickCounter, camera, (class_761) (Object) this, projectionMatrix, positionMatrix);
        WorldRenderEvents.fireEnd(ctx);
    }
}
