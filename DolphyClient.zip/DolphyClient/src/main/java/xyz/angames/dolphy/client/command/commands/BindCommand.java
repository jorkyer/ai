package xyz.angames.dolphy.client.command.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Formatting;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.command.Command;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.util.KeyUtils;

@Environment(EnvType.CLIENT)
public class BindCommand extends Command {
   public BindCommand() {
      super("bind", "Manage keybinds for modules", "$bind <add | list | reset | clear> ...");
   }

   @Override
   public void execute(String[] args) {
      if (args.length < 1) {
         this.sendSyntax();
      } else {
         String action = args[0].toLowerCase();
         switch (action) {
            case "add":
               if (args.length != 3) {
                  this.sendError("Usage: $bind add <module | clickgui | hudeditor> <key>");
                  return;
               }

               String moduleName = args[1];
               String keyName = args[2].toUpperCase();
               int keyCode = KeyUtils.getKeyCode(keyName);
               if (keyCode == -1) {
                  this.sendError("Unknown key: " + keyName);
                  return;
               }

               this.setBind(moduleName, keyCode, keyName);
               break;
            case "list":
               sendMessage(Formatting.GOLD + "--- Key Binds ---");
               if (DolphyClient.clickGuiKeyCode != -1) {
                  sendMessage(Formatting.GRAY + "ClickGUI: " + Formatting.AQUA + KeyUtils.getKeyName(DolphyClient.clickGuiKeyCode));
               }

               if (DolphyClient.hudEditorKeyCode != -1) {
                  sendMessage(Formatting.GRAY + "HudEditor: " + Formatting.AQUA + KeyUtils.getKeyName(DolphyClient.hudEditorKeyCode));
               }

               DolphyClient.moduleManager
                  .getModules()
                  .stream()
                  .filter(m -> m.getKeyCode() != -1)
                  .forEach(m -> sendMessage(Formatting.GRAY + m.getName() + ": " + Formatting.AQUA + KeyUtils.getKeyName(m.getKeyCode())));
               break;
            case "reset":
               if (args.length != 2) {
                  this.sendError("Usage: $bind reset <module | clickgui | hudeditor>");
                  return;
               }

               this.setBind(args[1], -1, "NONE");
               break;
            case "clear":
               DolphyClient.moduleManager.getModules().forEach(m -> m.setKeyCode(-1));
               sendMessage(Formatting.GREEN + "Cleared all module keybinds! (ClickGUI and HudEditor were kept safe)");
               break;
            default:
               this.sendError("Unknown action: " + action);
         }
      }
   }

   private void setBind(String name, int key, String keyName) {
      boolean found = false;
      if (name.equalsIgnoreCase("clickgui")) {
         DolphyClient.clickGuiKeyCode = key;
         sendMessage(Formatting.GREEN + "Bound ClickGUI to " + (key == -1 ? "NONE" : keyName));
         found = true;
      } else if (name.equalsIgnoreCase("hudeditor")) {
         DolphyClient.hudEditorKeyCode = key;
         sendMessage(Formatting.GREEN + "Bound HudEditor to " + (key == -1 ? "NONE" : keyName));
         found = true;
      } else {
         Module module = DolphyClient.moduleManager.getModuleByName(name);
         if (module != null) {
            module.setKeyCode(key);
            sendMessage(Formatting.GREEN + "Bound " + module.getName() + " to " + (key == -1 ? "NONE" : keyName));
            found = true;
         } else {
            this.sendError("Module not found: " + name);
         }
      }
   }

   @Override
   public List<String> suggest(String[] args) {
      if (args.length == 1) {
         return List.of("add", "list", "reset", "clear");
      }

      if (args.length != 2 || !args[0].equalsIgnoreCase("add") && !args[0].equalsIgnoreCase("reset")) {
         if (args.length == 3 && args[0].equalsIgnoreCase("add")) {
            String prefix = args[2].toLowerCase();
            return KeyUtils.getKeyNames().stream().map(String::toLowerCase).filter(name -> name.startsWith(prefix) || name.contains(prefix)).sorted((a, b) -> {
               boolean aStarts = a.startsWith(prefix);
               boolean bStarts = b.startsWith(prefix);
               if (aStarts && !bStarts) {
                  return -1;
               } else {
                  return !aStarts && bStarts ? 1 : a.compareTo(b);
               }
            }).collect(Collectors.toList());
         } else {
            return super.suggest(args);
         }
      } else {
         List<String> suggestions = new ArrayList<>();
         suggestions.add("clickgui");
         suggestions.add("hudeditor");
         suggestions.addAll(DolphyClient.moduleManager.getModules().stream().map(Module::getName).map(String::toLowerCase).collect(Collectors.toList()));
         return suggestions;
      }
   }
}
