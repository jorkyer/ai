package xyz.angames.dolphy.client.effects;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.config.ThemeManager;
import xyz.angames.dolphy.client.module.Module;

@Environment(EnvType.CLIENT)
public class KillEffectRenderer {
   private final KillEffectManager manager;
   private static final Identifier BLOOM_TEXTURE = Identifier.of("dolphy", "textures/effects/bloom.png");
   private static final Identifier[] BLOOD_TEXTURES = new Identifier[]{
      Identifier.of("dolphy", "textures/effects/blood_0.png"),
      Identifier.of("dolphy", "textures/effects/blood_1.png"),
      Identifier.of("dolphy", "textures/effects/blood_2.png")
   };

   public KillEffectRenderer(KillEffectManager manager) {
      this.manager = manager;
   }

   public void render(WorldRenderContext context) {
      Module module = DolphyClient.moduleManager.getModuleByName("KillEffect");
      if (module != null && module.isEnabled()) {
         if (!this.manager.getEffects().isEmpty()) {
            long currentTime = System.currentTimeMillis();
            RenderSystem.enableBlend();
            RenderSystem.disableCull();
            Tessellator tessellator = Tessellator.getInstance();
            double camX = context.camera().getPos().x;
            double camY = context.camera().getPos().y;
            double camZ = context.camera().getPos().z;
            int rgb = ThemeManager.getThemedColor(0L);
            Color c = new Color(rgb);
            float r = c.getRed() / 255.0F;
            float g = c.getGreen() / 255.0F;
            float b = c.getBlue() / 255.0F;

            for (KillEffectManager.KillEffect effect : this.manager.getEffects()) {
               long age = currentTime - effect.startTime;
               long maxAge = "Blood".equals(effect.mode) ? KillEffectManager.BLOOD_LIFESPAN : KillEffectManager.LIFESPAN;
               if (age <= maxAge) {
                  MatrixStack matrices = context.matrixStack();
                  matrices.push();
                  matrices.translate(effect.pos.x - camX, effect.pos.y - camY, effect.pos.z - camZ);

                  if ("Blood".equals(effect.mode)) {
                     this.renderBloodEffect(context, matrices, tessellator, effect, age, maxAge);
                  } else {
                     float progress = (float)age / 3000.0F;
                     float globalAlpha = 1.0F - progress;
                     RenderSystem.disableDepthTest();
                     RenderSystem.depthMask(false);
                     RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);

                     if ("Zap".equals(effect.mode)) {
                        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
                        float zapAlpha = 1.0F - (float)age / 800.0F;
                        if (zapAlpha > 0.0F) {
                           BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);

                           for (int i = 0; i < effect.zapPoints.size() - 1; i++) {
                              Vec3d p1 = effect.zapPoints.get(i);
                              Vec3d p2 = effect.zapPoints.get(i + 1);
                              double distance = p1.distanceTo(p2);
                              int bubbles = (int)(distance / 0.25);

                              for (int j = 0; j <= bubbles; j++) {
                                 float lerp = (float)j / Math.max(1, bubbles);
                                 float bx = (float)(p1.x + (p2.x - p1.x) * lerp);
                                 float by = (float)(p1.y + (p2.y - p1.y) * lerp);
                                 float bz = (float)(p1.z + (p2.z - p1.z) * lerp);
                                 matrices.push();
                                 matrices.translate(bx, by, bz);
                                 matrices.multiply(context.camera().getRotation());
                                 float scale = 0.6F;
                                 matrices.scale(scale, scale, scale);
                                 this.drawBatchedGlowingDot(matrices.peek().getPositionMatrix(), buffer, r, g, b, zapAlpha);
                                 matrices.pop();
                              }
                           }

                           BufferRenderer.drawWithGlobalProgram(buffer.end());
                        }
                     } else if ("Thanos".equals(effect.mode)) {
                        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
                        RenderSystem.setShaderTexture(0, BLOOM_TEXTURE);
                        Quaternionf cameraRot = context.camera().getRotation();
                        BufferBuilder buffer = null;

                        for (KillEffectManager.ThanosParticle p : effect.thanosParticles) {
                           float currentY = p.startY;
                           float pAlpha = globalAlpha;
                           if ((float)age > p.delay) {
                              float fallTime = (float)age - p.delay;
                              currentY -= fallTime * p.fallSpeed;
                              if (currentY <= 0.0F) {
                                 currentY = 0.0F;
                                 pAlpha *= 0.6F;
                              }
                           }

                           if (!(pAlpha <= 0.05F)) {
                              if (buffer == null) {
                                 buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
                              }

                              matrices.push();
                              matrices.translate(p.startX, currentY, p.startZ);
                              matrices.multiply(cameraRot);
                              float pScale = 0.18F;
                              matrices.scale(pScale, pScale, pScale);
                              Matrix4f pMatrix = matrices.peek().getPositionMatrix();
                              buffer.vertex(pMatrix, -0.5F, -0.5F, 0.0F).texture(0.0F, 1.0F).color(1.0F, 1.0F, 1.0F, pAlpha);
                              buffer.vertex(pMatrix, 0.5F, -0.5F, 0.0F).texture(1.0F, 1.0F).color(1.0F, 1.0F, 1.0F, pAlpha);
                              buffer.vertex(pMatrix, 0.5F, 0.5F, 0.0F).texture(1.0F, 0.0F).color(1.0F, 1.0F, 1.0F, pAlpha);
                              buffer.vertex(pMatrix, -0.5F, 0.5F, 0.0F).texture(0.0F, 0.0F).color(1.0F, 1.0F, 1.0F, pAlpha);
                              matrices.pop();
                           }
                        }

                        if (buffer != null) {
                           BufferRenderer.drawWithGlobalProgram(buffer.end());
                        }
                     }
                  }

                  matrices.pop();
               }
            }

            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
         }
      }
   }

   private void renderBloodEffect(
      WorldRenderContext context,
      MatrixStack matrices,
      Tessellator tessellator,
      KillEffectManager.KillEffect effect,
      long age,
      long maxAge
   ) {
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

      float fadeOut = 1.0F;
      long fadeStart = maxAge - 1300L;
      if (age > fadeStart) {
         fadeOut = Math.max(0.0F, 1.0F - (float)(age - fadeStart) / 1300.0F);
      }
      if (fadeOut <= 0.01F) {
         return;
      }

      Quaternionf cameraRot = context.camera().getRotation();
      Matrix4f baseMat = matrices.peek().getPositionMatrix();

      // 1. Render airborne blood droplets during initial splash
      BufferBuilder airBuf = null;
      RenderSystem.setShaderTexture(0, BLOOD_TEXTURES[0]);
      for (int i = 0; i < effect.bloodDrops.size(); i++) {
         KillEffectManager.BloodDrop d = effect.bloodDrops.get(i);
         if ((float)age < d.flightMs) {
            float t = (float)age / Math.max(1.0F, d.flightMs);
            float curX = d.startX + (d.targetX - d.startX) * t;
            float curZ = d.startZ + (d.targetZ - d.startZ) * t;
            float linearY = d.startY + (d.groundYOffset + 0.02F - d.startY) * t;
            float arc = 4.0F * t * (1.0F - t) * d.arcHeight;
            float curY = linearY + arc;

            if (airBuf == null) {
               airBuf = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            }
            matrices.push();
            matrices.translate(curX, curY, curZ);
            matrices.multiply(cameraRot);
            float dropSize = 0.14F + 0.08F * (1.0F - t);
            matrices.scale(dropSize, dropSize, dropSize);
            Matrix4f m = matrices.peek().getPositionMatrix();
            float sh = d.shade;
            airBuf.vertex(m, -0.5F, -0.5F, 0.0F).texture(0.0F, 1.0F).color(sh, sh * 0.1F, sh * 0.1F, 0.95F * fadeOut);
            airBuf.vertex(m, 0.5F, -0.5F, 0.0F).texture(1.0F, 1.0F).color(sh, sh * 0.1F, sh * 0.1F, 0.95F * fadeOut);
            airBuf.vertex(m, 0.5F, 0.5F, 0.0F).texture(1.0F, 0.0F).color(sh, sh * 0.1F, sh * 0.1F, 0.95F * fadeOut);
            airBuf.vertex(m, -0.5F, 0.5F, 0.0F).texture(0.0F, 0.0F).color(sh, sh * 0.1F, sh * 0.1F, 0.95F * fadeOut);
            matrices.pop();
         }
      }
      if (airBuf != null) {
         BufferRenderer.drawWithGlobalProgram(airBuf.end());
      }

      // 2. Render ground blood puddles grouped by texture variant (0, 1, 2)
      for (int texIdx = 0; texIdx < BLOOD_TEXTURES.length; texIdx++) {
         RenderSystem.setShaderTexture(0, BLOOD_TEXTURES[texIdx]);
         BufferBuilder puddleBuf = null;

         for (int i = 0; i < effect.bloodDrops.size(); i++) {
            KillEffectManager.BloodDrop d = effect.bloodDrops.get(i);
            if (d.texIdx != texIdx || (float)age < d.flightMs) {
               continue;
            }
            float landedAge = (float)age - d.flightMs;
            float spreadAnim = Math.min(1.0F, landedAge / 150.0F);
            float easeSpread = 0.35F + 0.65F * (1.0F - (1.0F - spreadAnim) * (1.0F - spreadAnim));
            float rad = d.puddleRadius * easeSpread;

            if (puddleBuf == null) {
               puddleBuf = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            }

            float cos = (float)Math.cos(d.rotRad) * rad;
            float sin = (float)Math.sin(d.rotRad) * rad;
            float py = d.groundYOffset + 0.014F + i * 0.0004F;
            float cx = d.targetX;
            float cz = d.targetZ;
            float sh = d.shade;
            float a = 0.92F * fadeOut;

            puddleBuf.vertex(baseMat, cx - cos + sin, py, cz - sin - cos).texture(0.0F, 1.0F).color(sh, sh, sh, a);
            puddleBuf.vertex(baseMat, cx + cos + sin, py, cz + sin - cos).texture(1.0F, 1.0F).color(sh, sh, sh, a);
            puddleBuf.vertex(baseMat, cx + cos - sin, py, cz + sin + cos).texture(1.0F, 0.0F).color(sh, sh, sh, a);
            puddleBuf.vertex(baseMat, cx - cos - sin, py, cz - sin + cos).texture(0.0F, 0.0F).color(sh, sh, sh, a);
         }

         if (puddleBuf != null) {
            BufferRenderer.drawWithGlobalProgram(puddleBuf.end());
         }
      }
   }

   private void drawBatchedGlowingDot(Matrix4f matrix, BufferBuilder buffer, float r, float g, float b, float alpha) {
      for (int i = 0; i < 360; i += 30) {
         double rad1 = Math.toRadians(i);
         double rad2 = Math.toRadians(i + 30);
         float px1 = (float)Math.cos(rad1);
         float py1 = (float)Math.sin(rad1);
         float px2 = (float)Math.cos(rad2);
         float py2 = (float)Math.sin(rad2);
         buffer.vertex(matrix, 0.0F, 0.0F, 0.0F).color(1.0F, 1.0F, 1.0F, alpha);
         buffer.vertex(matrix, px1, py1, 0.0F).color(r, g, b, 0.0F);
         buffer.vertex(matrix, px2, py2, 0.0F).color(r, g, b, 0.0F);
      }
   }
}
