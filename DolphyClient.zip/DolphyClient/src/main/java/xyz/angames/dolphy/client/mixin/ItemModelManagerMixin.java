package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import xyz.angames.dolphy.client.module.modules.render.ItemReplacerModule;

@Mixin(class_10442.class)
public class ItemModelManagerMixin {
    @ModifyVariable(
        method = "method_65597",
        at = @At("HEAD"),
        argsOnly = true
    )
    private class_1799 modifyStackForLivingEntity(class_1799 stack, class_10444 renderState, class_1799 origStack, class_811 displayContext, class_1309 entity) {
        return ItemReplacerModule.replaceIfNeeded(stack, entity);
    }

    @ModifyVariable(
        method = "method_65596",
        at = @At("HEAD"),
        argsOnly = true
    )
    private class_1799 modifyStackForNonLiving(class_1799 stack, class_10444 renderState, class_1799 origStack, class_811 displayContext, class_1937 world, class_1309 entity, int seed) {
        return ItemReplacerModule.replaceIfNeeded(stack, entity);
    }
}
