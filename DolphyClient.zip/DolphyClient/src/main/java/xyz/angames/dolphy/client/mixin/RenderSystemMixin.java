package xyz.angames.dolphy.client.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Fog;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.config.ThemeManager;
import xyz.angames.dolphy.client.module.modules.render.AmbientsModule;

@Environment(EnvType.CLIENT)
@Mixin(RenderSystem.class)
public class RenderSystemMixin {
   @ModifyVariable(method = "setShaderFog", at = @At("HEAD"), argsOnly = true, ordinal = 0)
   private static Fog modifyFog(Fog originalFog) {
      if (DolphyClient.moduleManager == null) {
         return originalFog;
      }

      AmbientsModule ambients = (AmbientsModule)DolphyClient.moduleManager.getModuleByName("Ambients");
      if (ambients != null && ambients.isEnabled() && ambients.customFog.get()) {
         float start = originalFog.start();
         float end = originalFog.end();
         float r = originalFog.red();
         float g = originalFog.green();
         float b = originalFog.blue();
         float a = originalFog.alpha();
         start = (float)ambients.fogStart.get();
         end = (float)ambients.fogEnd.get();
         if (ambients.fogColorEnabled.get() && ambients.themeSync.get()) {
            float strength = (float)ambients.fogStrength.get();
            if (strength > 0.0F) {
               Color themeColor = new Color(ThemeManager.getThemedColor(0L));
               float fr = themeColor.getRed() / 255.0F;
               float fg = themeColor.getGreen() / 255.0F;
               float fb = themeColor.getBlue() / 255.0F;
               r = r * (1.0F - strength) + fr * strength;
               g = g * (1.0F - strength) + fg * strength;
               b = b * (1.0F - strength) + fb * strength;
            }
         }

         return new Fog(start, end, originalFog.shape(), r, g, b, a);
      } else {
         return originalFog;
      }
   }
}
