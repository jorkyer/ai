package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.NameTagsModule;

@Mixin(class_897.class)
public class EntityRendererMixin {
    @Inject(method = "method_3926", at = @At("HEAD"), cancellable = true)
    private void onRenderLabelIfPresent(class_10017 state, class_4587 matrices, class_11659 queue, class_12075 cameraState, CallbackInfo ci) {
        if (state == null || state.field_53337 == null) return;
        NameTagsModule nameTags = DolphyClient.getInstance().getModuleManager().getModule(NameTagsModule.class);
        if (nameTags != null && nameTags.isEnabled() && nameTags.isHideVanillaTags()) {
            ci.cancel();
        }
    }
}
