package xyz.angames.dolphy.client.compat;

import net.minecraft.class_332;
import net.minecraft.class_4587;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;

public class CompatMatrixStack extends class_4587 {
    private final class_332 context;

    public CompatMatrixStack(class_332 context) {
        super();
        this.context = context;
        syncFromContext();
    }

    @Override
    public void method_22903() {
        super.method_22903();
        if (context != null) {
            try {
                context.method_51448().pushMatrix();
                syncToContext();
            } catch (Throwable ignored) {}
        }
    }

    @Override
    public void method_22909() {
        if (!super.method_67795()) {
            super.method_22909();
        }
        if (context != null) {
            try {
                context.method_51448().popMatrix();
            } catch (Throwable ignored) {}
            syncToContext();
        }
    }

    @Override
    public void method_46416(float x, float y, float z) {
        super.method_46416(x, y, z);
        syncToContext();
    }

    @Override
    public void method_22904(double x, double y, double z) {
        this.method_46416((float) x, (float) y, (float) z);
    }

    @Override
    public void method_22905(float x, float y, float z) {
        super.method_22905(x, y, z);
        syncToContext();
    }

    @Override
    public void method_22907(Quaternionfc q) {
        super.method_22907(q);
        syncToContext();
    }

    public void method_22907(Quaternionf q) {
        super.method_22907((Quaternionfc) q);
        syncToContext();
    }

    @Override
    public void method_34426() {
        super.method_34426();
        syncToContext();
    }

    @Override
    public void method_34425(Matrix4fc m) {
        super.method_34425(m);
        syncToContext();
    }

    public void syncToContext() {
        if (context != null) {
            try {
                Matrix4f m4 = super.method_23760().method_23761();
                Matrix3x2fStack m2 = context.method_51448();
                m2.set(
                    m4.m00(), m4.m01(),
                    m4.m10(), m4.m11(),
                    m4.m30(), m4.m31()
                );
            } catch (Throwable ignored) {}
        }
    }

    public void syncFromContext() {
        if (context != null && super.method_67795()) {
            try {
                Matrix3x2fStack m2 = context.method_51448();
                super.method_23760().method_23761().set(
                    m2.m00, m2.m01, 0.0F, 0.0F,
                    m2.m10, m2.m11, 0.0F, 0.0F,
                    0.0F,   0.0F,   1.0F, 0.0F,
                    m2.m20, m2.m21, 0.0F, 1.0F
                );
            } catch (Throwable ignored) {}
        }
    }
}
