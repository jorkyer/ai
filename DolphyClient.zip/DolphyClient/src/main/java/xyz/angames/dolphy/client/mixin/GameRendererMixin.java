package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_11228;
import net.minecraft.class_11246;
import net.minecraft.class_1309;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_758;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.compat.DolphyCompat;
import xyz.angames.dolphy.client.module.modules.render.AspectRatioModule;
import xyz.angames.dolphy.client.module.modules.render.CustomFovModule;
import xyz.angames.dolphy.client.module.modules.render.NoRenderModule;
import xyz.angames.dolphy.client.module.modules.render.ZoomModule;

@Mixin(class_757.class)
public class GameRendererMixin {
    @Shadow
    @Final
    private class_11228 field_59965;

    @Shadow
    @Final
    private class_758 field_60793;

    @Shadow
    @Final
    private class_11246 field_59966;

    @Inject(method = "method_3192", at = @At("HEAD"))
    private void onRenderHead(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
        DolphyCompat.guiRendererInstance = this.field_59965;
        DolphyCompat.fogRendererInstance = this.field_60793;
        DolphyCompat.guiStateInstance = this.field_59966;
        DolphyCompat.guiStateDirty = true;
    }

    @Inject(method = "method_3196", at = @At("RETURN"), cancellable = true)
    private void onGetFov(class_4184 camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Float> cir) {
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return;
        float fov = cir.getReturnValue();
        boolean modified = false;
        CustomFovModule fovModule = DolphyClient.getInstance().getModuleManager().getModule(CustomFovModule.class);
        if (fovModule != null && fovModule.isEnabled()) {
            fov = fovModule.modifyFov(fov, changingFov);
            modified = true;
        }
        ZoomModule zoomModule = DolphyClient.getInstance().getModuleManager().getModule(ZoomModule.class);
        if (zoomModule != null) {
            float zoomMult = zoomModule.getZoomMultiplier();
            if (zoomMult < 0.999f) {
                fov *= zoomMult;
                modified = true;
            }
        }
        if (modified) {
            cir.setReturnValue(Math.max(1.0f, Math.min(179.0f, fov)));
        }
    }

    @Inject(method = "method_3198", at = @At("HEAD"), cancellable = true)
    private void onTiltViewWhenHurt(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return;
        NoRenderModule mod = DolphyClient.getInstance().getModuleManager().getModule(NoRenderModule.class);
        if (mod == null || !mod.isEnabled()) return;
        if (mod.isNoHurtCam()) {
            ci.cancel();
            return;
        }
        if (mod.isCustomHurtCam()) {
            ci.cancel();
            net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
            if (mc.method_1560() instanceof class_1309) {
                class_1309 livingEntity = (class_1309) mc.method_1560();
                float f = (float) livingEntity.field_6235 - tickDelta;
                if (livingEntity.method_29504()) {
                    float g = Math.min((float) livingEntity.field_6213 + tickDelta, 20.0f);
                    matrices.method_22907(class_7833.field_40718.rotationDegrees(40.0f - 8000.0f / (g + 200.0f)));
                }
                if (f < 0.0f) return;
                f /= (float) livingEntity.field_6254;
                f = class_3532.method_15374(f * f * f * f * (float) Math.PI);
                float g = livingEntity.method_6055();
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-g));
                float scale = mod.getHurtCamStrength();
                matrices.method_22907(class_7833.field_40718.rotationDegrees(-f * 14.0f * scale));
                matrices.method_22907(class_7833.field_40716.rotationDegrees(g));
            }
        }
    }

    @Inject(method = "method_3188", at = @At("HEAD"), cancellable = true)
    private void onBobView(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return;
        NoRenderModule mod = DolphyClient.getInstance().getModuleManager().getModule(NoRenderModule.class);
        if (mod != null && mod.isEnabled() && mod.isNoBobbing()) {
            ci.cancel();
        }
    }

    @Inject(method = "method_32796", at = @At("RETURN"), cancellable = true)
    private void onGetBasicProjectionMatrix(float fovDegrees, CallbackInfoReturnable<org.joml.Matrix4f> cir) {
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return;
        AspectRatioModule ar = DolphyClient.getInstance().getModuleManager().getModule(AspectRatioModule.class);
        if (ar != null && ar.isEnabled()) {
            float customAspect = ar.getAspectRatio();
            org.joml.Matrix4f mat = new org.joml.Matrix4f();
            mat.perspective((float) Math.toRadians(fovDegrees), customAspect, 0.05f, 4000.0f);
            cir.setReturnValue(mat);
        }
    }
}
