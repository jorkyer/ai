package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_10426;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5819;
import net.minecraft.class_7833;
import net.minecraft.class_916;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.ItemPhysicModule;

@Mixin(class_916.class)
public class ItemEntityRendererMixin {
    @Shadow
    @Final
    private class_5819 field_4725;

    @Inject(method = "method_3996(Lnet/minecraft/class_10426;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;Lnet/minecraft/class_12075;)V", at = @At("HEAD"), cancellable = true)
    private void onRender(class_10426 state, class_4587 matrices, class_11659 queue, class_12075 cameraState, CallbackInfo ci) {
        ItemPhysicModule mod = DolphyClient.getInstance().getModuleManager().getModule(ItemPhysicModule.class);
        if (mod == null || !mod.isEnabled()) return;
        if (state.field_55310.method_65605()) return;
        ci.cancel();

        matrices.method_22903();
        float age = state.field_53325;
        float seed = state.field_53450;
        float speed = mod.getRotateSpeed();
        boolean isOnGround = isLikelyOnGround(age);
        boolean is3D = state.field_55310.method_65606();

        if (mod.isFlatOnGround() && isOnGround) {
            if (is3D) {
                matrices.method_46416(0.0f, 0.1f, 0.0f);
                float yaw = (seed * 360.0f) % 360.0f;
                float tilt = (float) Math.sin(seed * 17.3f) * 15.0f;
                matrices.method_22907(class_7833.field_40716.rotationDegrees(yaw));
                matrices.method_22907(class_7833.field_40714.rotationDegrees(tilt));
            } else {
                matrices.method_46416(0.0f, 0.03f, 0.0f);
                matrices.method_22907(class_7833.field_40714.rotationDegrees(90.0f));
                float yaw = (seed * 360.0f) % 360.0f;
                matrices.method_22907(class_7833.field_40718.rotationDegrees(yaw));
            }
        } else {
            float spinX = (age * 18.0f * speed + seed * 360.0f) % 360.0f;
            float spinY = (age * 12.0f * speed + seed * 180.0f) % 360.0f;
            float spinZ = (age * 8.0f * speed + seed * 90.0f) % 360.0f;
            matrices.method_46416(0.0f, 0.15f, 0.0f);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(spinY));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(spinX));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(spinZ));
        }

        renderStack(matrices, queue, state.field_61820, state);
        matrices.method_22909();
    }

    private boolean isLikelyOnGround(float age) {
        return age > 6.0f;
    }

    private void renderStack(class_4587 matrices, class_11659 queue, int light, class_10426 state) {
        this.field_4725.method_43052(state.field_53451);
        int renderedAmount = state.field_53449;
        class_10444 itemRenderState = state.field_55310;
        boolean bl = itemRenderState.method_65606();
        float f = 0.25f;
        float g = 0.0f;
        float h = 0.0f;
        if (!bl) {
            float r = -0.0f * (float) (renderedAmount - 1) * 0.5f;
            float s = -0.0f * (float) (renderedAmount - 1) * 0.5f;
            float t = -0.09375f * (float) (renderedAmount - 1) * 0.5f;
            matrices.method_46416(r, s, t);
        }
        for (int u = 0; u < renderedAmount; ++u) {
            matrices.method_22903();
            if (u > 0) {
                if (bl) {
                    float s = (this.field_4725.method_43057() * 2.0f - 1.0f) * 0.15f;
                    float t = (this.field_4725.method_43057() * 2.0f - 1.0f) * 0.15f;
                    float v = (this.field_4725.method_43057() * 2.0f - 1.0f) * 0.15f;
                    matrices.method_46416(s, t, v);
                } else {
                    float s = (this.field_4725.method_43057() * 2.0f - 1.0f) * 0.15f * 0.5f;
                    float t = (this.field_4725.method_43057() * 2.0f - 1.0f) * 0.15f * 0.5f;
                    matrices.method_46416(s, t, 0.0f);
                }
            }
            itemRenderState.method_65604(matrices, queue, light, class_4608.field_21444, state.field_61821);
            matrices.method_22909();
            if (!bl) {
                matrices.method_46416(0.0f * f, 0.0f * g, 0.09375f);
            }
        }
    }
}
