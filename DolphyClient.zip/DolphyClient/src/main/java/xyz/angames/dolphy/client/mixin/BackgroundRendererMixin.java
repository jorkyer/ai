package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_758;
import net.minecraft.class_9779;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.AmbientsModule;

@Mixin(class_758.class)
public class BackgroundRendererMixin {
    @Inject(method = "method_71110", at = @At("RETURN"), cancellable = true)
    private void onGetFogColor(class_4184 camera, float tickDelta, class_638 world, int viewDistance, float skyDarkness, CallbackInfoReturnable<Vector4f> cir) {
        AmbientsModule ambients = DolphyClient.getInstance().getModuleManager().getModule(AmbientsModule.class);
        if (ambients != null && ambients.shouldOverrideFog()) {
            int col = ambients.getFogColorInt();
            float r = ((col >> 16) & 0xFF) / 255.0f;
            float g = ((col >> 8) & 0xFF) / 255.0f;
            float b = (col & 0xFF) / 255.0f;
            Vector4f orig = cir.getReturnValue();
            float a = orig != null ? orig.w : 1.0f;
            cir.setReturnValue(new Vector4f(r, g, b, a));
        }
    }

    @Inject(method = "method_71108", at = @At("HEAD"))
    private static void onSetupFog(class_4184 camera, int viewDistance, boolean thickFog, class_9779 tickCounter, float skyDarkness, class_638 world, CallbackInfoReturnable<?> cir) {
    }
}
