package xyz.angames.dolphy.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;
import net.minecraft.scoreboard.ScoreboardObjective;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.angames.dolphy.client.module.modules.misc.NameProtectModule;

@Environment(EnvType.CLIENT)
@Mixin(ScoreboardObjective.class)
public class ScoreboardObjectiveMixin {
   @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
   public void onGetDisplayName(CallbackInfoReturnable<Text> cir) {
      cir.setReturnValue(NameProtectModule.getProtectedText((Text)cir.getReturnValue()));
   }
}
