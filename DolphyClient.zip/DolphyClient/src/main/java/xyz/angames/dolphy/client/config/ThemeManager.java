package xyz.angames.dolphy.client.config;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.InterfaceModule;

@Environment(EnvType.CLIENT)
public class ThemeManager {
   private static Color themeColor = new Color(108, 195, 255);
   private static ThemeManager.Theme currentTheme = ThemeManager.Theme.IPHONE_GLASS;
   private static String lastSyncedInterfaceTheme = null;

   private static void syncFromInterfaceModule() {
      if (DolphyClient.moduleManager != null) {
         if (DolphyClient.moduleManager.getModuleByName("Interface") instanceof InterfaceModule ifaceMod && ifaceMod.colorTheme != null) {
            String selected = ifaceMod.colorTheme.get();
            if (selected != null && !selected.equals(lastSyncedInterfaceTheme)) {
               lastSyncedInterfaceTheme = selected;
               for (ThemeManager.Theme t : ThemeManager.Theme.values()) {
                  if (t.getName().equalsIgnoreCase(selected)) {
                     currentTheme = t;
                     break;
                  }
               }
            }
         }
      }
   }

   private static void syncToInterfaceModule(ThemeManager.Theme theme) {
      lastSyncedInterfaceTheme = theme.getName();
      if (DolphyClient.moduleManager != null) {
         if (DolphyClient.moduleManager.getModuleByName("Interface") instanceof InterfaceModule ifaceMod && ifaceMod.colorTheme != null) {
            if (!theme.getName().equalsIgnoreCase(ifaceMod.colorTheme.get())) {
               ifaceMod.colorTheme.set(theme.getName());
            }
         }
      }
   }

   public static ThemeManager.Theme getCurrentTheme() {
      syncFromInterfaceModule();
      return currentTheme;
   }

   public static void setCurrentTheme(ThemeManager.Theme theme) {
      setTheme(theme);
   }

   public static String getCustomColor1Hex() {
      Color c = getThemeColor();
      return String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
   }

   public static String getCustomColor2Hex() {
      Color c = getSecondaryColor();
      return String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
   }

   public static void setCustomColor(String hex) {
      if (hex != null) {
         try {
            String clean = hex.trim();
            if (!clean.startsWith("#")) {
               clean = "#" + clean;
            }
            setThemeColor(Color.decode(clean));
         } catch (Exception var2) {
         }
      }
   }

   public static void setCustomColors(String hex1, String hex2) {
      setCustomColor(hex1);
   }

   public static void setTheme(ThemeManager.Theme theme) {
      if (theme != null) {
         currentTheme = theme;
         syncToInterfaceModule(theme);
      }
   }

   public static void setThemeByName(String name) {
      if (name != null) {
         for (ThemeManager.Theme t : ThemeManager.Theme.values()) {
            if (t.getName().equalsIgnoreCase(name) || t.name().equalsIgnoreCase(name)) {
               setTheme(t);
               return;
            }
         }
      }
   }

   public static Color getThemeColor() {
      syncFromInterfaceModule();
      if (currentTheme == ThemeManager.Theme.CUSTOM) {
         return themeColor;
      }
      return new Color(getThemedColor(0L));
   }

   public static void setThemeColor(Color color) {
      if (color != null) {
         themeColor = color;
         currentTheme = ThemeManager.Theme.CUSTOM;
         syncToInterfaceModule(ThemeManager.Theme.CUSTOM);
      }
   }

   public static Color getPrimaryColor() {
      syncFromInterfaceModule();
      if (currentTheme == ThemeManager.Theme.CUSTOM) {
         return themeColor;
      }
      if (currentTheme == ThemeManager.Theme.CHROMA) {
         return new Color(getThemedColor(0L));
      }
      return currentTheme.getPrimary();
   }

   public static Color getSecondaryColor() {
      syncFromInterfaceModule();
      if (currentTheme == ThemeManager.Theme.CUSTOM) {
         float[] hsb = Color.RGBtoHSB(themeColor.getRed(), themeColor.getGreen(), themeColor.getBlue(), null);
         return Color.getHSBColor((hsb[0] + 0.06F) % 1.0F, Math.max(0.25F, hsb[1] * 0.85F), Math.min(1.0F, hsb[2] * 1.1F));
      }
      if (currentTheme == ThemeManager.Theme.CHROMA) {
         return new Color(getThemedColor(600L));
      }
      return currentTheme.getSecondary();
   }

   public static int getThemedColor(long offset) {
      syncFromInterfaceModule();
      long now = System.currentTimeMillis();
      if (currentTheme == ThemeManager.Theme.CHROMA) {
         float hue = (float)(((now / 14L + offset / 3L) % 360L) / 360.0);
         if (hue < 0.0F) {
            hue += 1.0F;
         }
         return Color.HSBtoRGB(hue, 0.75F, 1.0F);
      }

      Color c1 = getPrimaryColor();
      Color c2 = getSecondaryColor();
      double rad = (now / 12.0 + offset * 0.35) * (Math.PI / 180.0);
      float wave = (float)((Math.sin(rad) + 1.0) * 0.5);
      return interpolateColor(c1, c2, wave).getRGB();
   }

   public static Color interpolateColor(Color color1, Color color2, float factor) {
      factor = Math.max(0.0F, Math.min(1.0F, factor));
      int r = (int)(color1.getRed() + (color2.getRed() - color1.getRed()) * factor);
      int g = (int)(color1.getGreen() + (color2.getGreen() - color1.getGreen()) * factor);
      int b = (int)(color1.getBlue() + (color2.getBlue() - color1.getBlue()) * factor);
      int a = (int)(color1.getAlpha() + (color2.getAlpha() - color1.getAlpha()) * factor);
      return new Color(r, g, b, a);
   }

   @Environment(EnvType.CLIENT)
   public static enum Theme {
      IPHONE_GLASS("iPhone Glass", new Color(214, 244, 255), new Color(98, 190, 255)),
      DOLPHY("Dolphy Cyan", new Color(0, 242, 254), new Color(79, 172, 254)),
      SAKURA("Sakura Pink", new Color(255, 94, 158), new Color(255, 184, 222)),
      CYBER_VIOLET("Cyber Violet", new Color(183, 33, 255), new Color(33, 212, 253)),
      SUNSET_GOLD("Sunset Gold", new Color(255, 81, 47), new Color(240, 152, 25)),
      EMERALD_MINT("Emerald Mint", new Color(0, 255, 135), new Color(96, 239, 255)),
      CRIMSON_BLOOD("Crimson Red", new Color(255, 30, 86), new Color(255, 118, 142)),
      AMETHYST("Amethyst", new Color(196, 113, 237), new Color(120, 162, 255)),
      CHROMA("Chroma Wave", new Color(255, 95, 162), new Color(80, 220, 255)),
      CUSTOM("Custom", new Color(108, 195, 255), new Color(180, 225, 255));

      private final String name;
      private final Color primary;
      private final Color secondary;

      private Theme(String name, Color primary, Color secondary) {
         this.name = name;
         this.primary = primary;
         this.secondary = secondary;
      }

      public String getName() {
         return this.name;
      }

      public Color getPrimary() {
         return this.currentPrimary();
      }

      public Color getSecondary() {
         return this.currentSecondary();
      }

      private Color currentPrimary() {
         return this == CUSTOM ? ThemeManager.themeColor : this.primary;
      }

      private Color currentSecondary() {
         return this == CUSTOM ? ThemeManager.themeColor : this.secondary;
      }
   }
}
