package xyz.angames.dolphy.client.module.modules.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.setting.BooleanSetting;
import xyz.angames.dolphy.client.module.setting.ModeSetting;
import xyz.angames.dolphy.client.module.setting.NumberSetting;

@Environment(EnvType.CLIENT)
public class BandanaModule extends Module {
   public final ModeSetting colorMode = new ModeSetting("Color", "Theme", "Theme", "Lunar Red", "Chroma", "White", "Obsidian");
   public final BooleanSetting self = new BooleanSetting("Self", true);
   public final BooleanSetting friends = new BooleanSetting("Friends", true);
   public final NumberSetting waveSpeed = new NumberSetting("WaveSpeed", 1.0, 0.3, 2.5, 0.1);

   public BandanaModule() {
      super("Bandana", "Lunar Client 3D headband with physics cloth tails", Module.Category.COSMETIC);
      this.addSettings(this.colorMode, this.self, this.friends, this.waveSpeed);
   }
}
