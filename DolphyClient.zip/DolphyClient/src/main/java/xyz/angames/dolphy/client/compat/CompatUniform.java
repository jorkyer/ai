package xyz.angames.dolphy.client.compat;

import java.nio.FloatBuffer;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL20;

public class CompatUniform {
    public final String name;
    public final int programId;
    public final int location;
    private static final FloatBuffer MAT_BUF = BufferUtils.createFloatBuffer(16);

    public CompatUniform(String name, int programId, int location) {
        this.name = name;
        this.programId = programId;
        this.location = location;
    }

    private boolean bindProg() {
        if (location < 0 || programId <= 0) return false;
        GL20.glUseProgram(programId);
        return true;
    }

    public void method_1251(float v0) {
        if (bindProg()) GL20.glUniform1f(location, v0);
    }

    public void method_1252(float v0, float v1) {
        if (bindProg()) GL20.glUniform2f(location, v0, v1);
    }

    public void method_1255(float v0, float v1) {
        if (bindProg()) GL20.glUniform2f(location, v0, v1);
    }

    public void method_1253(float v0, float v1, float v2) {
        if (bindProg()) GL20.glUniform3f(location, v0, v1, v2);
    }

    public void method_1249(float v0, float v1, float v2) {
        if (bindProg()) GL20.glUniform3f(location, v0, v1, v2);
    }

    public void method_1254(float v0, float v1, float v2, float v3) {
        if (bindProg()) GL20.glUniform4f(location, v0, v1, v2, v3);
    }

    public void method_35652(float v0, float v1, float v2, float v3) {
        if (bindProg()) GL20.glUniform4f(location, v0, v1, v2, v3);
    }

    public void method_35657(float v0, float v1, float v2, float v3) {
        if (bindProg()) GL20.glUniform4f(location, v0, v1, v2, v3);
    }

    public void method_1248(int v0) {
        if (bindProg()) GL20.glUniform1i(location, v0);
    }

    public void method_35649(int v0) {
        if (bindProg()) GL20.glUniform1i(location, v0);
    }

    public void method_1255(float[] values) {
        if (!bindProg() || values == null) return;
        if (values.length == 1) GL20.glUniform1f(location, values[0]);
        else if (values.length == 2) GL20.glUniform2f(location, values[0], values[1]);
        else if (values.length == 3) GL20.glUniform3f(location, values[0], values[1], values[2]);
        else if (values.length >= 4) GL20.glUniform4f(location, values[0], values[1], values[2], values[3]);
    }

    public void method_1250(Matrix4f mat) {
        if (!bindProg() || mat == null) return;
        MAT_BUF.clear();
        mat.get(MAT_BUF);
        GL20.glUniformMatrix4fv(location, false, MAT_BUF);
    }
}
