package xyz.angames.dolphy.client.protection;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipFile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class ProtectionGuard {
   private static volatile boolean initialized = false;
   private static final String PUBLIC_KEY_B64 =
      "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEd/+qlBn3X31NnucXJvcoKaG2/cxTw95sO63HGIAthqf8Zkd7CvFDEj6i12KLvKeKhdYuIDD/I4wkFQaZQUGWpQ==";
   private static final long EPOCH_BASE_SEC = 1767225600L; // 2026-01-01 00:00:00 UTC

   private static final String[] FORBIDDEN_ARGS = new String[]{
      "-agentlib:jdwp",
      "-xdebug",
      "-xrunjdwp",
      "recaf",
      "byteman",
      "byte-buddy-agent",
      "classdumper",
      "jvmti",
      "slicer",
      "fernflower",
      "vineflower",
      "cfr-",
      "jadx"
   };

   private ProtectionGuard() {
   }

   public static void init() {
      if (initialized) {
         return;
      }
      initialized = true;
      verifyEnvironment();
      verifyLicenseOrSelfDestruct(false);
      setupEphemeralCleanup();

      Thread watchdog = new Thread(() -> {
         // Verify against true network UTC time in background thread on startup
         verifyLicenseOrSelfDestruct(true);
         int ticks = 0;
         while (true) {
            try {
               Thread.sleep(8000L);
               ticks++;
               verifyEnvironment();
               // Refresh network time every ~2 minutes, local+monotonic check every 8 seconds
               verifyLicenseOrSelfDestruct(ticks % 15 == 0);
            } catch (InterruptedException e) {
               return;
            } catch (Throwable ignored) {
            }
         }
      }, "Dolphy-Guard");
      watchdog.setDaemon(true);
      watchdog.start();
   }

   public static void verifyEnvironment() {
      try {
         List<String> args = ManagementFactory.getRuntimeMXBean().getInputArguments();
         for (String arg : args) {
            if (arg == null) {
               continue;
            }
            String lower = arg.toLowerCase(Locale.ROOT);
            for (String bad : FORBIDDEN_ARGS) {
               if (lower.contains(bad)) {
                  selfDestructAndHalt();
               }
            }
            if (lower.startsWith("-javaagent:") && !lower.contains("authlib-injector") && !lower.contains("fabric")) {
               selfDestructAndHalt();
            }
         }
      } catch (Throwable ignored) {
      }
   }

   public static void verifyLicenseOrSelfDestruct(boolean fetchNetworkTime) {
      try {
         String key = readEmbeddedOrSessionKey();
         if (key == null || key.isEmpty()) {
            selfDestructAndHalt();
            return;
         }
         String hwid = computeHwid();
         long nowMs = getAccurateTimeMillis(fetchNetworkTime);
         if (!isLicenseValid(key, hwid, nowMs)) {
            selfDestructAndHalt();
         }
      } catch (Throwable t) {
         selfDestructAndHalt();
      }
   }

   private static String readEmbeddedOrSessionKey() {
      // 1. Read from META-INF/.dolphy_auth stamped inside the injected mod JAR
      try (InputStream is = ProtectionGuard.class.getResourceAsStream("/META-INF/.dolphy_auth")) {
         if (is != null) {
            BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            String line = br.readLine();
            if (line != null && line.trim().startsWith("DLPH-")) {
               return line.trim();
            }
         }
      } catch (Throwable ignored) {
      }

      // 2. Fallback: read from .dolphy_session in working directory
      try {
         Path sessionFile = Path.of(".dolphy_session");
         if (Files.exists(sessionFile)) {
            List<String> lines = Files.readAllLines(sessionFile, StandardCharsets.UTF_8);
            if (!lines.isEmpty() && lines.get(0).trim().startsWith("DLPH-")) {
               return lines.get(0).trim();
            }
         }
      } catch (Throwable ignored) {
      }

      // 3. Fallback: read from ~/.dolphy_auth in user home
      try {
         Path homeAuth = Path.of(System.getProperty("user.home", "."), ".dolphy_auth");
         if (Files.exists(homeAuth)) {
            List<String> lines = Files.readAllLines(homeAuth, StandardCharsets.UTF_8);
            if (!lines.isEmpty() && lines.get(0).trim().startsWith("DLPH-")) {
               return lines.get(0).trim();
            }
         }
      } catch (Throwable ignored) {
      }
      return null;
   }

   public static boolean isLicenseValid(String key, String hwid, long nowMs) {
      try {
         if (key == null) return false;
         String k = key.trim();
         String[] parts = k.split("-", 4);
         if (parts.length != 4 || !"DLPH".equalsIgnoreCase(parts[0])) {
            return false;
         }

         String type = parts[1].toUpperCase(Locale.ROOT);
         String expHex = parts[2].toUpperCase(Locale.ROOT);
         String sigB64 = parts[3];
         String cleanHwid = hwid.trim().toUpperCase(Locale.ROOT);

         byte[] pubBytes = Base64.getDecoder().decode(PUBLIC_KEY_B64);
         PublicKey pubKey = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(pubBytes));
         Signature verifier = Signature.getInstance("SHA256withECDSA");
         verifier.initVerify(pubKey);
         String payload = cleanHwid + ":" + type + ":" + expHex;
         verifier.update(payload.getBytes(StandardCharsets.UTF_8));
         byte[] sigBytes = Base64.getUrlDecoder().decode(sigB64);

         if (!verifier.verify(sigBytes)) {
            return false;
         }

         if ("LT".equals(type) || "FFFFFFFF".equals(expHex)) {
            return true;
         }

         long expOffsetSec = Long.parseUnsignedLong(expHex, 16);
         long expEpochSec = EPOCH_BASE_SEC + expOffsetSec;
         long nowSec = nowMs / 1000L;
         return nowSec <= expEpochSec;
      } catch (Throwable t) {
         return false;
      }
   }

   public static long getAccurateTimeMillis(boolean queryNetwork) {
      long localNow = System.currentTimeMillis();
      long bestTime = localNow;
      Path clkFile = Path.of(System.getProperty("user.home", "."), ".dolphy_clk");

      try {
         if (Files.exists(clkFile)) {
            String raw = Files.readString(clkFile, StandardCharsets.UTF_8).trim();
            long saved = Long.parseLong(raw);
            if (saved > bestTime) {
               bestTime = saved;
            }
         }
      } catch (Throwable ignored) {
      }

      if (queryNetwork) {
         long netTime = fetchNetworkTimeMillis();
         if (netTime > 1700000000000L) {
            bestTime = Math.max(bestTime, netTime);
         }
      }

      try {
         Files.writeString(clkFile, Long.toString(bestTime), StandardCharsets.UTF_8);
      } catch (Throwable ignored) {
      }
      return bestTime;
   }

   private static long fetchNetworkTimeMillis() {
      String[] urls = new String[]{"https://www.google.com", "https://cloudflare.com"};
      for (String u : urls) {
         try {
            HttpURLConnection conn = (HttpURLConnection) new URL(u).openConnection();
            conn.setRequestMethod("HEAD");
            conn.setConnectTimeout(2500);
            conn.setReadTimeout(2500);
            conn.connect();
            long date = conn.getDate();
            conn.disconnect();
            if (date > 1700000000000L) {
               return date;
            }
         } catch (Throwable ignored) {
         }
      }
      return 0L;
   }

   private static void setupEphemeralCleanup() {
      Runtime.getRuntime().addShutdownHook(new Thread(() -> {
         try {
            spawnDelayedJarDeletion();
         } catch (Throwable ignored) {
         }
      }));
   }

   private static void selfDestructAndHalt() {
      try {
         spawnDelayedJarDeletion();
      } catch (Throwable ignored) {
      }
      Runtime.getRuntime().halt(0);
   }

   private static void spawnDelayedJarDeletion() {
      List<File> targets = new ArrayList<>();

      // 1. Check ~/.dolphy_auth and .dolphy_session for recorded target path
      try {
         Path homeAuth = Path.of(System.getProperty("user.home", "."), ".dolphy_auth");
         if (Files.exists(homeAuth)) {
            List<String> lines = Files.readAllLines(homeAuth, StandardCharsets.UTF_8);
            if (lines.size() >= 2) {
               targets.add(new File(lines.get(1).trim()));
            }
            Files.deleteIfExists(homeAuth);
         }
      } catch (Throwable ignored) {
      }

      try {
         Path sessionFile = Path.of(".dolphy_session");
         if (Files.exists(sessionFile)) {
            List<String> lines = Files.readAllLines(sessionFile, StandardCharsets.UTF_8);
            if (lines.size() >= 2) {
               targets.add(new File(lines.get(1).trim()));
            }
            Files.deleteIfExists(sessionFile);
         }
      } catch (Throwable ignored) {
      }

      // 2. Check ProtectionDomain CodeSource location
      try {
         URL loc = ProtectionGuard.class.getProtectionDomain().getCodeSource().getLocation();
         if (loc != null) {
            String s = loc.toString();
            if (s.startsWith("jar:file:")) {
               int bang = s.indexOf("!");
               if (bang > 0) s = s.substring(4, bang);
            }
            if (s.startsWith("file:")) {
               File f = new File(URI.create(s));
               if (f.isFile() && f.getName().endsWith(".jar")) {
                  targets.add(f);
               }
            }
         }
      } catch (Throwable ignored) {
      }

      // 3. Scan ./mods directory for any jar containing DolphyClient
      try {
         File modsDir = new File("mods");
         if (modsDir.isDirectory()) {
            File[] files = modsDir.listFiles();
            if (files != null) {
               for (File f : files) {
                  if (f.isFile() && f.getName().toLowerCase(Locale.ROOT).endsWith(".jar")) {
                     if (f.getName().toLowerCase(Locale.ROOT).contains("dolphy")) {
                        targets.add(f);
                     } else {
                        try (ZipFile zf = new ZipFile(f)) {
                           if (zf.getEntry("xyz/angames/dolphy/client/DolphyClient.class") != null) {
                              targets.add(f);
                           }
                        } catch (Throwable ignored) {
                        }
                     }
                  }
               }
            }
         }
      } catch (Throwable ignored) {
      }

      boolean isWin = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
      for (File target : targets) {
         if (target == null) continue;
         String abs = target.getAbsolutePath();
         try {
            target.delete();
            target.deleteOnExit();
         } catch (Throwable ignored) {
         }
         try {
            if (isWin) {
               new ProcessBuilder("cmd.exe", "/c", "ping 127.0.0.1 -n 3 > nul & del /f /q \"" + abs + "\"")
                  .directory(new File(System.getProperty("user.home", ".")))
                  .start();
            } else {
               new ProcessBuilder("sh", "-c", "sleep 2 && rm -f \"" + abs + "\"")
                  .directory(new File(System.getProperty("user.home", ".")))
                  .start();
            }
         } catch (Throwable ignored) {
         }
      }
   }

   public static String computeHwid() {
      try {
         String raw = System.getProperty("os.name", "")
            + "|"
            + System.getProperty("os.arch", "")
            + "|"
            + System.getProperty("user.name", "")
            + "|"
            + System.getenv("PROCESSOR_IDENTIFIER")
            + "|"
            + Runtime.getRuntime().availableProcessors();
         MessageDigest md = MessageDigest.getInstance("SHA-256");
         byte[] digest = md.digest(raw.getBytes(StandardCharsets.UTF_8));
         StringBuilder sb = new StringBuilder();
         for (int i = 0; i < 8; i++) {
            sb.append(String.format("%02X", digest[i] & 0xFF));
            if (i == 3) {
               sb.append("-");
            }
         }
         return sb.toString();
      } catch (Exception e) {
         return "DOLPHY-0000";
      }
   }
}
