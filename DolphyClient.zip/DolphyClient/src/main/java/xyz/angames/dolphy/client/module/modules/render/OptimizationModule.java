package xyz.angames.dolphy.client.module.modules.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleType;
import net.minecraft.particle.ParticleTypes;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.setting.BooleanSetting;
import xyz.angames.dolphy.client.module.setting.NumberSetting;

@Environment(EnvType.CLIENT)
public class OptimizationModule extends Module {
   private static OptimizationModule instance;

   public final BooleanSetting cullFarParticles = new BooleanSetting("Cull Far Particles", true);
   public final NumberSetting particleDistance = new NumberSetting("Particle Max Dist", 24.0, 8.0, 64.0, 2.0);
   public final BooleanSetting noExplosionParticles = new BooleanSetting("No Explosion Lag", true);
   public final BooleanSetting noWeatherParticles = new BooleanSetting("No Weather Splash", true);
   public final BooleanSetting noSmokeParticles = new BooleanSetting("No Heavy Smoke", true);
   public final BooleanSetting noPotionParticles = new BooleanSetting("No Potion Swirls", false);
   public final BooleanSetting limitEntityDist = new BooleanSetting("Boost Entity Cull", true);
   public final NumberSetting entityScale = new NumberSetting("Entity Dist %", 75.0, 50.0, 150.0, 5.0);
   public final BooleanSetting unfocusedFps = new BooleanSetting("Unfocused FPS Saver", true);
   public final NumberSetting unfocusedLimit = new NumberSetting("Unfocused Max FPS", 20.0, 10.0, 60.0, 5.0);
   public final BooleanSetting autoMemoryClean = new BooleanSetting("Smart RAM Cleaner", true);

   private int savedMaxFps = -1;
   private double savedEntityScale = -1.0;
   private long lastGcCheckMs = 0L;

   public OptimizationModule() {
      super("Optimization", "Increases FPS by culling heavy particles, distant entities, and background GPU load.", Module.Category.RENDER);
      this.addSetting(this.cullFarParticles);
      this.addSetting(this.particleDistance);
      this.addSetting(this.noExplosionParticles);
      this.addSetting(this.noWeatherParticles);
      this.addSetting(this.noSmokeParticles);
      this.addSetting(this.noPotionParticles);
      this.addSetting(this.limitEntityDist);
      this.addSetting(this.entityScale);
      this.addSetting(this.unfocusedFps);
      this.addSetting(this.unfocusedLimit);
      this.addSetting(this.autoMemoryClean);
      instance = this;
      this.setEnabled(true);
   }

   public static OptimizationModule getInstance() {
      return instance;
   }

   public boolean shouldSkipParticle(ParticleEffect effect, double x, double y, double z) {
      if (!this.isEnabled() || effect == null) {
         return false;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (this.cullFarParticles.get() && mc != null && mc.player != null) {
         double maxDist = this.particleDistance.get();
         double dx = x - mc.player.getX();
         double dy = y - mc.player.getY();
         double dz = z - mc.player.getZ();
         if (dx * dx + dy * dy + dz * dz > maxDist * maxDist) {
            return true;
         }
      }

      ParticleType<?> type = effect.getType();
      if (this.noExplosionParticles.get()
         && (type == ParticleTypes.EXPLOSION
            || type == ParticleTypes.EXPLOSION_EMITTER
            || type == ParticleTypes.POOF
            || type == ParticleTypes.FLASH)) {
         return true;
      }
      if (this.noWeatherParticles.get()
         && (type == ParticleTypes.RAIN
            || type == ParticleTypes.SPLASH
            || type == ParticleTypes.FALLING_WATER
            || type == ParticleTypes.DRIPPING_WATER)) {
         return true;
      }
      if (this.noSmokeParticles.get()
         && (type == ParticleTypes.LARGE_SMOKE
            || type == ParticleTypes.SMOKE
            || type == ParticleTypes.CAMPFIRE_COSY_SMOKE
            || type == ParticleTypes.CAMPFIRE_SIGNAL_SMOKE
            || type == ParticleTypes.ASH
            || type == ParticleTypes.WHITE_ASH)) {
         return true;
      }
      if (this.noPotionParticles.get()
         && (type == ParticleTypes.ENTITY_EFFECT
            || type == ParticleTypes.EFFECT
            || type == ParticleTypes.INSTANT_EFFECT)) {
         return true;
      }
      return false;
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.options == null) {
         return;
      }

      if (this.unfocusedFps.get()) {
         boolean focused = mc.isWindowFocused();
         int currentCap = mc.options.getMaxFps().getValue();
         int limit = (int)Math.round(this.unfocusedLimit.get());
         if (!focused) {
            if (this.savedMaxFps == -1 && currentCap > limit) {
               this.savedMaxFps = currentCap;
               mc.options.getMaxFps().setValue(limit);
            }
         } else if (this.savedMaxFps != -1) {
            mc.options.getMaxFps().setValue(this.savedMaxFps);
            this.savedMaxFps = -1;
         }
      }

      if (this.limitEntityDist.get()) {
         if (this.savedEntityScale < 0.0) {
            this.savedEntityScale = mc.options.getEntityDistanceScaling().getValue();
         }
         double targetScale = Math.max(0.5, Math.min(1.5, this.entityScale.get() / 100.0));
         if (Math.abs(mc.options.getEntityDistanceScaling().getValue() - targetScale) > 0.04) {
            mc.options.getEntityDistanceScaling().setValue(targetScale);
         }
      }

      if (this.autoMemoryClean.get()) {
         long now = System.currentTimeMillis();
         if (now - this.lastGcCheckMs > 45000L) {
            this.lastGcCheckMs = now;
            Runtime rt = Runtime.getRuntime();
            long max = rt.maxMemory();
            long used = rt.totalMemory() - rt.freeMemory();
            if (max > 0L && (double)used / (double)max > 0.86) {
               System.gc();
            }
         }
      }
   }

   @Override
   public void onDisable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc != null && mc.options != null) {
         if (this.savedMaxFps != -1) {
            mc.options.getMaxFps().setValue(this.savedMaxFps);
            this.savedMaxFps = -1;
         }
         if (this.savedEntityScale > 0.0) {
            mc.options.getEntityDistanceScaling().setValue(this.savedEntityScale);
            this.savedEntityScale = -1.0;
         }
      }
   }
}
