package xyz.angames.dolphy.client.module.modules.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.Identifier;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.setting.BooleanSetting;
import xyz.angames.dolphy.client.module.setting.ModeSetting;

@Environment(EnvType.CLIENT)
public class CapeModule extends Module {
   public static CapeModule INSTANCE;
   private static final Identifier DOLPHY_CAPE = Identifier.of("dolphy", "textures/dolphy_cape.png");
   private static final Identifier LUNAR_CAPE = Identifier.of("dolphy", "textures/lunar_cape.png");
   private static final Identifier CRIMSON_CAPE = Identifier.of("dolphy", "textures/crimson_cape.png");
   private static final Identifier CLASSIC_CAPE = Identifier.of("dolphy", "textures/cape.png");

   public final ModeSetting style = new ModeSetting("Style", "Dolphy", "Dolphy", "Lunar Galaxy", "Crimson", "Classic");
   public final BooleanSetting self = new BooleanSetting("Self", true);
   public final BooleanSetting friends = new BooleanSetting("Friends", true);

   public CapeModule() {
      super("Capes", "Lunar Client custom capes (Dolphy, Lunar Galaxy, Crimson)", Module.Category.COSMETIC);
      INSTANCE = this;
      this.addSettings(this.style, this.self, this.friends);
      this.setEnabled(true);
   }

   public Identifier getCapeTexture() {
      String mode = this.style.get();
      if ("Lunar Galaxy".equalsIgnoreCase(mode)) {
         return LUNAR_CAPE;
      } else if ("Crimson".equalsIgnoreCase(mode)) {
         return CRIMSON_CAPE;
      } else if ("Classic".equalsIgnoreCase(mode)) {
         return CLASSIC_CAPE;
      } else {
         return DOLPHY_CAPE;
      }
   }
}
