package xyz.angames.dolphy.client.compat;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.lwjgl.opengl.GL20;

public class CompatShader {
    private static final String MRE_COMMON_GLSL =
        "float rdist(vec2 pos, vec2 size, vec4 radius) {\n" +
        "    radius.xy = (pos.x > 0.0) ? radius.xy : radius.wz;\n" +
        "    radius.x  = (pos.y > 0.0) ? radius.x : radius.y;\n" +
        "    float r = min(radius.x, min(size.x, size.y));\n" +
        "    vec2 v = abs(pos) - size + r;\n" +
        "    return min(max(v.x, v.y), 0.0) + length(max(v, 0.0)) - r;\n" +
        "}\n" +
        "float ralpha(vec2 size, vec2 coord, vec4 radius, float smoothness) {\n" +
        "    vec2 center = size * 0.5;\n" +
        "    float dist = rdist(center - (coord * size), center - 1.0, radius);\n" +
        "    return 1.0 - smoothstep(1.0 - smoothness, 1.0, dist);\n" +
        "}\n" +
        "const vec2 RECT_VERTICES_COORDS[4] = vec2[4](\n" +
        "    vec2(0.0, 0.0),\n" +
        "    vec2(0.0, 1.0),\n" +
        "    vec2(1.0, 1.0),\n" +
        "    vec2(1.0, 0.0)\n" +
        ");\n" +
        "vec2 rvertexcoord(int id) {\n" +
        "    return RECT_VERTICES_COORDS[id % 4];\n" +
        "}\n";

    private static final Pattern MOJ_IMPORT_PATTERN =
        Pattern.compile("(?m)^\\s*#\\s*moj_import\\s+(?:<([^>]+)>|\"([^\"]+)\")\\s*$");

    public final String name;
    public int programId;
    public final Map<String, CompatUniform> uniforms = new HashMap<>();

    public CompatShader(String name) {
        this.name = name;
        this.programId = compileShaderByName(name);
    }

    public void ensureCompiled() {
        if (this.programId <= 0) {
            this.programId = compileShaderByName(this.name);
            this.uniforms.clear();
        }
    }

    public CompatUniform method_34582(String uniformName) {
        if (uniformName == null) {
            return new CompatUniform("", programId, -1);
        }
        CompatUniform u = uniforms.get(uniformName);
        if (u != null) return u;
        int loc = programId > 0 ? GL20.glGetUniformLocation(programId, uniformName) : -1;
        u = new CompatUniform(uniformName, programId, loc);
        if (programId > 0) {
            uniforms.put(uniformName, u);
        }
        return u;
    }

    public Map<String, CompatUniform> getUniformsMap() {
        return uniforms;
    }

    private static int compileShaderByName(String idStr) {
        String vertSrc = null;
        String fragSrc = null;

        if ("position".equals(idStr) || idStr.endsWith(":core/position")) {
            vertSrc = "#version 150\nin vec3 Position;\nuniform mat4 ModelViewMat;\nuniform mat4 ProjMat;\nvoid main() {\n    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);\n}\n";
            fragSrc = "#version 150\nuniform vec4 ColorModulator;\nout vec4 fragColor;\nvoid main() {\n    fragColor = ColorModulator;\n}\n";
        } else if ("position_color".equals(idStr) || idStr.endsWith(":core/position_color") || "rendertype_lines".equals(idStr) || idStr.endsWith(":core/rendertype_lines")) {
            vertSrc = "#version 150\nin vec3 Position;\nin vec4 Color;\nuniform mat4 ModelViewMat;\nuniform mat4 ProjMat;\nout vec4 vertexColor;\nvoid main() {\n    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);\n    vertexColor = Color;\n}\n";
            fragSrc = "#version 150\nin vec4 vertexColor;\nuniform vec4 ColorModulator;\nout vec4 fragColor;\nvoid main() {\n    vec4 color = vertexColor;\n    if (color.a == 0.0) discard;\n    fragColor = color * ColorModulator;\n}\n";
        } else if ("position_tex".equals(idStr) || idStr.endsWith(":core/position_tex")) {
            vertSrc = "#version 150\nin vec3 Position;\nin vec2 UV0;\nuniform mat4 ModelViewMat;\nuniform mat4 ProjMat;\nout vec2 texCoord0;\nvoid main() {\n    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);\n    texCoord0 = UV0;\n}\n";
            fragSrc = "#version 150\nuniform sampler2D Sampler0;\nuniform vec4 ColorModulator;\nin vec2 texCoord0;\nout vec4 fragColor;\nvoid main() {\n    vec4 color = texture(Sampler0, texCoord0);\n    if (color.a == 0.0) discard;\n    fragColor = color * ColorModulator;\n}\n";
        } else if ("position_tex_color".equals(idStr) || idStr.endsWith(":core/position_tex_color")) {
            vertSrc = "#version 150\nin vec3 Position;\nin vec2 UV0;\nin vec4 Color;\nuniform mat4 ModelViewMat;\nuniform mat4 ProjMat;\nout vec2 texCoord0;\nout vec4 vertexColor;\nvoid main() {\n    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);\n    texCoord0 = UV0;\n    vertexColor = Color;\n}\n";
            fragSrc = "#version 150\nuniform sampler2D Sampler0;\nuniform vec4 ColorModulator;\nin vec2 texCoord0;\nin vec4 vertexColor;\nout vec4 fragColor;\nvoid main() {\n    vec4 color = texture(Sampler0, texCoord0) * vertexColor;\n    if (color.a == 0.0) discard;\n    fragColor = color * ColorModulator;\n}\n";
        } else {
            try {
                class_2960 loc = idStr.contains(":") ? class_2960.method_60654(idStr) : class_2960.method_60655("minecraft", idStr);
                String ns = loc.method_12836();
                String path = loc.method_12832();
                String jsonStr = readResourceText(ns, "shaders/" + path + ".json");
                if (jsonStr == null && !path.startsWith("core/")) {
                    jsonStr = readResourceText(ns, "shaders/core/" + path + ".json");
                }
                String vRef = ns + ":" + path;
                String fRef = ns + ":" + path;
                if (jsonStr != null) {
                    String vMatch = extractJsonField(jsonStr, "vertex");
                    String fMatch = extractJsonField(jsonStr, "fragment");
                    if (vMatch != null) vRef = vMatch;
                    if (fMatch != null) fRef = fMatch;
                }
                vertSrc = readShaderSource(vRef, ".vsh");
                fragSrc = readShaderSource(fRef, ".fsh");
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }

        if (vertSrc == null || fragSrc == null) {
            vertSrc = "#version 150\nin vec3 Position;\nin vec2 UV0;\nin vec4 Color;\nuniform mat4 ModelViewMat;\nuniform mat4 ProjMat;\nout vec2 texCoord0;\nout vec4 vertexColor;\nvoid main() {\n    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);\n    texCoord0 = UV0;\n    vertexColor = Color;\n}\n";
            fragSrc = "#version 150\nin vec2 texCoord0;\nin vec4 vertexColor;\nuniform vec4 ColorModulator;\nout vec4 fragColor;\nvoid main() {\n    fragColor = vertexColor * ColorModulator;\n}\n";
        }

        int vs = compileStage(GL20.GL_VERTEX_SHADER, vertSrc, idStr + ".vsh");
        int fs = compileStage(GL20.GL_FRAGMENT_SHADER, fragSrc, idStr + ".fsh");
        if (vs <= 0 || fs <= 0) return 0;

        int prog = GL20.glCreateProgram();
        GL20.glAttachShader(prog, vs);
        GL20.glAttachShader(prog, fs);
        GL20.glBindAttribLocation(prog, 0, "Position");
        GL20.glBindAttribLocation(prog, 1, "UV0");
        GL20.glBindAttribLocation(prog, 2, "Color");
        GL20.glBindAttribLocation(prog, 3, "Normal");
        GL20.glLinkProgram(prog);
        GL20.glDeleteShader(vs);
        GL20.glDeleteShader(fs);
        if (GL20.glGetProgrami(prog, GL20.GL_LINK_STATUS) == 0) {
            System.err.println("[DolphyCompat] Link failed for " + idStr + ": " + GL20.glGetProgramInfoLog(prog, 4096));
            GL20.glDeleteProgram(prog);
            return 0;
        }
        return prog;
    }

    private static int compileStage(int type, String src, String label) {
        int s = GL20.glCreateShader(type);
        GL20.glShaderSource(s, src);
        GL20.glCompileShader(s);
        if (GL20.glGetShaderi(s, GL20.GL_COMPILE_STATUS) == 0) {
            System.err.println("[DolphyCompat] Compile failed for " + label + ": " + GL20.glGetShaderInfoLog(s, 4096));
            GL20.glDeleteShader(s);
            return 0;
        }
        return s;
    }

    private static String extractJsonField(String json, String key) {
        Matcher m = Pattern.compile("\"" + key + "\"\\s*:\\s*\"([^\"]+)\"").matcher(json);
        return m.find() ? m.group(1) : null;
    }

    private static String readShaderSource(String ref, String ext) {
        String ns = "minecraft";
        String path = ref;
        int idx = ref.indexOf(':');
        if (idx >= 0) {
            ns = ref.substring(0, idx);
            path = ref.substring(idx + 1);
        }
        String text = readResourceText(ns, "shaders/" + path + ext);
        if (text == null && !path.startsWith("core/")) {
            text = readResourceText(ns, "shaders/core/" + path + ext);
        }
        if (text == null) return null;
        return preprocessShader(text, ns, 0);
    }

    private static String preprocessShader(String src, String defaultNs, int depth) {
        if (src == null || depth > 8) return src;
        Matcher m = MOJ_IMPORT_PATTERN.matcher(src);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String target = m.group(1) != null ? m.group(1).trim() : m.group(2).trim();
            String incNs = defaultNs;
            String incPath = target;
            int colon = target.indexOf(':');
            if (colon >= 0) {
                incNs = target.substring(0, colon);
                incPath = target.substring(colon + 1);
            }
            String incContent = null;
            if ("mre".equals(incNs) && "common.glsl".equals(incPath)) {
                incContent = MRE_COMMON_GLSL;
            } else {
                incContent = readResourceText(incNs, "shaders/include/" + incPath);
                if (incContent == null) {
                    incContent = readResourceText(incNs, "shaders/" + incPath);
                }
            }
            if (incContent == null) {
                incContent = "";
            } else {
                incContent = preprocessShader(incContent, incNs, depth + 1);
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(incContent));
        }
        m.appendTail(sb);
        String out = sb.toString();
        out = out.replace("const vec2[4] RECT_VERTICES_COORDS = vec2[] (", "const vec2 RECT_VERTICES_COORDS[4] = vec2[4](");
        out = out.replace("const vec2 DIRS[8] = vec2[](", "const vec2 DIRS[8] = vec2[8](");
        return out;
    }

    private static String readResourceText(String ns, String path) {
        String full = "/assets/" + ns + "/" + path;
        try (InputStream in = CompatShader.class.getResourceAsStream(full)) {
            if (in != null) {
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Throwable ignored) {}
        try {
            ClassLoader cl = Thread.currentThread().getContextClassLoader();
            if (cl != null) {
                try (InputStream in = cl.getResourceAsStream("assets/" + ns + "/" + path)) {
                    if (in != null) {
                        return new String(in.readAllBytes(), StandardCharsets.UTF_8);
                    }
                }
            }
        } catch (Throwable ignored) {}
        try {
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.method_1478() != null) {
                var opt = mc.method_1478().method_14486(class_2960.method_60655(ns, path));
                if (opt.isPresent()) {
                    try (InputStream in = opt.get().method_14482()) {
                        return new String(in.readAllBytes(), StandardCharsets.UTF_8);
                    }
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }
}
