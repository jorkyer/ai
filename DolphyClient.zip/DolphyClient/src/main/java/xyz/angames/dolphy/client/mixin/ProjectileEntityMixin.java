package xyz.angames.dolphy.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.Module;

@Environment(EnvType.CLIENT)
@Mixin(ProjectileEntity.class)
public class ProjectileEntityMixin {
   @Inject(method = "onEntityHit", at = @At("HEAD"))
   private void onEntityHit(EntityHitResult entityHitResult, CallbackInfo ci) {
      ProjectileEntity self = (ProjectileEntity)(Object)this;
      if (self.getOwner() == MinecraftClient.getInstance().player) {
         Entity target = entityHitResult.getEntity();
         if (DolphyClient.killEffectManager != null) {
            Module mod = DolphyClient.moduleManager.getModuleByName("KillEffect");
            if (mod != null && mod.isEnabled()) {
               DolphyClient.killEffectManager.onAttack(target);
            }
         }
      }
   }
}
