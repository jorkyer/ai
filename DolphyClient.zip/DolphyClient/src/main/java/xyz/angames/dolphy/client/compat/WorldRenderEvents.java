package xyz.angames.dolphy.client.compat;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_4597;

public final class WorldRenderEvents {
    public static final Event<BeforeEntities> BEFORE_ENTITIES = EventFactory.createArrayBacked(
        BeforeEntities.class,
        callbacks -> context -> {
            for (BeforeEntities cb : callbacks) {
                cb.beforeEntities(context);
            }
        }
    );

    public static final Event<AfterEntities> AFTER_ENTITIES = EventFactory.createArrayBacked(
        AfterEntities.class,
        callbacks -> context -> {
            for (AfterEntities cb : callbacks) {
                cb.afterEntities(context);
            }
        }
    );

    public static final Event<AfterTranslucent> AFTER_TRANSLUCENT = EventFactory.createArrayBacked(
        AfterTranslucent.class,
        callbacks -> context -> {
            for (AfterTranslucent cb : callbacks) {
                cb.afterTranslucent(context);
            }
        }
    );

    public static final Event<Last> LAST = EventFactory.createArrayBacked(
        Last.class,
        callbacks -> context -> {
            for (Last cb : callbacks) {
                cb.onLast(context);
            }
        }
    );

    public static void fireEnd(WorldRenderContext compatCtx) {
        if (compatCtx == null) return;
        DolphyCompat.worldViewMat.set(compatCtx.matrixStack().method_23760().method_23761());
        if (compatCtx.projectionMatrix() != null) {
            DolphyCompat.worldProjMat.set(compatCtx.projectionMatrix());
        }
        DolphyCompat.beginWorldRender();
        try {
            DolphyCompat.flushDeferredWorldRender();
            BEFORE_ENTITIES.invoker().beforeEntities(compatCtx);
            AFTER_ENTITIES.invoker().afterEntities(compatCtx);
            AFTER_TRANSLUCENT.invoker().afterTranslucent(compatCtx);
            LAST.invoker().onLast(compatCtx);
            if (compatCtx.consumers() instanceof class_4597.class_4598) {
                ((class_4597.class_4598) compatCtx.consumers()).method_22993();
            }
        } catch (Throwable ignored) {
        } finally {
            DolphyCompat.endWorldRender();
        }
    }

    @FunctionalInterface
    public interface BeforeEntities {
        void beforeEntities(WorldRenderContext context);
    }

    @FunctionalInterface
    public interface AfterEntities {
        void afterEntities(WorldRenderContext context);
    }

    @FunctionalInterface
    public interface AfterTranslucent {
        void afterTranslucent(WorldRenderContext context);
    }

    @FunctionalInterface
    public interface Last {
        void onLast(WorldRenderContext context);
    }
}
