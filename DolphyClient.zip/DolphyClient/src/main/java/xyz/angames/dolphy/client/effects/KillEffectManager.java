package xyz.angames.dolphy.client.effects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.KillEffectModule;

@Environment(EnvType.CLIENT)
public class KillEffectManager {
   public static final long LIFESPAN = 3000L;
   public static final long BLOOD_LIFESPAN = 5500L;
   private final List<KillEffectManager.KillEffect> effects = new CopyOnWriteArrayList<>();
   private final Map<Integer, KillEffectManager.TrackedTarget> recentAttacks = new ConcurrentHashMap<>();
   private final MinecraftClient client = MinecraftClient.getInstance();

   public void onAttack(Entity target) {
      if (target instanceof LivingEntity living) {
         this.recentAttacks.put(target.getId(), new KillEffectManager.TrackedTarget(living));
      }
   }

   public void tick() {
      if (this.client.world != null && this.client.player != null) {
         long now = System.currentTimeMillis();

         for (Entry<Integer, KillEffectManager.TrackedTarget> entry : this.recentAttacks.entrySet()) {
            int id = entry.getKey();
            KillEffectManager.TrackedTarget tracked = entry.getValue();
            if (now - tracked.lastHitTime > 10000L) {
               this.recentAttacks.remove(id);
            } else {
               Entity currentEntity = this.client.world.getEntityById(id);
               boolean isKilled = false;
               Vec3d deathPos = tracked.lastPos;
               Box deathBox = tracked.lastBox;
               if (currentEntity == null) {
                  isKilled = true;
               } else if (currentEntity instanceof LivingEntity living) {
                  Vec3d currentPos = living.getPos();
                  if (living.isDead() || living.getHealth() <= 0.0F || living.deathTime > 0 || !living.isAlive()) {
                     isKilled = true;
                     deathPos = currentPos;
                     deathBox = living.getBoundingBox();
                  } else if (currentPos.squaredDistanceTo(tracked.lastPos) > 400.0) {
                     isKilled = true;
                  }

                  if (!isKilled) {
                     tracked.lastPos = currentPos;
                     tracked.lastBox = living.getBoundingBox();
                  }
               }

               if (isKilled) {
                  KillEffectModule mod = (KillEffectModule)DolphyClient.moduleManager.getModuleByName("KillEffect");
                  String mode = mod != null ? mod.mode.get() : "Blood";
                  this.effects.add(new KillEffectManager.KillEffect(deathPos, deathBox, mode, now));
                  this.recentAttacks.remove(id);
               }
            }
         }

         this.effects.removeIf(e -> {
            long maxAge = "Blood".equals(e.mode) ? BLOOD_LIFESPAN : LIFESPAN;
            return now - e.startTime > maxAge;
         });
      } else {
         this.effects.clear();
         this.recentAttacks.clear();
      }
   }

   public List<KillEffectManager.KillEffect> getEffects() {
      return this.effects;
   }

   private static float findGroundYOffset(Vec3d origin, float offsetX, float offsetZ) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.world == null) {
         return 0.0F;
      }
      double wx = origin.x + offsetX;
      double wz = origin.z + offsetZ;
      int baseBlockY = (int)Math.floor(origin.y + 0.5);
      for (int dy = 1; dy >= -4; dy--) {
         BlockPos bp = BlockPos.ofFloored(wx, baseBlockY + dy, wz);
         BlockState state = mc.world.getBlockState(bp);
         if (!state.isAir()) {
            VoxelShape shape = state.getCollisionShape(mc.world, bp);
            if (!shape.isEmpty()) {
               double topY = bp.getY() + shape.getMax(net.minecraft.util.math.Direction.Axis.Y);
               return (float)(topY - origin.y);
            }
         }
      }
      return 0.0F;
   }

   @Environment(EnvType.CLIENT)
   public static class KillEffect {
      public final Vec3d pos;
      public final String mode;
      public final long startTime;
      public final List<Vec3d> zapPoints = new ArrayList<>();
      public final List<KillEffectManager.ThanosParticle> thanosParticles = new ArrayList<>();
      public final List<KillEffectManager.BloodDrop> bloodDrops = new ArrayList<>();

      public KillEffect(Vec3d pos, Box box, String mode, long startTime) {
         this.pos = pos;
         this.mode = mode;
         this.startTime = startTime;
         float width = box != null ? (float)(box.maxX - box.minX) : 0.6F;
         float height = box != null ? (float)(box.maxY - box.minY) : 1.8F;

         if ("Zap".equals(mode)) {
            float currentX = 0.0F;
            float currentZ = 0.0F;
            this.zapPoints.add(new Vec3d(0.0, 0.0, 0.0));

            for (float y = 1.0F + (float)Math.random() * 1.5F; y <= 20.0F; y = (float)(y + (1.0 + Math.random() * 1.5))) {
               currentX = (float)(currentX + (Math.random() - 0.5) * 3.5);
               currentZ = (float)(currentZ + (Math.random() - 0.5) * 3.5);
               this.zapPoints.add(new Vec3d(currentX, y, currentZ));
            }
         } else if ("Thanos".equals(mode)) {
            for (int i = 0; i < 500; i++) {
               KillEffectManager.ThanosParticle p = new KillEffectManager.ThanosParticle();
               p.startX = (float)((Math.random() - 0.5) * width);
               p.startY = (float)(Math.random() * height);
               p.startZ = (float)((Math.random() - 0.5) * width);
               p.fallSpeed = (float)(0.001 + Math.random() * 0.003);
               p.delay = (float)(Math.random() * 1200.0);
               this.thanosParticles.add(p);
            }
         } else if ("Blood".equals(mode)) {
            int dropCount = 26;
            for (int i = 0; i < dropCount; i++) {
               KillEffectManager.BloodDrop drop = new KillEffectManager.BloodDrop();
               drop.startX = (float)((Math.random() - 0.5) * width * 0.55);
               drop.startY = 0.35F + (float)(Math.random() * Math.max(0.5F, height * 0.75F));
               drop.startZ = (float)((Math.random() - 0.5) * width * 0.55);

               double angle = Math.random() * Math.PI * 2.0;
               float dist = i < 4
                  ? (float)(Math.random() * 0.55)
                  : (float)(0.25 + Math.pow(Math.random(), 0.85) * 2.15);
               drop.targetX = (float)(Math.cos(angle) * dist);
               drop.targetZ = (float)(Math.sin(angle) * dist);
               drop.groundYOffset = findGroundYOffset(pos, drop.targetX, drop.targetZ);
               drop.flightMs = 110.0F + (float)(Math.random() * 280.0);
               drop.arcHeight = 0.15F + (float)(Math.random() * 0.55);
               drop.puddleRadius = i < 5
                  ? 0.42F + (float)(Math.random() * 0.36)
                  : 0.16F + (float)(Math.random() * 0.34);
               drop.rotRad = (float)(Math.random() * Math.PI * 2.0);
               drop.texIdx = i % 3;
               drop.shade = 0.78F + (float)(Math.random() * 0.22);
               this.bloodDrops.add(drop);
            }
         }
      }
   }

   @Environment(EnvType.CLIENT)
   public static class ThanosParticle {
      public float startX;
      public float startY;
      public float startZ;
      public float fallSpeed;
      public float delay;
   }

   @Environment(EnvType.CLIENT)
   public static class BloodDrop {
      public float startX;
      public float startY;
      public float startZ;
      public float targetX;
      public float targetZ;
      public float groundYOffset;
      public float flightMs;
      public float arcHeight;
      public float puddleRadius;
      public float rotRad;
      public int texIdx;
      public float shade;
   }

   @Environment(EnvType.CLIENT)
   private static class TrackedTarget {
      public Vec3d lastPos;
      public Box lastBox;
      public final long lastHitTime;

      public TrackedTarget(LivingEntity entity) {
         this.lastPos = entity.getPos();
         this.lastBox = entity.getBoundingBox();
         this.lastHitTime = System.currentTimeMillis();
      }
   }
}
