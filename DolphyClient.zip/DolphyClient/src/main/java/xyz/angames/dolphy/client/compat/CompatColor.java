package xyz.angames.dolphy.client.compat;

import java.awt.Color;
import java.awt.color.ColorSpace;

public class CompatColor extends Color {
    private static int clamp(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }

    private static float clampF(float v) {
        if (Float.isNaN(v)) return 0.0F;
        return v < 0.0F ? 0.0F : (v > 1.0F ? 1.0F : v);
    }

    public CompatColor(int r, int g, int b) {
        super(clamp(r), clamp(g), clamp(b));
    }

    public CompatColor(int r, int g, int b, int a) {
        super(clamp(r), clamp(g), clamp(b), clamp(a));
    }

    public CompatColor(int rgb) {
        super(rgb);
    }

    public CompatColor(int rgba, boolean hasalpha) {
        super(rgba, hasalpha);
    }

    public CompatColor(float r, float g, float b) {
        super(clampF(r), clampF(g), clampF(b));
    }

    public CompatColor(float r, float g, float b, float a) {
        super(clampF(r), clampF(g), clampF(b), clampF(a));
    }

    public CompatColor(ColorSpace cspace, float[] components, float alpha) {
        super(cspace, components, clampF(alpha));
    }
}
