package xyz.angames.dolphy.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.particle.Particle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.OptimizationModule;
import xyz.angames.dolphy.client.module.modules.render.ParticlesModule;

@Environment(EnvType.CLIENT)
@Mixin(ParticleManager.class)
public class MinecraftParticleManagerMixin {
   @Unique
   private static long dolphy$lastTotemPopTime = 0L;

   @Inject(method = "addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V", at = @At("HEAD"), cancellable = true)
   private void onAddEmitter(Entity entity, ParticleEffect parameters, int maxAge, CallbackInfo ci) {
      if (parameters != null
         && parameters.getType() == ParticleTypes.TOTEM_OF_UNDYING
         && (DolphyClient.moduleManager != null && DolphyClient.moduleManager.getModuleByName("Particles") instanceof ParticlesModule && ((ParticlesModule)DolphyClient.moduleManager.getModuleByName("Particles")).isEnabled() && ((ParticlesModule)DolphyClient.moduleManager.getModuleByName("Particles")).totemPop.get())) {
         long now = System.currentTimeMillis();
         if (now - dolphy$lastTotemPopTime > 40L) {
            dolphy$lastTotemPopTime = now;
            if (DolphyClient.particleManager != null && entity != null) {
               Vec3d pos = entity.getPos().add(0.0, entity.getHeight() * 0.5, 0.0);
               DolphyClient.particleManager.addTotemPop(pos);
            }
         }

         ci.cancel();
      }
   }

   @Inject(method = "addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;)V", at = @At("HEAD"), cancellable = true)
   private void onAddEmitterShort(Entity entity, ParticleEffect parameters, CallbackInfo ci) {
      if (parameters != null
         && parameters.getType() == ParticleTypes.TOTEM_OF_UNDYING
         && (DolphyClient.moduleManager != null && DolphyClient.moduleManager.getModuleByName("Particles") instanceof ParticlesModule && ((ParticlesModule)DolphyClient.moduleManager.getModuleByName("Particles")).isEnabled() && ((ParticlesModule)DolphyClient.moduleManager.getModuleByName("Particles")).totemPop.get())) {
         long now = System.currentTimeMillis();
         if (now - dolphy$lastTotemPopTime > 40L) {
            dolphy$lastTotemPopTime = now;
            if (DolphyClient.particleManager != null && entity != null) {
               Vec3d pos = entity.getPos().add(0.0, entity.getHeight() * 0.5, 0.0);
               DolphyClient.particleManager.addTotemPop(pos);
            }
         }

         ci.cancel();
      }
   }

   @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;", at = @At("HEAD"), cancellable = true)
   private void onAddParticle(
      ParticleEffect parameters, double x, double y, double z, double velocityX, double velocityY, double velocityZ, CallbackInfoReturnable<Particle> cir
   ) {
      if (!Double.isNaN(x)
         && !Double.isNaN(y)
         && !Double.isNaN(z)
         && !Double.isInfinite(x)
         && !Double.isInfinite(y)
         && !Double.isInfinite(z)
         && !Double.isNaN(velocityX)
         && !Double.isNaN(velocityY)
         && !Double.isNaN(velocityZ)
         && !Double.isInfinite(velocityX)
         && !Double.isInfinite(velocityY)
         && !Double.isInfinite(velocityZ)
         && !(Math.abs(x) > 3.0E7)
         && !(Math.abs(y) > 3.0E7)
         && !(Math.abs(z) > 3.0E7)) {
         OptimizationModule opt = OptimizationModule.getInstance();
         if (opt != null && opt.shouldSkipParticle(parameters, x, y, z)) {
            cir.setReturnValue(null);
            return;
         }
         if (parameters != null
            && parameters.getType() == ParticleTypes.TOTEM_OF_UNDYING
            && (DolphyClient.moduleManager != null && DolphyClient.moduleManager.getModuleByName("Particles") instanceof ParticlesModule && ((ParticlesModule)DolphyClient.moduleManager.getModuleByName("Particles")).isEnabled() && ((ParticlesModule)DolphyClient.moduleManager.getModuleByName("Particles")).totemPop.get())) {
            cir.setReturnValue(null);
         }
      } else {
         cir.setReturnValue(null);
      }
   }
}
