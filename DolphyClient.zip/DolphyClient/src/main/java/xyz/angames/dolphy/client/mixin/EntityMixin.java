package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.FreeLookModule;

@Mixin(class_1297.class)
public class EntityMixin {
    @Inject(method = "method_5872", at = @At("HEAD"), cancellable = true)
    private void onChangeLookDirection(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        if ((Object) this != class_310.method_1551().field_1724) return;
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return;
        FreeLookModule freeLook = DolphyClient.getInstance().getModuleManager().getModule(FreeLookModule.class);
        if (freeLook == null || !freeLook.isEnabled()) return;
        if (!freeLook.isFreeLooking()) {
            if (freeLook.isToggleMode()) return;
            if (!freeLook.isKeyDown()) return;
            class_746 player = class_310.method_1551().field_1724;
            if (player != null) {
                freeLook.startFreeLook(player.method_36454(), player.method_36455());
            }
        }
        freeLook.onCameraLook(cursorDeltaX, cursorDeltaY);
        ci.cancel();
    }
}
