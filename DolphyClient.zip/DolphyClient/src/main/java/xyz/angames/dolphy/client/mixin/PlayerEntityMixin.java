package xyz.angames.dolphy.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.TargetEspModule;
import xyz.angames.dolphy.client.module.modules.render.HitGlowModule;
import xyz.angames.dolphy.client.util.TargetUtils;

@Environment(EnvType.CLIENT)
@Mixin(PlayerEntity.class)
public class PlayerEntityMixin {
   @Inject(method = "attack", at = @At("HEAD"))
   private void onAttack(Entity target, CallbackInfo ci) {
      if ((Object)this == MinecraftClient.getInstance().player && target instanceof LivingEntity livingTarget) {
         if (!TargetUtils.isInvisible(livingTarget)) {
            TargetEspModule.addTargetAttack(target);
            if (DolphyClient.targetHudManager != null) {
               DolphyClient.targetHudManager.setTarget(livingTarget);
            }
         }

         HitGlowModule.addWave(target.getPos());
         if (DolphyClient.particleManager != null) {
            DolphyClient.particleManager.addEffects(target.getEyePos());
         }
      }
   }
}
