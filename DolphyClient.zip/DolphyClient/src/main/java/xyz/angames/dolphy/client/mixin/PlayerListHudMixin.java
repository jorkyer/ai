package xyz.angames.dolphy.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.angames.dolphy.client.module.modules.misc.NameProtectModule;

@Environment(EnvType.CLIENT)
@Mixin(PlayerListHud.class)
public class PlayerListHudMixin {
   @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
   public void onGetPlayerName(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
      Text originalText = (Text)cir.getReturnValue();
      if (originalText != null) {
         cir.setReturnValue(NameProtectModule.getProtectedText(originalText));
      } else {
         String originalStr = entry.getProfile().getName();
         String protectedStr = NameProtectModule.getProtectedName(originalStr);
         if (!originalStr.equals(protectedStr)) {
            cir.setReturnValue(Text.literal(protectedStr));
         }
      }
   }
}
