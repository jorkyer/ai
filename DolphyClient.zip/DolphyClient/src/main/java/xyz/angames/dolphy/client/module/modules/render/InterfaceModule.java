package xyz.angames.dolphy.client.module.modules.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.setting.BooleanSetting;
import xyz.angames.dolphy.client.module.setting.ModeSetting;
import xyz.angames.dolphy.client.module.setting.NumberSetting;

@Environment(EnvType.CLIENT)
public class InterfaceModule extends Module {
   public final ModeSetting colorTheme = new ModeSetting(
      "Theme",
      "iPhone Glass",
      "iPhone Glass",
      "Dolphy Cyan",
      "Sakura Pink",
      "Cyber Violet",
      "Sunset Gold",
      "Emerald Mint",
      "Crimson Red",
      "Amethyst",
      "Chroma Wave",
      "Custom"
   );
   public final ModeSetting hudStyle = new ModeSetting(
      "HUD Style",
      "iPhone Liquid Glass",
      "iPhone Liquid Glass",
      "iPhone Frosted",
      "Theme Translucent",
      "Solid Dark"
   );
   public final NumberSetting glassOpacity = new NumberSetting("Glass Opacity", 0.18, 0.05, 0.85, 0.02);
   public final NumberSetting glassBlur = new NumberSetting("Glass Blur", 10.0, 0.0, 24.0, 0.5);
   public final NumberSetting glassRefraction = new NumberSetting("Glass Refraction", 0.055, 0.0, 0.15, 0.005);

   public final BooleanSetting targetHud = new BooleanSetting("Target HUD", false);
   public final BooleanSetting effectHud = new BooleanSetting("Effect HUD", false);
   public final BooleanSetting inventoryHud = new BooleanSetting("Inventory HUD", false);
   public final BooleanSetting arrayList = new BooleanSetting("Array List", false);
   public final BooleanSetting armorHud = new BooleanSetting("Armor HUD", false);
   public final BooleanSetting musicHud = new BooleanSetting("Music HUD", false);
   public final BooleanSetting infoHud = new BooleanSetting("Info HUD", false);
   public final BooleanSetting logo = new BooleanSetting("WaterMark", false);
   public final BooleanSetting activeBinds = new BooleanSetting("Active Binds", false);
   public final BooleanSetting liquidGlassHud = new BooleanSetting("LiquidGlass HUD", true);

   public InterfaceModule() {
      super("Interface", "Manages HUD elements, color themes, and iPhone Liquid Glass transparency.", Module.Category.RENDER);
      this.addSetting(this.colorTheme);
      this.addSetting(this.hudStyle);
      this.addSetting(this.glassOpacity);
      this.addSetting(this.glassBlur);
      this.addSetting(this.glassRefraction);
      this.addSetting(this.targetHud);
      this.addSetting(this.effectHud);
      this.addSetting(this.inventoryHud);
      this.addSetting(this.arrayList);
      this.addSetting(this.armorHud);
      this.addSetting(this.musicHud);
      this.addSetting(this.infoHud);
      this.addSetting(this.logo);
      this.addSetting(this.activeBinds);
      this.addSetting(this.liquidGlassHud);
   }
}
