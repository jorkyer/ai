package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_7833;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.BabyBoyModule;
import xyz.angames.dolphy.client.module.modules.render.SpinBotModule;
import xyz.angames.dolphy.client.render.ChinaHatFeatureRenderer;

@Mixin(class_1007.class)
public abstract class PlayerEntityRendererMixin extends class_922<class_11890, class_10055, class_591> {
    protected PlayerEntityRendererMixin(class_5617.class_5618 ctx, class_591 model, float shadowRadius) {
        super(ctx, model, shadowRadius);
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInit(class_5617.class_5618 ctx, boolean slim, CallbackInfo ci) {
        this.method_4046(new ChinaHatFeatureRenderer(this));
    }

    @Inject(method = "method_62604(Lnet/minecraft/class_11890;Lnet/minecraft/class_10055;F)V", at = @At("TAIL"))
    private void onUpdateRenderState(class_11890 player, class_10055 state, float tickDelta, CallbackInfo ci) {
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return;
        BabyBoyModule babyBoy = DolphyClient.getInstance().getModuleManager().getModule(BabyBoyModule.class);
        if (babyBoy != null && babyBoy.isEnabled()) {
            class_310 mc = class_310.method_1551();
            if (mc != null && player == mc.field_1724 && babyBoy.isChangeSelf()) {
                state.field_53525 = true;
            } else if (mc != null && player != mc.field_1724 && babyBoy.isChangePlayers()) {
                state.field_53525 = true;
            }
        }
    }

    @Inject(method = "method_4213(Lnet/minecraft/class_10055;Lnet/minecraft/class_4587;)V", at = @At("TAIL"))
    private void onScale(class_10055 state, class_4587 matrices, CallbackInfo ci) {
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return;
        SpinBotModule spinBot = DolphyClient.getInstance().getModuleManager().getModule(SpinBotModule.class);
        if (spinBot != null && spinBot.isEnabled()) {
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.field_1724 != null) {
                String localName = mc.field_1724.method_5477().getString();
                if (localName.equals(state.field_53529) || state.field_53328 == mc.field_1724.method_5628()) {
                    float spinAngle = spinBot.getCurrentAngle();
                    float spinDelta = spinAngle - state.field_53407;
                    matrices.method_22907(class_7833.field_40716.rotationDegrees(spinDelta));
                }
            }
        }
    }
}
