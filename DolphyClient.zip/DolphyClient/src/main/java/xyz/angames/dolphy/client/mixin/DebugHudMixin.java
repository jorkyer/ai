package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_332;
import net.minecraft.class_340;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.FpsBoostModule;

@Mixin(class_340.class)
public class DebugHudMixin {
    @Inject(method = "method_51745", at = @At("HEAD"), cancellable = true)
    private void onDrawText(class_332 context, CallbackInfo ci) {
        FpsBoostModule fpsModule = DolphyClient.getInstance().getModuleManager().getModule(FpsBoostModule.class);
        if (fpsModule == null || !fpsModule.isEnabled()) return;
        fpsModule.renderAnimatedF3(context);
        ci.cancel();
    }
}
