package xyz.angames.dolphy.client.render;

import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.compat.DolphyCompat;
import xyz.angames.dolphy.client.module.modules.cosmetic.CapesModule;
import xyz.angames.dolphy.client.module.modules.cosmetic.HatsModule;
import xyz.angames.dolphy.client.module.modules.cosmetic.WingsModule;
import xyz.angames.dolphy.client.module.modules.render.ChinaHatModule;

public class ChinaHatFeatureRenderer extends class_3887<class_10055, class_591> {
    public ChinaHatFeatureRenderer(class_3883<class_10055, class_591> context) {
        super(context);
    }

    @Override
    public void method_4199(class_4587 matrices, class_11659 queue, int light, class_10055 state, float limbAngle, float limbDistance) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return;
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return;

        ChinaHatModule chinaHat = DolphyClient.getInstance().getModuleManager().getModule(ChinaHatModule.class);
        HatsModule hats = DolphyClient.getInstance().getModuleManager().getModule(HatsModule.class);
        WingsModule wings = DolphyClient.getInstance().getModuleManager().getModule(WingsModule.class);
        CapesModule capes = DolphyClient.getInstance().getModuleManager().getModule(CapesModule.class);

        boolean chinaEnabled = chinaHat != null && chinaHat.isEnabled();
        boolean hatsEnabled = hats != null && hats.isEnabled();
        boolean wingsEnabled = wings != null && wings.isEnabled();
        boolean capesEnabled = capes != null && capes.isEnabled();
        if (!chinaEnabled && !hatsEnabled && !wingsEnabled && !capesEnabled) return;

        String localName = mc.field_1724.method_5477().getString();
        boolean isSelf = localName.equals(state.field_53529) || state.field_53328 == mc.field_1724.method_5628();
        boolean firstPerson = mc.field_1690.method_31044().method_31034();

        class_591 model = this.method_17165();
        float headX = model.field_3398.field_3657;
        float headY = model.field_3398.field_3656;
        float headZ = model.field_3398.field_3655;
        float headPitch = model.field_3398.field_3654;
        float headYaw = model.field_3398.field_3675;
        float headRoll = model.field_3398.field_3674;

        float bodyX = model.field_3391.field_3657;
        float bodyY = model.field_3391.field_3656;
        float bodyZ = model.field_3391.field_3655;
        float bodyPitch = model.field_3391.field_3654;
        float bodyYaw = model.field_3391.field_3675;
        float bodyRoll = model.field_3391.field_3674;

        org.joml.Matrix4f savedMatrix = new org.joml.Matrix4f((org.joml.Matrix4fc) matrices.method_23760().method_23761());

        DolphyCompat.deferWorldRender(() -> {
            class_4587 m = new class_4587();
            m.method_23760().method_23761().set((org.joml.Matrix4fc) savedMatrix);

            if ((chinaEnabled || hatsEnabled) && (!isSelf || !firstPerson)) {
                m.method_22903();
                m.method_46416(headX / 16.0F, headY / 16.0F, headZ / 16.0F);
                if (headRoll != 0.0F) m.method_22907(class_7833.field_40718.rotation(headRoll));
                if (headYaw != 0.0F) m.method_22907(class_7833.field_40716.rotation(headYaw));
                if (headPitch != 0.0F) m.method_22907(class_7833.field_40714.rotation(headPitch));
                m.method_22907(class_7833.field_40714.rotationDegrees(180.0F));
                m.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                if (chinaEnabled && (isSelf || chinaHat.isRenderPlayers())) {
                    chinaHat.renderHatFromFeature(m);
                }
                if (hatsEnabled && (isSelf || hats.isShowOnOthers())) {
                    hats.renderFromFeature(m);
                }
                m.method_22909();
            }

            if ((wingsEnabled || capesEnabled) && (!isSelf || !firstPerson)) {
                m.method_22903();
                m.method_46416(bodyX / 16.0F, bodyY / 16.0F, bodyZ / 16.0F);
                if (bodyRoll != 0.0F) m.method_22907(class_7833.field_40718.rotation(bodyRoll));
                if (bodyYaw != 0.0F) m.method_22907(class_7833.field_40716.rotation(bodyYaw));
                if (bodyPitch != 0.0F) m.method_22907(class_7833.field_40714.rotation(bodyPitch));
                m.method_22907(class_7833.field_40714.rotationDegrees(180.0F));
                m.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
                if (wingsEnabled && (isSelf || wings.isShowOnOthers())) {
                    wings.renderWingsFromFeature(m, state.field_53325);
                }
                if (capesEnabled && (isSelf || capes.isShowOnOthers())) {
                    capes.renderCapeFromFeature(m, state);
                }
                m.method_22909();
            }
        });
    }
}
