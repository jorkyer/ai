package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_10017;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.FullbrightModule;
import xyz.angames.dolphy.client.module.modules.render.HitColorModule;
import xyz.angames.dolphy.client.module.modules.render.PlayerChamsModule;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin<T extends class_1309, S extends class_10042, M extends class_583<? super S>> {
    @Shadow
    protected M field_4737;

    @Unique
    private boolean dolphy$renderingChams = false;

    @Inject(method = "method_4054(Lnet/minecraft/class_10042;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;Lnet/minecraft/class_12075;)V", at = @At("HEAD"), cancellable = true)
    private void onRenderHead(S state, class_4587 matrices, class_11659 queue, class_12075 cameraState, CallbackInfo ci) {
        if (DolphyClient.getInstance() != null && DolphyClient.getInstance().getModuleManager() != null) {
            FullbrightModule fb = DolphyClient.getInstance().getModuleManager().getModule(FullbrightModule.class);
            if (fb != null && fb.isEnabled()) {
                ((class_10017) state).field_61820 = 15728880;
            }
        }
        if (!(state instanceof class_10055)) return;
        PlayerChamsModule chams = getChamsModule();
        if (chams == null || !chams.isEnabled()) return;
        class_10055 playerState = (class_10055) state;
        if (!chams.isRenderSelf() && isLocalPlayer(playerState)) return;
        dolphy$renderingChams = true;
    }

    @Inject(method = "method_4054(Lnet/minecraft/class_10042;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;Lnet/minecraft/class_12075;)V", at = @At("RETURN"))
    private void onRenderReturn(S state, class_4587 matrices, class_11659 queue, class_12075 cameraState, CallbackInfo ci) {
        if (!dolphy$renderingChams) return;
        dolphy$renderingChams = false;
    }

    @Inject(method = "method_62603", at = @At("RETURN"), cancellable = true)
    private void onGetMixColor(S state, CallbackInfoReturnable<Integer> cir) {
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return;
        HitColorModule hitColor = DolphyClient.getInstance().getModuleManager().getModule(HitColorModule.class);
        if (hitColor != null && hitColor.isEnabled() && state.field_53459) {
            cir.setReturnValue(hitColor.getHitColorArgb());
            return;
        }
        if (dolphy$renderingChams) {
            PlayerChamsModule chams = getChamsModule();
            if (chams != null && chams.isEnabled() && chams.isColorOverlay()) {
                cir.setReturnValue(chams.getVisibleColor());
            }
        }
    }

    @Unique
    private PlayerChamsModule getChamsModule() {
        if (DolphyClient.getInstance() == null || DolphyClient.getInstance().getModuleManager() == null) return null;
        return DolphyClient.getInstance().getModuleManager().getModule(PlayerChamsModule.class);
    }

    @Unique
    private boolean isLocalPlayer(class_10055 state) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return false;
        return state.field_53328 == mc.field_1724.method_5628();
    }
}
