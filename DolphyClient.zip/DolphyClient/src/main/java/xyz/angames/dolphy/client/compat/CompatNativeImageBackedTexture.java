package xyz.angames.dolphy.client.compat;

import java.util.function.Supplier;
import net.minecraft.class_1011;
import net.minecraft.class_1043;

public class CompatNativeImageBackedTexture extends class_1043 {
    public CompatNativeImageBackedTexture(class_1011 image) {
        super(() -> "dolphy_dynamic_tex", image);
    }

    public CompatNativeImageBackedTexture(Supplier<String> nameSupplier, class_1011 image) {
        super(nameSupplier, image);
    }

    public CompatNativeImageBackedTexture(int width, int height, boolean useStb) {
        super("dolphy_dynamic_tex", width, height, useStb);
    }
}
