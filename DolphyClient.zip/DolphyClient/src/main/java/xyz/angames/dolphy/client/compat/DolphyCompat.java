package xyz.angames.dolphy.client.compat;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.function.BiFunction;
import net.minecraft.*;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL33C;

public final class DolphyCompat {
    private static final Map<String, CompatShader> SHADERS = new HashMap<>();
    private static CompatShader activeShader = null;
    private static final float[] SHADER_COLOR = new float[]{1.0F, 1.0F, 1.0F, 1.0F};
    private static final int[] SHADER_TEXTURES = new int[12];
    private static final FloatBuffer MAT_BUF = BufferUtils.createFloatBuffer(16);

    private static int sharedVao = 0;
    private static int sharedVbo = 0;
    private static int quadEbo = 0;
    private static int quadEboCapacityQuads = 0;

    public static final Matrix4f worldViewMat = new Matrix4f();
    public static final Matrix4f worldProjMat = new Matrix4f();
    public static boolean inWorldRender = false;

    private static final WeakHashMap<class_332, CompatMatrixStack> CONTEXT_MATRICES = new WeakHashMap<>();
    private static final Deque<int[]> SCISSOR_STACK = new ArrayDeque<>();

    public static class_11228 guiRendererInstance = null;
    public static class_758 fogRendererInstance = null;
    public static class_11246 guiStateInstance = null;
    public static boolean guiStateDirty = false;

    public static class_11659 currentOrderedQueue;
    private static final List<Runnable> DEFERRED_WORLD_TASKS = new ArrayList<>();

    private DolphyCompat() {}

    public static void deferWorldRender(Runnable task) {
        if (task != null) {
            synchronized (DEFERRED_WORLD_TASKS) {
                DEFERRED_WORLD_TASKS.add(task);
            }
        }
    }

    public static void flushDeferredWorldRender() {
        List<Runnable> tasks;
        synchronized (DEFERRED_WORLD_TASKS) {
            if (DEFERRED_WORLD_TASKS.isEmpty()) return;
            tasks = new ArrayList<>(DEFERRED_WORLD_TASKS);
            DEFERRED_WORLD_TASKS.clear();
        }
        for (Runnable r : tasks) {
            try {
                r.run();
            } catch (Throwable ignored) {}
        }
    }

    public static void beginWorldRender() {
        inWorldRender = true;
        ensureMainFramebufferBound();
    }

    public static void endWorldRender() {
        inWorldRender = false;
    }

    public static void markGuiStateDirty() {
        guiStateDirty = true;
    }

    public static void flushGui() {
        if (!guiStateDirty) {
            ensureMainFramebufferBound();
            return;
        }
        guiStateDirty = false;
        try {
            if (guiRendererInstance != null && fogRendererInstance != null && guiStateInstance != null) {
                guiRendererInstance.method_70890(
                    fogRendererInstance.method_71109(class_758.class_4596.field_60101)
                );
                guiStateInstance.method_70926();
            }
        } catch (Throwable ignored) {}
        ensureMainFramebufferBound();
        if (!SCISSOR_STACK.isEmpty()) {
            int[] sc = SCISSOR_STACK.peek();
            GlStateManager._enableScissorTest();
            GlStateManager._scissorBox(sc[0], sc[1], sc[2], sc[3]);
        }
    }

    public static void ensureMainFramebufferBound() {
        try {
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.method_1522() != null) {
                class_276 fb = mc.method_1522();
                int fbo = getFbo(fb);
                if (fbo > 0) {
                    GlStateManager._glBindFramebuffer(36160, fbo);
                    GlStateManager._viewport(0, 0, fb.field_1482, fb.field_1481);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static void ensureFramebufferBound() {
        if (GlStateManager.getFrameBuffer(36009) == 0) {
            ensureMainFramebufferBound();
        }
    }

    public static CompatShader setShader(CompatShaderKey key) {
        if (key == null) {
            activeShader = null;
            return null;
        }
        CompatShader shader = SHADERS.get(key.id);
        if (shader == null) {
            shader = new CompatShader(key.id);
            SHADERS.put(key.id, shader);
        } else if (shader.programId <= 0) {
            shader.ensureCompiled();
        }
        activeShader = shader;
        if (shader.programId > 0) {
            GL20.glUseProgram(shader.programId);
        }
        return shader;
    }

    public static void setShaderColor(float r, float g, float b, float a) {
        SHADER_COLOR[0] = r;
        SHADER_COLOR[1] = g;
        SHADER_COLOR[2] = b;
        SHADER_COLOR[3] = a;
    }

    public static void setShaderTexture(int unit, int glTexId) {
        if (unit >= 0 && unit < SHADER_TEXTURES.length) {
            SHADER_TEXTURES[unit] = glTexId;
        }
    }

    public static void setShaderTexture(int unit, class_2960 id) {
        if (unit < 0 || unit >= SHADER_TEXTURES.length) return;
        if (id == null) {
            SHADER_TEXTURES[unit] = 0;
            return;
        }
        try {
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.method_1531() != null) {
                class_1044 tex = mc.method_1531().method_4619(id);
                SHADER_TEXTURES[unit] = getTextureGlId(tex);
            }
        } catch (Throwable ignored) {
            SHADER_TEXTURES[unit] = 0;
        }
    }

    public static Matrix4f getModelViewMatrix() {
        return new Matrix4f(RenderSystem.getModelViewMatrix());
    }

    public static Matrix4f getProjectionMatrix() {
        if (inWorldRender) {
            return new Matrix4f(worldProjMat);
        }
        class_310 mc = class_310.method_1551();
        if (mc != null && mc.method_22683() != null) {
            class_1041 win = mc.method_22683();
            float w = (float) win.method_4486();
            float h = (float) win.method_4502();
            return new Matrix4f().setOrtho(0.0F, Math.max(1.0F, w), Math.max(1.0F, h), 0.0F, -1000.0F, 1000.0F);
        }
        return new Matrix4f();
    }

    private static void ensureQuadEbo(int quadCount) {
        if (quadEbo == 0) {
            quadEbo = GL15.glGenBuffers();
        }
        if (quadCount > quadEboCapacityQuads) {
            int newCap = Math.max(quadCount, Math.max(1024, quadEboCapacityQuads * 2));
            IntBuffer indices = BufferUtils.createIntBuffer(newCap * 6);
            for (int i = 0; i < newCap; i++) {
                int v = i * 4;
                indices.put(v).put(v + 1).put(v + 2).put(v + 2).put(v + 3).put(v);
            }
            indices.flip();
            GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, quadEbo);
            GL15.glBufferData(GL15.GL_ELEMENT_ARRAY_BUFFER, indices, GL15.GL_STATIC_DRAW);
            quadEboCapacityQuads = newCap;
        } else {
            GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, quadEbo);
        }
    }

    public static void drawWithGlobalProgram(class_9801 builtBuffer) {
        if (builtBuffer == null) return;
        try {
            class_9801.class_4574 params = builtBuffer.method_60822();
            ByteBuffer vertexBuf = builtBuffer.method_60818();
            int vertexCount = params.comp_750();
            if (vertexCount <= 0 || vertexBuf == null) {
                builtBuffer.close();
                return;
            }
            VertexFormat format = params.comp_749();
            VertexFormat.class_5596 drawMode = params.comp_752();

            if (!inWorldRender && guiStateDirty) {
                class_310 mc = class_310.method_1551();
                int curFbo = GlStateManager.getFrameBuffer(36009);
                int mainFbo = (mc != null && mc.method_1522() != null) ? getFbo(mc.method_1522()) : 0;
                if (curFbo == 0 || curFbo == mainFbo) {
                    flushGui();
                }
            }
            ensureFramebufferBound();

            CompatShader shader = activeShader;
            if (shader == null || shader.programId <= 0) {
                shader = setShader(CompatShaderKey.field_53993);
            }
            if (shader == null || shader.programId <= 0) {
                builtBuffer.close();
                return;
            }

            int prevProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
            int prevVao = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
            int prevArrayBuf = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);

            GL20.glUseProgram(shader.programId);

            CompatUniform mvUniform = shader.method_34582("ModelViewMat");
            if (mvUniform != null) {
                mvUniform.method_1250(inWorldRender ? new Matrix4f() : getModelViewMatrix());
            }
            CompatUniform projUniform = shader.method_34582("ProjMat");
            if (projUniform != null) {
                projUniform.method_1250(getProjectionMatrix());
            }
            CompatUniform cmUniform = shader.method_34582("ColorModulator");
            if (cmUniform != null) {
                cmUniform.method_1254(SHADER_COLOR[0], SHADER_COLOR[1], SHADER_COLOR[2], SHADER_COLOR[3]);
            }

            for (int u = 0; u < 4; u++) {
                CompatUniform sUniform = shader.method_34582("Sampler" + u);
                if (sUniform != null && SHADER_TEXTURES[u] > 0) {
                    GlStateManager._activeTexture(GL13.GL_TEXTURE0 + u);
                    GL33C.glBindSampler(u, 0);
                    GlStateManager._bindTexture(SHADER_TEXTURES[u]);
                    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
                    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
                    sUniform.method_1248(u);
                }
            }
            GlStateManager._activeTexture(GL13.GL_TEXTURE0);
            GL33C.glBindSampler(0, 0);

            if (sharedVao == 0) {
                sharedVao = GL30.glGenVertexArrays();
                sharedVbo = GL15.glGenBuffers();
            }
            GlStateManager._glBindVertexArray(sharedVao);
            GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, sharedVbo);
            GL15.glBufferData(GL15.GL_ARRAY_BUFFER, vertexBuf, GL15.GL_STREAM_DRAW);

            int stride = format.getVertexSize();
            if (format.contains(VertexFormatElement.POSITION)) {
                GL20.glEnableVertexAttribArray(0);
                GL20.glVertexAttribPointer(0, 3, GL11.GL_FLOAT, false, stride, format.getOffset(VertexFormatElement.POSITION));
            } else {
                GL20.glDisableVertexAttribArray(0);
            }

            if (format.contains(VertexFormatElement.UV0)) {
                GL20.glEnableVertexAttribArray(1);
                GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, stride, format.getOffset(VertexFormatElement.UV0));
            } else {
                GL20.glDisableVertexAttribArray(1);
            }

            if (format.contains(VertexFormatElement.COLOR)) {
                GL20.glEnableVertexAttribArray(2);
                GL20.glVertexAttribPointer(2, 4, GL11.GL_UNSIGNED_BYTE, true, stride, format.getOffset(VertexFormatElement.COLOR));
            } else {
                GL20.glDisableVertexAttribArray(2);
                GL20.glVertexAttrib4f(2, 1.0F, 1.0F, 1.0F, 1.0F);
            }

            if (format.contains(VertexFormatElement.NORMAL)) {
                GL20.glEnableVertexAttribArray(3);
                GL20.glVertexAttribPointer(3, 3, GL11.GL_BYTE, true, stride, format.getOffset(VertexFormatElement.NORMAL));
            } else {
                GL20.glDisableVertexAttribArray(3);
            }

            if (drawMode == VertexFormat.class_5596.field_27382) {
                int quadCount = vertexCount / 4;
                if (quadCount > 0) {
                    ensureQuadEbo(quadCount);
                    GL11.glDrawElements(GL11.GL_TRIANGLES, quadCount * 6, GL11.GL_UNSIGNED_INT, 0L);
                }
            } else {
                int glMode = GL11.GL_TRIANGLES;
                if (drawMode == VertexFormat.class_5596.field_27380) glMode = GL11.GL_TRIANGLE_STRIP;
                else if (drawMode == VertexFormat.class_5596.field_27381) glMode = GL11.GL_TRIANGLE_FAN;
                else if (drawMode == VertexFormat.class_5596.field_27377) glMode = GL11.GL_LINES;
                GL11.glDrawArrays(glMode, 0, vertexCount);
            }

            GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, prevArrayBuf);
            GlStateManager._glBindVertexArray(prevVao);
            GlStateManager._glUseProgram(prevProgram);
        } catch (Throwable t) {
            t.printStackTrace();
        } finally {
            try {
                builtBuffer.close();
            } catch (Throwable ignored) {}
        }
    }

    public static void enableBlend() { GlStateManager._enableBlend(); }
    public static void disableBlend() { GlStateManager._disableBlend(); }
    public static void defaultBlendFunc() { GlStateManager._blendFuncSeparate(770, 771, 1, 0); }
    public static void blendFunc(int sfactor, int dfactor) { GlStateManager._blendFuncSeparate(sfactor, dfactor, 1, 0); }
    public static void blendFunc(CompatSourceFactor src, CompatDstFactor dst) {
        GlStateManager._blendFuncSeparate(src.value, dst.value, 1, 0);
    }
    public static void blendFuncSeparate(
        CompatSourceFactor srcRgb, CompatDstFactor dstRgb,
        CompatSourceFactor srcAlpha, CompatDstFactor dstAlpha
    ) {
        GlStateManager._blendFuncSeparate(srcRgb.value, dstRgb.value, srcAlpha.value, dstAlpha.value);
    }
    public static void blendFuncSeparate(int sRgb, int dRgb, int sAlpha, int dAlpha) {
        GlStateManager._blendFuncSeparate(sRgb, dRgb, sAlpha, dAlpha);
    }
    public static void enableDepthTest() { GlStateManager._enableDepthTest(); }
    public static void disableDepthTest() { GlStateManager._disableDepthTest(); }
    public static void depthMask(boolean mask) { GlStateManager._depthMask(mask); }
    public static void enableCull() { GlStateManager._enableCull(); }
    public static void disableCull() { GlStateManager._disableCull(); }
    public static void lineWidth(float width) { GL11.glLineWidth(width); }
    public static void clear(int mask) { GlStateManager._clear(mask); }

    public static int getFbo(class_276 fb) {
        if (fb == null) return 0;
        try {
            GpuTextureView colorView = fb.method_71639();
            if (colorView instanceof class_11391) {
                class_11391 glView = (class_11391) colorView;
                GpuTexture depthTex = fb.field_1478 ? fb.method_30278() : null;
                class_10865 glDev = (class_10865) RenderSystem.getDevice();
                return glView.method_76232(glDev.method_68401(), depthTex);
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    public static int getColorAttachment(class_276 fb) {
        if (fb == null) return 0;
        try {
            GpuTexture tex = fb.method_30277();
            if (tex instanceof class_10868) {
                class_10868 glTex = (class_10868) tex;
                int id = glTex.method_68427();
                if (id > 0) {
                    GlStateManager._bindTexture(id);
                    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
                    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
                    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, 33071);
                    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, 33071);
                }
                return id;
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    public static int getDepthAttachment(class_276 fb) {
        if (fb == null) return 0;
        try {
            GpuTexture tex = fb.method_30278();
            if (tex instanceof class_10868) {
                class_10868 glTex = (class_10868) tex;
                return glTex.method_68427();
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    public static void beginWrite(class_276 fb, boolean setViewport) {
        if (fb == null) return;
        if (!inWorldRender && guiStateDirty) {
            flushGui();
        }
        int fbo = getFbo(fb);
        if (fbo > 0) {
            GlStateManager._glBindFramebuffer(36160, fbo);
            if (setViewport) {
                GlStateManager._viewport(0, 0, fb.field_1482, fb.field_1481);
            }
        }
    }

    public static void endWrite(class_276 fb) {
        ensureMainFramebufferBound();
    }

    public static void resizeFb(class_276 fb, int width, int height) {
        if (fb != null) {
            fb.method_1234(Math.max(1, width), Math.max(1, height));
        }
    }

    public static void clearFb(class_276 fb) {
        if (fb == null) return;
        int prevFbo = GlStateManager.getFrameBuffer(36009);
        int fbo = getFbo(fb);
        if (fbo > 0) {
            GlStateManager._glBindFramebuffer(36160, fbo);
            GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            int mask = GL11.GL_COLOR_BUFFER_BIT | (fb.field_1478 ? GL11.GL_DEPTH_BUFFER_BIT : 0);
            GlStateManager._clear(mask);
            GlStateManager._glBindFramebuffer(36160, prevFbo);
        }
    }

    public static void setClearColorFb(class_276 fb, float r, float g, float b, float a) {
        GL11.glClearColor(r, g, b, a);
    }

    public static void drawFb(class_276 srcFb, int width, int height) {
        if (srcFb == null) return;
        int srcFbo = getFbo(srcFb);
        int dstFbo = GlStateManager.getFrameBuffer(36009);
        if (dstFbo == 0) {
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.method_1522() != null) {
                dstFbo = getFbo(mc.method_1522());
            }
        }
        if (srcFbo > 0 && dstFbo > 0) {
            GlStateManager._glBlitFrameBuffer(
                0, 0, srcFb.field_1482, srcFb.field_1481,
                0, 0, width, height,
                GL11.GL_COLOR_BUFFER_BIT, GL11.GL_NEAREST
            );
        }
    }

    public static int getTextureGlId(class_1044 tex) {
        if (tex == null) return 0;
        try {
            GpuTexture gpuTex = tex.method_68004();
            if (gpuTex instanceof class_10868) {
                class_10868 glTex = (class_10868) gpuTex;
                int id = glTex.method_68427();
                if (id > 0) {
                    GlStateManager._bindTexture(id);
                    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
                    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
                }
                return id;
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    public static void bindTexture(class_1044 tex) {
        int id = getTextureGlId(tex);
        if (id > 0) {
            GL33C.glBindSampler(0, 0);
            GlStateManager._bindTexture(id);
        }
    }

    public static void setTextureFilter(class_1044 tex, boolean bilinear, boolean mipmap) {
        int id = getTextureGlId(tex);
        if (id > 0) {
            GlStateManager._bindTexture(id);
            int filter = bilinear ? GL11.GL_LINEAR : GL11.GL_NEAREST;
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, filter);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, filter);
        }
    }

    public static void registerTexture(class_1060 tm, class_2960 id, class_1044 tex) {
        if (tm != null && id != null && tex != null) {
            tm.method_4616(id, tex);
            getTextureGlId(tex);
        }
    }

    public static int getImagePixelColor(class_1011 image, int x, int y) {
        if (image == null) return 0;
        return image.method_61940(x, y);
    }

    public static void setImagePixelColor(class_1011 image, int x, int y, int color) {
        if (image != null) {
            image.method_61941(x, y, color);
        }
    }

    public static class_4587 getMatrices(class_332 ctx) {
        if (ctx == null) return new class_4587();
        CompatMatrixStack stack = CONTEXT_MATRICES.get(ctx);
        if (stack == null) {
            stack = new CompatMatrixStack(ctx);
            CONTEXT_MATRICES.put(ctx, stack);
        } else if (stack.method_67795()) {
            stack.syncFromContext();
        }
        return stack;
    }

    private static void syncContextMatrix(class_332 ctx) {
        if (ctx != null) {
            CompatMatrixStack stack = CONTEXT_MATRICES.get(ctx);
            if (stack != null) {
                stack.syncToContext();
            }
        }
    }

    public static class_4597.class_4598 getDrawContextVertexConsumers(class_332 ctx) {
        return class_310.method_1551().method_22940().method_23000();
    }

    public static void drawContextDraw(class_332 ctx) {
        flushGui();
    }

    public static void enableScissor(class_332 ctx, int x1, int y1, int x2, int y2) {
        if (ctx != null) {
            ctx.method_44379(x1, y1, x2, y2);
        }
        class_310 mc = class_310.method_1551();
        if (mc != null && mc.method_22683() != null) {
            class_1041 win = mc.method_22683();
            int scale = win.method_4495();
            int fbH = win.method_4506();
            int sx = Math.max(0, x1 * scale);
            int sy = Math.max(0, fbH - y2 * scale);
            int sw = Math.max(0, (x2 - x1) * scale);
            int sh = Math.max(0, (y2 - y1) * scale);
            if (!SCISSOR_STACK.isEmpty()) {
                int[] prev = SCISSOR_STACK.peek();
                int nx1 = Math.max( sx, prev[0]);
                int ny1 = Math.max( sy, prev[1]);
                int nx2 = Math.min( sx + sw, prev[0] + prev[2]);
                int ny2 = Math.min( sy + sh, prev[1] + prev[3]);
                sx = nx1;
                sy = ny1;
                sw = Math.max(0, nx2 - nx1);
                sh = Math.max(0, ny2 - ny1);
            }
            SCISSOR_STACK.push(new int[]{sx, sy, sw, sh});
            GlStateManager._enableScissorTest();
            GlStateManager._scissorBox(sx, sy, sw, sh);
        }
    }

    public static void disableScissor(class_332 ctx) {
        if (ctx != null) {
            ctx.method_44380();
        }
        if (!SCISSOR_STACK.isEmpty()) {
            SCISSOR_STACK.pop();
        }
        if (SCISSOR_STACK.isEmpty()) {
            GlStateManager._disableScissorTest();
        } else {
            int[] prev = SCISSOR_STACK.peek();
            GlStateManager._enableScissorTest();
            GlStateManager._scissorBox(prev[0], prev[1], prev[2], prev[3]);
        }
    }

    public static double getScaleFactor(class_1041 window) {
        return window != null ? (double) window.method_4495() : 1.0D;
    }

    public static int drawText8(
        class_327 tr, String text, float x, float y, int color, boolean shadow,
        Matrix4f matrix, class_4597 vcs, class_327.class_6415 layerType, int bgColor, int light
    ) {
        return trDraw(tr, text, x, y, color, shadow, matrix, vcs, layerType, bgColor, light);
    }

    public static int drawText8(
        class_327 tr, class_2561 text, float x, float y, int color, boolean shadow,
        Matrix4f matrix, class_4597 vcs, class_327.class_6415 layerType, int bgColor, int light
    ) {
        return trDraw(tr, text, x, y, color, shadow, matrix, vcs, layerType, bgColor, light);
    }

    public static int drawTextWithShadow(class_332 ctx, class_327 tr, String text, int x, int y, int color) {
        if (ctx == null || tr == null || text == null) return x;
        syncContextMatrix(ctx);
        ctx.method_51433(tr, text, x, y, color, true);
        guiStateDirty = true;
        return x + tr.method_1727(text);
    }

    public static int drawTextWithShadow(class_332 ctx, class_327 tr, class_2561 text, int x, int y, int color) {
        if (ctx == null || tr == null || text == null) return x;
        syncContextMatrix(ctx);
        ctx.method_27535(tr, text, x, y, color);
        guiStateDirty = true;
        return x + tr.method_27525(text);
    }

    public static int drawText(class_332 ctx, class_327 tr, String text, int x, int y, int color, boolean shadow) {
        if (ctx == null || tr == null || text == null) return x;
        syncContextMatrix(ctx);
        ctx.method_51433(tr, text, x, y, color, shadow);
        guiStateDirty = true;
        return x + tr.method_1727(text);
    }

    public static int drawText(class_332 ctx, class_327 tr, class_2561 text, int x, int y, int color, boolean shadow) {
        if (ctx == null || tr == null || text == null) return x;
        syncContextMatrix(ctx);
        ctx.method_51439(tr, text, x, y, color, shadow);
        guiStateDirty = true;
        return x + tr.method_27525(text);
    }

    public static int trDraw(
        class_327 tr, String text, float x, float y, int color, boolean shadow,
        Matrix4f matrix, class_4597 vcs, class_327.class_6415 layerType, int bgColor, int light
    ) {
        if (tr == null || text == null) return (int) x;
        tr.method_27521(text, x, y, color, shadow, matrix, vcs, layerType, bgColor, light);
        return (int) x + tr.method_1727(text);
    }

    public static int trDraw(
        class_327 tr, class_2561 text, float x, float y, int color, boolean shadow,
        Matrix4f matrix, class_4597 vcs, class_327.class_6415 layerType, int bgColor, int light
    ) {
        if (tr == null || text == null) return (int) x;
        tr.method_27522(text, x, y, color, shadow, matrix, vcs, layerType, bgColor, light);
        return (int) x + tr.method_27525(text);
    }

    public static void drawItem(class_332 ctx, class_1799 stack, int x, int y) {
        if (ctx != null && stack != null) {
            syncContextMatrix(ctx);
            ctx.method_51427(stack, x, y);
            guiStateDirty = true;
        }
    }

    public static void drawStackOverlay(class_332 ctx, class_327 tr, class_1799 stack, int x, int y) {
        if (ctx != null && tr != null && stack != null) {
            syncContextMatrix(ctx);
            ctx.method_51431(tr, stack, x, y);
            guiStateDirty = true;
        }
    }

    public static void setRenderTextProvider(class_342 field, BiFunction<String, Integer, class_5481> provider) {
        if (field == null || provider == null) return;
        field.method_73210((str, firstIdx) -> provider.apply(str, firstIdx));
    }

    public static boolean screenMouseClicked(class_437 screen, double mouseX, double mouseY, int button) {
        if (screen == null) return false;
        class_11909 click = new class_11909(mouseX, mouseY, new class_11910(button, 0));
        return screen.method_25402(click, false);
    }

    public static boolean screenMouseReleased(class_437 screen, double mouseX, double mouseY, int button) {
        if (screen == null) return false;
        class_11909 click = new class_11909(mouseX, mouseY, new class_11910(button, 0));
        return screen.method_25406(click);
    }

    public static boolean screenMouseDragged(class_437 screen, double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (screen == null) return false;
        class_11909 click = new class_11909(mouseX, mouseY, new class_11910(button, 0));
        return screen.method_25403(click, deltaX, deltaY);
    }

    public static boolean screenKeyPressed(class_437 screen, int keyCode, int scanCode, int modifiers) {
        if (screen == null) return false;
        return screen.method_25404(new class_11908(keyCode, scanCode, modifiers));
    }

    public static boolean screenCharTyped(class_437 screen, char chr, int modifiers) {
        if (screen == null) return false;
        return screen.method_25400(new class_11905((int) chr, modifiers));
    }

    public static boolean hasShiftDown() {
        class_310 mc = class_310.method_1551();
        return mc != null && mc.method_74188();
    }

    public static boolean isKeyPressed(long handle, int code) {
        class_310 mc = class_310.method_1551();
        return mc != null && mc.method_22683() != null && class_3675.method_15987(mc.method_22683(), code);
    }

    public static class_4588 vertex(class_287 builder, Matrix4f mat, float x, float y, float z) {
        return builder.method_22918((Matrix4fc) mat, x, y, z);
    }

    public static class_4588 vertex(class_4588 consumer, Matrix4f mat, float x, float y, float z) {
        return consumer.method_22918((Matrix4fc) mat, x, y, z);
    }

    public static void multiply(class_4587 stack, Quaternionf q) {
        stack.method_22907((Quaternionfc) q);
    }

    public static class_4588 getBuffer(class_4597 provider, class_1921 layer) {
        return provider.method_73477(layer);
    }

    public static class_4588 getBuffer(class_4597.class_4598 provider, class_1921 layer) {
        return provider.method_73477(layer);
    }

    public static class_1921 getEntityTranslucent(class_2960 texture) {
        return class_12249.method_76000(texture);
    }

    public static class_1921 getTextLayer(class_2960 texture) {
        return class_12249.method_76022(texture);
    }

    public static class_243 getEntityPos(class_1297 entity) {
        return entity.method_73189();
    }

    public static class_1937 getEntityWorld(class_1297 entity) {
        return entity.method_73183();
    }

    public static class_243 getCameraPos(class_4184 camera) {
        return camera.method_71156();
    }

    public static float getSkyAngle(class_638 world, float tickDelta) {
        if (world == null) return 0.0F;
        return ((float) (world.method_28104().method_217() % 24000L) + tickDelta) / 24000.0F;
    }

    public static double getSpawnX(class_2604 pkt) { return pkt.method_73084().field_1352; }
    public static double getSpawnY(class_2604 pkt) { return pkt.method_73084().field_1351; }
    public static double getSpawnZ(class_2604 pkt) { return pkt.method_73084().field_1350; }

    public static double getVelocityX(class_2743 pkt) { return pkt.method_73085().field_1352; }
    public static double getVelocityY(class_2743 pkt) { return pkt.method_73085().field_1351; }
    public static double getVelocityZ(class_2743 pkt) { return pkt.method_73085().field_1350; }

    public static float sin(float v) { return class_3532.method_15374((double) v); }
    public static float cos(float v) { return class_3532.method_15362((double) v); }

    public static void playSound(class_1144 soundManager, class_1113 sound) {
        if (soundManager != null && sound != null) {
            soundManager.method_4873(sound);
        }
    }

    public static class_320 createSession(
        String username, UUID uuid, String accessToken,
        Optional<String> xuid, Optional<String> clientId, Object accountType
    ) {
        return new class_320(username, uuid, accessToken, xuid, clientId);
    }

    public static class_2960 getSkinTextureId(class_8685 skinTextures) {
        if (skinTextures == null || skinTextures.comp_1626() == null) return null;
        return skinTextures.comp_1626().comp_3627();
    }

    public static class_8685 withCapeTexture(class_8685 original, class_2960 capeTex) {
        if (original == null || capeTex == null) return original;
        class_12079.class_10726 asset = new class_12079.class_10726(capeTex);
        return new class_8685(original.comp_1626(), asset, asset, original.comp_1629(), original.comp_1630());
    }

    public static String getPlayerStateName(class_10055 state) {
        if (state == null) return "";
        if (state.field_53525 != null) return state.field_53525.getString();
        if (state.field_53337 != null) return state.field_53337.getString();
        return "";
    }

    public static String gameProfileGetName(com.mojang.authlib.GameProfile profile) {
        return profile != null ? profile.name() : "";
    }

    public static class_2371<class_1799> getArmorItems(class_1661 inv) {
        class_2371<class_1799> list = class_2371.method_10213(4, class_1799.field_8037);
        if (inv != null && inv.field_7546 != null) {
            list.set(0, inv.field_7546.method_6118(class_1304.field_6166));
            list.set(1, inv.field_7546.method_6118(class_1304.field_6172));
            list.set(2, inv.field_7546.method_6118(class_1304.field_6174));
            list.set(3, inv.field_7546.method_6118(class_1304.field_6169));
        }
        return list;
    }

    public static int getSelectedSlot(class_1661 inv) {
        return inv != null ? inv.method_67532() : 0;
    }

    public static void setSelectedSlot(class_1661 inv, int slot) {
        if (inv != null) {
            inv.method_61496(slot);
        }
    }

    public static boolean isSwordItem(Object itemObj) {
        if (!(itemObj instanceof class_1792)) return false;
        class_1792 item = (class_1792) itemObj;
        try {
            String key = item.method_7876();
            return key != null && key.endsWith("_sword");
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static boolean isMiningTool(Object itemObj) {
        if (!(itemObj instanceof class_1792)) return false;
        class_1792 item = (class_1792) itemObj;
        try {
            String p = item.method_7876();
            if (p == null) return false;
            return p.endsWith("_pickaxe") || p.endsWith("_axe") || p.endsWith("_shovel") || p.endsWith("_hoe");
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static void renderRagdollEntity(
        class_897 renderer, class_10042 stateCopy, class_4587 matrices, class_4597 captureProvider, int light
    ) {
        try {
            if (renderer instanceof class_922) {
                class_922 lr = (class_922) renderer;
                class_583 model = lr.method_4038();
                if (model != null) {
                    model.method_2819(stateCopy);
                    matrices.method_22903();
                    matrices.method_22905(-1.0F, -1.0F, 1.0F);
                    matrices.method_46416(0.0F, -1.501F, 0.0F);
                    model.method_60879(matrices, captureProvider.method_73477(null), light, class_4608.field_21444);
                    matrices.method_22909();
                }
            }
        } catch (Throwable ignored) {}
    }

    public static void renderHeldItem(
        class_759 heldItemRenderer, class_1309 entity, class_1799 stack, class_811 renderMode,
        boolean leftHanded, class_4587 matrices, Object vertexConsumersOrQueue, int light
    ) {
        class_11659 queue = (vertexConsumersOrQueue instanceof class_11659)
            ? (class_11659) vertexConsumersOrQueue
            : currentOrderedQueue;
        if (heldItemRenderer != null && queue != null) {
            heldItemRenderer.method_3233(entity, stack, renderMode, matrices, queue, light);
        }
    }

    public static void renderItemFallback(
        class_918 itemRenderer, class_1309 entity, class_1799 stack, class_811 renderMode,
        boolean leftHanded, class_4587 matrices, Object vertexConsumersOrQueue, class_1937 world,
        int light, int overlay, int seed
    ) {
        class_310 mc = class_310.method_1551();
        if (mc != null && mc.method_1561() != null) {
            renderHeldItem(mc.method_1561().method_43336(), entity, stack, renderMode, leftHanded, matrices, vertexConsumersOrQueue, light);
        }
    }

    public static void recordRenderCall(Runnable call) {
        if (call != null) {
            call.run();
        }
    }

    public static void fill(class_332 ctx, int x1, int y1, int x2, int y2, int color) {
        if (x1 > x2) { int t = x1; x1 = x2; x2 = t; }
        if (y1 > y2) { int t = y1; y1 = y2; y2 = t; }
        float a = (float)(color >>> 24 & 255) / 255.0F;
        float r = (float)(color >> 16 & 255) / 255.0F;
        float g = (float)(color >> 8 & 255) / 255.0F;
        float b = (float)(color & 255) / 255.0F;
        Matrix4f m = getMatrices(ctx).method_23760().method_23761();
        enableBlend();
        defaultBlendFunc();
        setShader(CompatShaderKey.field_53993);
        class_287 buf = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        buf.method_22918((Matrix4fc) m, (float) x1, (float) y2, 0.0F).method_22915(r, g, b, a);
        buf.method_22918((Matrix4fc) m, (float) x2, (float) y2, 0.0F).method_22915(r, g, b, a);
        buf.method_22918((Matrix4fc) m, (float) x2, (float) y1, 0.0F).method_22915(r, g, b, a);
        buf.method_22918((Matrix4fc) m, (float) x1, (float) y1, 0.0F).method_22915(r, g, b, a);
        drawWithGlobalProgram(buf.method_60800());
        disableBlend();
    }

    public static class_11659 currentRenderQueue = null;

    public static class_11659 getRenderQueue(Object vcpOrQueue) {
        if (vcpOrQueue instanceof class_11659) return (class_11659) vcpOrQueue;
        if (currentRenderQueue != null) return currentRenderQueue;
        class_310 mc = class_310.method_1551();
        return mc != null && mc.field_1773 != null ? mc.field_1773.method_72910() : null;
    }

    public static class_4597.class_4598 getVertexConsumers(class_332 ctx) {
        return getImmediateVertexConsumers();
    }

    public static class_4597.class_4598 getImmediateVertexConsumers() {
        class_310 mc = class_310.method_1551();
        return mc != null && mc.method_22940() != null ? mc.method_22940().method_23000() : null;
    }

    public static String getSkinTextureModel(class_8685 skin) {
        if (skin == null || skin.comp_1629() == null) return "default";
        return skin.comp_1629().method_15434();
    }

    public static void renderItemState(class_10039 state, class_4587 matrices, Object queueOrVcp, int light, int overlay) {
        if (state == null || state.field_55310 == null) return;
        class_11659 q = getRenderQueue(queueOrVcp);
        if (q != null) {
            state.field_55310.method_65604(matrices, q, state.field_61820, overlay, state.field_61821);
        }
    }

    public static boolean screenSuperMouseClicked(class_437 screen, double x, double y, int btn) { return false; }
    public static boolean screenSuperMouseReleased(class_437 screen, double x, double y, int btn) { return false; }
    public static boolean screenSuperMouseDragged(class_437 screen, double x, double y, int btn, double dx, double dy) { return false; }
    public static boolean screenSuperKeyPressed(class_437 screen, int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256 && screen != null && screen.method_25422()) {
            screen.method_25419();
            return true;
        }
        return false;
    }
    public static boolean screenSuperCharTyped(class_437 screen, char chr, int modifiers) { return false; }

    public static boolean isMiningToolItem(Object item) {
        if (item == null) return false;
        String s = item.toString().toLowerCase();
        return s.contains("pickaxe") || s.contains("axe") || s.contains("shovel") || s.contains("hoe");
    }

    public static final VertexFormat field_1575 = class_290.field_1575;
    public static final VertexFormat field_1576 = class_290.field_1576;
    public static final VertexFormat field_1580 = class_290.field_1580;
    public static final VertexFormat field_1585 = class_290.field_1585;

    public static void activeTexture(int tex) {
        GlStateManager._activeTexture(tex);
    }

    public static void depthFunc(int func) {
        GlStateManager._depthFunc(func);
    }

    public static void clear(class_276 fb) {
        clearFb(fb);
    }

    public static void clear(class_276 fb, boolean getError) {
        clearFb(fb);
    }

    public static void setClearColor(class_276 fb, float r, float g, float b, float a) {
        setClearColorFb(fb, r, g, b, a);
    }

    public static int getGlId(class_1044 tex) {
        return getTextureGlId(tex);
    }

    public static int getPixelColor(class_1011 image, int x, int y) {
        return getImagePixelColor(image, x, y);
    }

    public static void setPixelColor(class_1011 image, int x, int y, int color) {
        setImagePixelColor(image, x, y, color);
    }

    public static Object getExplosionEmitterParticle() {
        return class_2398.field_11236;
    }

    public static Object getExplosionParticle() {
        return class_2398.field_11226;
    }

    public static Object getFlashParticle() {
        return class_2398.field_17431;
    }

    public static class_1921 getGuiTextured(class_2960 id) {
        return class_12249.method_76000(id);
    }

    public static class_11659 getRenderQueue() {
        return getRenderQueue(null);
    }

    public static void recordRenderCall(CompatRenderCall call) {
        if (call != null) {
            call.execute();
        }
    }

    public static void renderEntity(class_897 renderer, class_10017 state, class_4587 matrices, Object vcp, int light) {
        if (state instanceof class_10042 && vcp instanceof class_4597) {
            renderRagdollEntity(renderer, (class_10042) state, matrices, (class_4597) vcp, light);
        }
    }

    public static void renderFirstPersonItem(
        class_759 renderer, class_1309 entity, class_1799 stack, class_811 mode,
        boolean leftHanded, class_4587 matrices, Object vcp, int light
    ) {
        renderHeldItem(renderer, entity, stack, mode, leftHanded, matrices, vcp, light);
    }

    public static void renderItem(
        class_918 renderer, class_1309 entity, class_1799 stack, class_811 mode,
        boolean leftHanded, class_4587 matrices, Object vcp, class_1937 world,
        int light, int overlay, int seed
    ) {
        renderItemFallback(renderer, entity, stack, mode, leftHanded, matrices, vcp, world, light, overlay, seed);
    }

    public static void deferChinaHatRender(
        xyz.angames.dolphy.client.effects.ChinaHatFeatureRenderer renderer,
        class_4587 matrices,
        int light,
        class_10017 state,
        float limbAngle,
        float limbDistance
    ) {
        if (renderer == null || matrices == null || !(state instanceof class_10055)) return;
        final class_10055 playerState = (class_10055) state;
        final Matrix4f entityMat = new Matrix4f(matrices.method_23760().method_23761());
        final class_1657 capturedPlayer = xyz.angames.dolphy.client.effects.ChinaHatFeatureRenderer.currentlyRenderingPlayer;
        deferWorldRender(() -> {
            try {
                class_310 mc = class_310.method_1551();
                class_1657 player = null;
                if (mc != null && mc.field_1687 != null) {
                    class_1297 ent = mc.field_1687.method_8469(playerState.field_53528);
                    if (ent instanceof class_1657) {
                        player = (class_1657) ent;
                    }
                }
                if (player == null) {
                    player = capturedPlayer;
                }
                xyz.angames.dolphy.client.effects.ChinaHatFeatureRenderer.currentlyRenderingPlayer = player;
                class_583 model = renderer.method_17165();
                if (model != null) {
                    model.method_2819(playerState);
                }
                class_4587 deferredStack = new class_4587();
                deferredStack.method_23760().method_23761().set(worldViewMat).mul(entityMat);
                renderer.render(deferredStack, getImmediateVertexConsumers(), light, playerState, limbAngle, limbDistance);
            } catch (Throwable ignored) {}
        });
    }
}



