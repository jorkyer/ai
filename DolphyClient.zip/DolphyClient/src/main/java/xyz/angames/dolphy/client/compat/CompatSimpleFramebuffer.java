package xyz.angames.dolphy.client.compat;

import net.minecraft.class_6367;

public class CompatSimpleFramebuffer extends class_6367 {
    public CompatSimpleFramebuffer(int width, int height, boolean useDepth) {
        super("dolphy_fbo", width, height, useDepth);
    }

    public CompatSimpleFramebuffer(String name, int width, int height, boolean useDepth) {
        super(name, width, height, useDepth);
    }
}
