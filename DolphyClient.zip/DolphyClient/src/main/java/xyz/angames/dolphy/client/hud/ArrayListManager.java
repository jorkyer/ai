package xyz.angames.dolphy.client.hud;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import dev.sxmurxy.mre.builders.Builder;
import dev.sxmurxy.mre.builders.states.QuadColorState;
import dev.sxmurxy.mre.builders.states.QuadRadiusState;
import dev.sxmurxy.mre.builders.states.SizeState;
import dev.sxmurxy.mre.msdf.MsdfFont;
import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix4f;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.config.ThemeManager;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.modules.render.InterfaceModule;
import xyz.angames.dolphy.client.util.DrawUtil;

@Environment(EnvType.CLIENT)
public class ArrayListManager {
   private final MinecraftClient client = MinecraftClient.getInstance();
   private static final Supplier<MsdfFont> SEMIBOLD_FONT = Suppliers.memoize(() -> MsdfFont.builder().atlas("semibold").data("semibold").build());

   public void render(DrawContext context) {
      MsdfFont semibold = (MsdfFont)SEMIBOLD_FONT.get();
      if (semibold != null) {
         double currentGuiScale = this.client.getWindow().getScaleFactor();
         if (currentGuiScale <= 0.0) {
            currentGuiScale = 2.0;
         }

         float scaleModifier = (float)(2.0 / currentGuiScale);
         context.getMatrices().push();
         context.getMatrices().scale(scaleModifier, scaleModifier, 1.0F);
         Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
         float guiWidth = this.client.getWindow().getScaledWidth() / scaleModifier;
         List<Module> enabledModules = DolphyClient.moduleManager
            .getModules()
            .stream()
            .filter(Module::isEnabled)
            .filter(modulex -> !(modulex instanceof InterfaceModule))
            .sorted(Comparator.<Module>comparingDouble(m -> semibold.getWidth(m.getName(), 7.5F)).reversed())
            .collect(Collectors.toList());
         float appear = DrawUtil.getHudAppearAnim();
         float y = 3.0F;
         long timeOffset = 0L;
         float textSize = 7.5F;
         float height = 14.0F;
         float paddingX = 5.5F;

         for (Module module : enabledModules) {
            String name = module.getName();
            float textW = semibold.getWidth(name, textSize);
            float pillW = paddingX + textW + paddingX + 2.0F;
            float pillX = guiWidth - pillW - 3.0F;
            Color baseAccent = new Color(ThemeManager.getThemedColor(timeOffset));
            Color accentColor = new Color(baseAccent.getRed(), baseAccent.getGreen(), baseAccent.getBlue(), Math.max(0, Math.min(255, (int)(255.0F * appear))));

            context.getMatrices().push();
            float animScale = 0.92F + 0.08F * appear;
            if (animScale < 0.999F) {
               float cx = pillX + pillW * 0.5F;
               float cy = y + height * 0.5F;
               context.getMatrices().translate(cx, cy, 0.0F);
               context.getMatrices().scale(animScale, animScale, 1.0F);
               context.getMatrices().translate(-cx, -cy, 0.0F);
            }
            Matrix4f pillMat = context.getMatrices().peek().getPositionMatrix();

            for (int i = 2; i > 0; i--) {
               float progress = i / 2.0F;
               float spread = progress * 3.5F;
               int alpha = (int)(60.0F * (1.0F - progress) * (1.0F - progress) * appear);
               if (alpha > 0) {
                  Builder.rectangle()
                     .size(new SizeState(pillW + spread * 2.0F, height + spread * 2.0F))
                     .radius(new QuadRadiusState(4.0F + spread))
                     .color(new QuadColorState(new Color(0, 0, 0, alpha)))
                     .build()
                     .render(pillMat, pillX - spread, y - spread + 0.5F);
               }
            }

            DrawUtil.drawHudBackground(pillMat, pillX, y, pillW, height, 4.0F, appear);
            Builder.rectangle()
               .size(new SizeState(1.5F, height - 4.0F))
               .radius(new QuadRadiusState(0.75F))
               .color(new QuadColorState(accentColor))
               .build()
               .render(pillMat, pillX + pillW - 2.5F, y + 2.0F);
            float textY = y + height / 2.0F - 2.7F;
            Builder.text().font(semibold).text(name).color(accentColor).size(textSize).build().render(pillMat, pillX + paddingX, textY);
            context.getMatrices().pop();
            y += height + 2.5F;
            timeOffset += 180L;
         }

         context.getMatrices().pop();
      }
   }
}
