package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_11910;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.FreeLookModule;
import xyz.angames.dolphy.client.module.modules.render.KeystrokesModule;

@Mixin(class_312.class)
public class MouseButtonMixin {
    @Inject(method = "method_1601", at = @At("HEAD"))
    private void onMouseButton(long window, class_11910 input, int action, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client == null || input == null || window != client.method_22683().method_4490()) return;
        int button = input.comp_4800();
        if (action == 1 && client.field_1755 == null) {
            KeystrokesModule keystrokes = DolphyClient.getInstance().getModuleManager().getModule(KeystrokesModule.class);
            if (keystrokes != null) {
                if (button == 0) keystrokes.registerLeftClick();
                else if (button == 1) keystrokes.registerRightClick();
            }
            DolphyClient.getInstance().onMousePress(button);
        } else if (action == 0) {
            FreeLookModule freeLook = DolphyClient.getInstance().getModuleManager().getModule(FreeLookModule.class);
            if (freeLook != null && freeLook.isEnabled() && freeLook.isFreeLooking() && !freeLook.isToggleMode()) {
                if (freeLook.getKeyBind() == -100 - button) {
                    freeLook.stopFreeLook();
                }
            }
        }
    }
}
