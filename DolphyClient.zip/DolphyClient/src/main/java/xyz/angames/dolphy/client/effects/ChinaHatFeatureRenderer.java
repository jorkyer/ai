package xyz.angames.dolphy.client.effects;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.config.ThemeManager;
import xyz.angames.dolphy.client.module.modules.render.BandanaModule;
import xyz.angames.dolphy.client.module.modules.render.ChinaHatModule;
import xyz.angames.dolphy.client.module.modules.render.LunarHatModule;
import xyz.angames.dolphy.client.util.FriendManager;

@Environment(EnvType.CLIENT)
public class ChinaHatFeatureRenderer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
   public static PlayerEntity currentlyRenderingPlayer;
   private static final Identifier BLOOM_TEXTURE = Identifier.of("dolphy", "textures/effects/dashtrail/dashbloom.png");
   private float spinAngle = 0.0F;
   private long lastRenderTime = 0L;

   public ChinaHatFeatureRenderer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
      super(context);
   }

   private boolean shouldRenderForPlayer(MinecraftClient mc, boolean selfAllowed, boolean friendsAllowed) {
      if (currentlyRenderingPlayer == null || mc.player == null) {
         return false;
      }
      if (currentlyRenderingPlayer.getId() == mc.player.getId()) {
         return selfAllowed;
      }
      return friendsAllowed && FriendManager.isFriend(currentlyRenderingPlayer.getName().getString());
   }

   @Override
   public void render(
      MatrixStack matrices,
      VertexConsumerProvider vertexConsumers,
      int light,
      PlayerEntityRenderState state,
      float limbAngle,
      float limbDistance
   ) {
      if (state.invisible || DolphyClient.moduleManager == null) {
         return;
      }

      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null || currentlyRenderingPlayer == null) {
         return;
      }

      ChinaHatModule chinaHat = (ChinaHatModule)DolphyClient.moduleManager.getModuleByName("ChinaHat");
      LunarHatModule lunarHat = (LunarHatModule)DolphyClient.moduleManager.getModuleByName("LunarHat");
      BandanaModule bandana = (BandanaModule)DolphyClient.moduleManager.getModuleByName("Bandana");

      boolean doChinaHat = chinaHat != null && chinaHat.isEnabled() && this.shouldRenderForPlayer(mc, chinaHat.self.get(), chinaHat.friends.get());
      boolean doLunarHat = lunarHat != null && lunarHat.isEnabled() && this.shouldRenderForPlayer(mc, lunarHat.self.get(), lunarHat.friends.get());
      boolean doBandana = bandana != null && bandana.isEnabled() && this.shouldRenderForPlayer(mc, bandana.self.get(), bandana.friends.get());

      if (!doChinaHat && !doLunarHat && !doBandana) {
         return;
      }

      if (vertexConsumers instanceof VertexConsumerProvider.Immediate immediate) {
         immediate.draw();
      }

      long now = System.currentTimeMillis();
      if (this.lastRenderTime != 0L) {
         this.spinAngle = (this.spinAngle + (float)(now - this.lastRenderTime) / 1000.0F * 80.0F) % 360.0F;
      }
      this.lastRenderTime = now;

      if (doChinaHat) {
         this.renderChinaHat(matrices, now);
      }
      if (doBandana) {
         this.renderBandana(matrices, bandana, now, limbDistance);
      }
      if (doLunarHat) {
         this.renderLunarHat(matrices, lunarHat, now, limbDistance);
      }
   }

   private void renderBandana(MatrixStack matrices, BandanaModule mod, long now, float limbDistance) {
      matrices.push();
      ((PlayerEntityModel)(Object)this.getContextModel()).head.rotate(matrices);
      // Flip Y so +Y is UP, and origin is neck pivot (top of head is Y = +0.50F)
      matrices.scale(1.0F, -1.0F, 1.0F);
      Matrix4f m = matrices.peek().getPositionMatrix();

      RenderSystem.enableBlend();
      RenderSystem.disableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(true);
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

      Color mainCol = this.resolveCosmeticColor(mod.colorMode.get(), now, 0);
      Color accentCol = this.resolveCosmeticColor(mod.colorMode.get(), now, 60);
      Color darkEdge = this.lerpColor(mainCol, new Color(15, 15, 22), 0.45F);
      Color trimWhite = new Color(245, 245, 252);

      BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

      // 1. Snug 3D Bandana Wrap around forehead (x: -0.266..0.266, y: 0.31..0.41, z: -0.266..0.266)
      float r = 0.266F;
      float yBot = 0.315F;
      float yTop = 0.405F;
      this.drawBandWrap(buf, m, -r, yBot, -r, r, yTop, r, mainCol, darkEdge);
      // Lunar-style center trim stripe around the headband
      float rTrim = 0.268F;
      this.drawBandWrap(buf, m, -rTrim, 0.352F, -rTrim, rTrim, 0.368F, rTrim, trimWhite, accentCol);

      // 2. 3D Knot at the back of the head (z = +0.275F, y = 0.355F)
      this.drawBox3D(buf, m, -0.048F, 0.320F, 0.258F, 0.048F, 0.395F, 0.305F, mainCol, darkEdge);

      // 3. Two animated fluttering cloth tails behind the knot
      float speed = (float)mod.waveSpeed.get();
      float tSec = (now % 100000L) / 1000.0F * 4.5F * speed;
      int segs = 6;
      float segLen = 0.058F;
      for (int tail = -1; tail <= 1; tail += 2) {
         float prevX = tail * 0.028F;
         float prevY = 0.345F;
         float prevZ = 0.295F;
         float prevW = 0.036F;

         for (int s = 1; s <= segs; s++) {
            float frac = (float)s / segs;
            float waveX = (float)Math.sin(tSec - s * 0.65F + tail * 0.8F) * (0.025F + limbDistance * 0.04F) * frac;
            float waveZ = (float)Math.cos(tSec * 0.85F - s * 0.55F) * 0.015F * frac;
            float curX = tail * (0.028F + frac * 0.075F) + waveX;
            float curY = 0.345F - s * segLen + limbDistance * 0.06F * frac;
            float curZ = 0.295F + frac * (0.095F + limbDistance * 0.14F) + waveZ;
            float curW = 0.036F * (1.0F - frac * 0.55F);

            Color c0 = this.lerpColor(mainCol, accentCol, (float)(s - 1) / segs);
            Color c1 = this.lerpColor(mainCol, accentCol, frac);

            this.putPosCol(buf, m, prevX - prevW, prevY, prevZ, c0, 1.0F);
            this.putPosCol(buf, m, prevX + prevW, prevY, prevZ, c0, 1.0F);
            this.putPosCol(buf, m, curX + curW, curY, curZ, c1, 1.0F);
            this.putPosCol(buf, m, curX - curW, curY, curZ, c1, 1.0F);

            prevX = curX;
            prevY = curY;
            prevZ = curZ;
            prevW = curW;
         }
      }

      BufferRenderer.drawWithGlobalProgram(buf.end());
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
      matrices.pop();
   }

   private void renderLunarHat(MatrixStack matrices, LunarHatModule mod, long now, float limbDistance) {
      matrices.push();
      ((PlayerEntityModel)(Object)this.getContextModel()).head.rotate(matrices);
      // Flip Y so +Y is UP, top of head is at Y = 0.50F
      matrices.scale(1.0F, -1.0F, 1.0F);

      float scale = (float)mod.scale.get();
      float bob = mod.bobbing.get() ? (float)Math.sin((now % 100000L) / 1000.0 * 2.8) * 0.018F : 0.0F;
      matrices.translate(0.0F, 0.505F + bob, 0.0F);
      matrices.scale(scale, scale, scale);

      Matrix4f m = matrices.peek().getPositionMatrix();
      RenderSystem.enableBlend();
      RenderSystem.disableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(true);
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

      Color mainCol = this.resolveCosmeticColor(mod.colorMode.get(), now, 0);
      Color accentCol = this.resolveCosmeticColor(mod.colorMode.get(), now, 80);
      String style = mod.style.get();

      if ("King Crown".equalsIgnoreCase(style)) {
         this.drawKingCrown(m, mainCol, accentCol, now);
      } else if ("Angel Halo".equalsIgnoreCase(style)) {
         this.drawAngelHalo(m, mainCol, accentCol, now);
      } else if ("Devil Horns".equalsIgnoreCase(style)) {
         this.drawDevilHorns(m, mainCol, accentCol);
      } else if ("Top Hat".equalsIgnoreCase(style)) {
         this.drawTopHat(m, mainCol, accentCol);
      } else if ("Wizard Hat".equalsIgnoreCase(style)) {
         this.drawWizardHat(m, mainCol, accentCol);
      } else if ("Bunny Ears".equalsIgnoreCase(style)) {
         this.drawBunnyEars(m, mainCol, now, limbDistance);
      } else if ("Deadmau5".equalsIgnoreCase(style)) {
         this.drawDeadmau5Ears(m, mainCol, accentCol);
      }

      RenderSystem.depthMask(true);
      RenderSystem.enableCull();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
      matrices.pop();
   }

   private void drawKingCrown(Matrix4f m, Color mainCol, Color gemCol, long now) {
      // Classic Lunar Client Golden Royal Crown with 8 spikes, velvet inner cushion & glowing gems
      Color goldBright = new Color(255, 215, 65);
      Color goldDark = new Color(205, 148, 22);
      Color velvetRed = new Color(165, 22, 38);
      if (!"Theme".equalsIgnoreCase(gemCol.toString()) && mainCol.getRed() != 255) {
         // Keep crown golden with theme-colored gems, or tint gold slightly toward theme
         goldBright = this.lerpColor(goldBright, mainCol, 0.22F);
      }

      int sides = 16;
      float rOuter = 0.235F;
      float rInner = 0.212F;
      float baseH = 0.085F;
      float spikeH = 0.175F;

      BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

      // 1. Velvet inner cushion dome
      for (int i = 0; i < sides; i++) {
         double a0 = (Math.PI * 2) * i / sides;
         double a1 = (Math.PI * 2) * (i + 1) / sides;
         float x0 = (float)Math.cos(a0) * rInner;
         float z0 = (float)Math.sin(a0) * rInner;
         float x1 = (float)Math.cos(a1) * rInner;
         float z1 = (float)Math.sin(a1) * rInner;
         this.putPosCol(buf, m, x0, 0.01F, z0, velvetRed, 1.0F);
         this.putPosCol(buf, m, x1, 0.01F, z1, velvetRed, 1.0F);
         this.putPosCol(buf, m, 0.0F, 0.095F, 0.0F, velvetRed.darker(), 1.0F);
         this.putPosCol(buf, m, 0.0F, 0.095F, 0.0F, velvetRed.darker(), 1.0F);
      }

      // 2. Golden crown band + 8 pointed spikes
      for (int i = 0; i < sides; i++) {
         double a0 = (Math.PI * 2) * i / sides;
         double a1 = (Math.PI * 2) * (i + 1) / sides;
         double aMid = (a0 + a1) * 0.5;
         float x0 = (float)Math.cos(a0) * rOuter;
         float z0 = (float)Math.sin(a0) * rOuter;
         float x1 = (float)Math.cos(a1) * rOuter;
         float z1 = (float)Math.sin(a1) * rOuter;

         Color cBand = i % 2 == 0 ? goldBright : goldDark;
         this.putPosCol(buf, m, x0, 0.0F, z0, goldDark, 1.0F);
         this.putPosCol(buf, m, x1, 0.0F, z1, goldDark, 1.0F);
         this.putPosCol(buf, m, x1, baseH, z1, cBand, 1.0F);
         this.putPosCol(buf, m, x0, baseH, z0, cBand, 1.0F);

         // Every 2nd segment forms a royal crown spike
         if (i % 2 == 0) {
            double aNext = (Math.PI * 2) * (i + 2) / sides;
            double aPeak = (a0 + aNext) * 0.5;
            float x2 = (float)Math.cos(aNext) * rOuter;
            float z2 = (float)Math.sin(aNext) * rOuter;
            float xp = (float)Math.cos(aPeak) * (rOuter * 1.05F);
            float zp = (float)Math.sin(aPeak) * (rOuter * 1.05F);

            this.putPosCol(buf, m, x0, baseH, z0, goldDark, 1.0F);
            this.putPosCol(buf, m, x2, baseH, z2, goldDark, 1.0F);
            this.putPosCol(buf, m, xp, spikeH, zp, goldBright, 1.0F);
            this.putPosCol(buf, m, xp, spikeH, zp, goldBright, 1.0F);

            // Glowing gem on the crown band below each spike
            float gx = (float)Math.cos(aPeak) * (rOuter + 0.012F);
            float gz = (float)Math.sin(aPeak) * (rOuter + 0.012F);
            float gw = 0.022F;
            Color gem = (i / 2) % 2 == 0 ? mainCol : gemCol;
            this.drawBox3D(buf, m, gx - gw, 0.026F, gz - gw, gx + gw, 0.064F, gz + gw, gem, Color.WHITE);
         }
      }

      BufferRenderer.drawWithGlobalProgram(buf.end());
   }

   private void drawAngelHalo(Matrix4f m, Color mainCol, Color accentCol, long now) {
      float hoverY = 0.14F + (float)Math.sin((now % 100000L) / 1000.0 * 3.4) * 0.022F;
      float majorR = 0.24F;
      float minorR = 0.026F;
      int segs = 28;
      int rings = 8;

      BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      for (int i = 0; i < segs; i++) {
         double u0 = (Math.PI * 2) * i / segs;
         double u1 = (Math.PI * 2) * (i + 1) / segs;
         Color cSeg = this.lerpColor(mainCol, accentCol, (float)(Math.sin(u0) * 0.5 + 0.5));
         for (int j = 0; j < rings; j++) {
            double v0 = (Math.PI * 2) * j / rings;
            double v1 = (Math.PI * 2) * (j + 1) / rings;
            this.putTorusVertex(buf, m, majorR, minorR, hoverY, u0, v0, cSeg);
            this.putTorusVertex(buf, m, majorR, minorR, hoverY, u1, v0, cSeg);
            this.putTorusVertex(buf, m, majorR, minorR, hoverY, u1, v1, Color.WHITE);
            this.putTorusVertex(buf, m, majorR, minorR, hoverY, u0, v1, Color.WHITE);
         }
      }
      BufferRenderer.drawWithGlobalProgram(buf.end());

      // Soft additive halo glow
      RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
      RenderSystem.depthMask(false);
      BufferBuilder glowBuf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      for (int i = 0; i < segs; i++) {
         double u0 = (Math.PI * 2) * i / segs;
         double u1 = (Math.PI * 2) * (i + 1) / segs;
         for (int j = 0; j < rings; j++) {
            double v0 = (Math.PI * 2) * j / rings;
            double v1 = (Math.PI * 2) * (j + 1) / rings;
            this.putTorusVertexAlpha(glowBuf, m, majorR, minorR * 2.1F, hoverY, u0, v0, mainCol, 0.28F);
            this.putTorusVertexAlpha(glowBuf, m, majorR, minorR * 2.1F, hoverY, u1, v0, mainCol, 0.28F);
            this.putTorusVertexAlpha(glowBuf, m, majorR, minorR * 2.1F, hoverY, u1, v1, mainCol, 0.28F);
            this.putTorusVertexAlpha(glowBuf, m, majorR, minorR * 2.1F, hoverY, u0, v1, mainCol, 0.28F);
         }
      }
      BufferRenderer.drawWithGlobalProgram(glowBuf.end());
   }

   private void putTorusVertex(BufferBuilder buf, Matrix4f m, float R, float r, float yOff, double u, double v, Color c) {
      this.putTorusVertexAlpha(buf, m, R, r, yOff, u, v, c, 1.0F);
   }

   private void putTorusVertexAlpha(BufferBuilder buf, Matrix4f m, float R, float r, float yOff, double u, double v, Color c, float a) {
      float rad = R + r * (float)Math.cos(v);
      float x = rad * (float)Math.cos(u);
      float z = rad * (float)Math.sin(u);
      float y = yOff + r * (float)Math.sin(v);
      this.putPosCol(buf, m, x, y, z, c, a);
   }

   private void drawDevilHorns(Matrix4f m, Color mainCol, Color accentCol) {
      Color baseDark = new Color(24, 14, 20);
      BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      int segs = 7;
      int sides = 8;

      for (int side = -1; side <= 1; side += 2) {
         for (int s = 0; s < segs; s++) {
            float t0 = (float)s / segs;
            float t1 = (float)(s + 1) / segs;

            float r0 = 0.058F * (1.0F - t0 * 0.88F);
            float r1 = 0.058F * (1.0F - t1 * 0.88F);

            float cx0 = side * (0.165F + (float)Math.sin(t0 * 2.2F) * 0.11F - t0 * t0 * 0.09F);
            float cy0 = -0.02F + t0 * 0.26F;
            float cz0 = -0.06F - (float)Math.sin(t0 * 1.6F) * 0.05F;

            float cx1 = side * (0.165F + (float)Math.sin(t1 * 2.2F) * 0.11F - t1 * t1 * 0.09F);
            float cy1 = -0.02F + t1 * 0.26F;
            float cz1 = -0.06F - (float)Math.sin(t1 * 1.6F) * 0.05F;

            Color c0 = this.lerpColor(baseDark, mainCol, t0);
            Color c1 = this.lerpColor(baseDark, accentCol, t1);

            for (int i = 0; i < sides; i++) {
               double a0 = (Math.PI * 2) * i / sides;
               double a1 = (Math.PI * 2) * (i + 1) / sides;
               this.putPosCol(buf, m, cx0 + (float)Math.cos(a0) * r0, cy0, cz0 + (float)Math.sin(a0) * r0, c0, 1.0F);
               this.putPosCol(buf, m, cx0 + (float)Math.cos(a1) * r0, cy0, cz0 + (float)Math.sin(a1) * r0, c0, 1.0F);
               this.putPosCol(buf, m, cx1 + (float)Math.cos(a1) * r1, cy1, cz1 + (float)Math.sin(a1) * r1, c1, 1.0F);
               this.putPosCol(buf, m, cx1 + (float)Math.cos(a0) * r1, cy1, cz1 + (float)Math.sin(a0) * r1, c1, 1.0F);
            }
         }
      }
      BufferRenderer.drawWithGlobalProgram(buf.end());
   }

   private void drawTopHat(Matrix4f m, Color mainCol, Color accentCol) {
      Color silkBlack = new Color(20, 20, 26);
      Color silkHighlight = new Color(38, 38, 48);
      int sides = 24;
      BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

      // 1. Wide circular brim (r = 0.34F, h = 0.0..0.028F)
      this.drawCylinder(buf, m, 0.34F, 0.34F, 0.0F, 0.028F, sides, silkBlack, silkHighlight, true);
      // 2. Theme-colored satin ribbon band (r = 0.228F, h = 0.028F..0.085F)
      this.drawCylinder(buf, m, 0.228F, 0.230F, 0.028F, 0.085F, sides, mainCol, accentCol, false);
      // 3. Tall silk top hat cylinder (r = 0.224F -> 0.242F, h = 0.085F..0.34F)
      this.drawCylinder(buf, m, 0.224F, 0.242F, 0.085F, 0.34F, sides, silkBlack, silkHighlight, true);

      BufferRenderer.drawWithGlobalProgram(buf.end());
   }

   private void drawWizardHat(Matrix4f m, Color mainCol, Color accentCol) {
      Color darkFabric = new Color(26, 20, 42);
      Color goldBuckle = new Color(255, 210, 65);
      int sides = 20;
      BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

      // Wide wizard brim
      this.drawCylinder(buf, m, 0.42F, 0.24F, 0.0F, 0.025F, sides, darkFabric, mainCol, true);
      // Ribbon band + golden front buckle
      this.drawCylinder(buf, m, 0.238F, 0.225F, 0.022F, 0.068F, sides, mainCol, accentCol, false);
      this.drawBox3D(buf, m, -0.045F, 0.022F, -0.248F, 0.045F, 0.072F, -0.228F, goldBuckle, Color.WHITE);

      // Bent conical wizard spire
      int segs = 6;
      for (int s = 0; s < segs; s++) {
         float t0 = (float)s / segs;
         float t1 = (float)(s + 1) / segs;
         float r0 = 0.225F * (1.0F - t0 * 0.94F);
         float r1 = 0.225F * (1.0F - t1 * 0.94F);
         float y0 = 0.065F + t0 * 0.36F;
         float y1 = 0.065F + t1 * 0.36F;
         float zOff0 = t0 * t0 * 0.14F;
         float zOff1 = t1 * t1 * 0.14F;
         Color c0 = this.lerpColor(darkFabric, mainCol, t0 * 0.65F);
         Color c1 = this.lerpColor(darkFabric, accentCol, t1 * 0.65F);

         for (int i = 0; i < sides; i++) {
            double a0 = (Math.PI * 2) * i / sides;
            double a1 = (Math.PI * 2) * (i + 1) / sides;
            this.putPosCol(buf, m, (float)Math.cos(a0) * r0, y0, zOff0 + (float)Math.sin(a0) * r0, c0, 1.0F);
            this.putPosCol(buf, m, (float)Math.cos(a1) * r0, y0, zOff0 + (float)Math.sin(a1) * r0, c0, 1.0F);
            this.putPosCol(buf, m, (float)Math.cos(a1) * r1, y1, zOff1 + (float)Math.sin(a1) * r1, c1, 1.0F);
            this.putPosCol(buf, m, (float)Math.cos(a0) * r1, y1, zOff1 + (float)Math.sin(a0) * r1, c1, 1.0F);
         }
      }
      BufferRenderer.drawWithGlobalProgram(buf.end());
   }

   private void drawBunnyEars(Matrix4f m, Color mainCol, long now, float limbDistance) {
      Color furWhite = new Color(248, 248, 252);
      Color furShade = new Color(220, 222, 232);
      Color innerPink = this.lerpColor(new Color(255, 155, 185), mainCol, 0.45F);
      BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

      float wiggle = (float)Math.sin((now % 100000L) / 1000.0 * 4.5) * (0.015F + limbDistance * 0.03F);
      for (int side = -1; side <= 1; side += 2) {
         float cx = side * 0.125F;
         float tiltX = side * 0.025F + side * wiggle;
         // Lower ear segment
         this.drawBox3D(buf, m, cx - 0.052F, -0.01F, -0.028F, cx + 0.052F, 0.16F, 0.028F, furWhite, furShade);
         // Inner pink pad
         this.drawBox3D(buf, m, cx - 0.032F, 0.01F, -0.032F, cx + 0.032F, 0.25F, -0.025F, innerPink, mainCol);
         // Upper ear segment
         this.drawBox3D(buf, m, cx + tiltX - 0.044F, 0.15F, -0.024F, cx + tiltX + 0.044F, 0.29F, 0.024F, furWhite, furShade);
      }
      BufferRenderer.drawWithGlobalProgram(buf.end());
   }

   private void drawDeadmau5Ears(Matrix4f m, Color mainCol, Color accentCol) {
      BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      int sides = 20;
      float earR = 0.20F;
      float depth = 0.045F;

      for (int side = -1; side <= 1; side += 2) {
         float cx = side * 0.25F;
         float cy = 0.12F;
         for (int i = 0; i < sides; i++) {
            double a0 = (Math.PI * 2) * i / sides;
            double a1 = (Math.PI * 2) * (i + 1) / sides;
            float x0 = cx + (float)Math.cos(a0) * earR;
            float y0 = cy + (float)Math.sin(a0) * earR;
            float x1 = cx + (float)Math.cos(a1) * earR;
            float y1 = cy + (float)Math.sin(a1) * earR;

            // Front disc
            this.putPosCol(buf, m, cx, cy, -depth, mainCol, 1.0F);
            this.putPosCol(buf, m, x0, y0, -depth, accentCol, 1.0F);
            this.putPosCol(buf, m, x1, y1, -depth, accentCol, 1.0F);
            this.putPosCol(buf, m, cx, cy, -depth, mainCol, 1.0F);

            // Back disc
            this.putPosCol(buf, m, cx, cy, depth, mainCol, 1.0F);
            this.putPosCol(buf, m, x1, y1, depth, accentCol, 1.0F);
            this.putPosCol(buf, m, x0, y0, depth, accentCol, 1.0F);
            this.putPosCol(buf, m, cx, cy, depth, mainCol, 1.0F);

            // Rim
            this.putPosCol(buf, m, x0, y0, -depth, accentCol, 1.0F);
            this.putPosCol(buf, m, x1, y1, -depth, accentCol, 1.0F);
            this.putPosCol(buf, m, x1, y1, depth, mainCol, 1.0F);
            this.putPosCol(buf, m, x0, y0, depth, mainCol, 1.0F);
         }
      }
      BufferRenderer.drawWithGlobalProgram(buf.end());
   }

   private void drawCylinder(
      BufferBuilder buf, Matrix4f m, float rBot, float rTop, float yBot, float yTop, int sides, Color cBot, Color cTop, boolean capTop
   ) {
      for (int i = 0; i < sides; i++) {
         double a0 = (Math.PI * 2) * i / sides;
         double a1 = (Math.PI * 2) * (i + 1) / sides;
         float c0 = (float)Math.cos(a0), s0 = (float)Math.sin(a0);
         float c1 = (float)Math.cos(a1), s1 = (float)Math.sin(a1);

         this.putPosCol(buf, m, c0 * rBot, yBot, s0 * rBot, cBot, 1.0F);
         this.putPosCol(buf, m, c1 * rBot, yBot, s1 * rBot, cBot, 1.0F);
         this.putPosCol(buf, m, c1 * rTop, yTop, s1 * rTop, cTop, 1.0F);
         this.putPosCol(buf, m, c0 * rTop, yTop, s0 * rTop, cTop, 1.0F);

         if (capTop) {
            this.putPosCol(buf, m, 0.0F, yTop, 0.0F, cTop, 1.0F);
            this.putPosCol(buf, m, c0 * rTop, yTop, s0 * rTop, cBot, 1.0F);
            this.putPosCol(buf, m, c1 * rTop, yTop, s1 * rTop, cBot, 1.0F);
            this.putPosCol(buf, m, 0.0F, yTop, 0.0F, cTop, 1.0F);
         }
      }
   }

   private void drawBandWrap(BufferBuilder buf, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1, Color cMain, Color cSide) {
      // Front
      this.putPosCol(buf, m, x0, y0, z0, cMain, 1.0F);
      this.putPosCol(buf, m, x1, y0, z0, cMain, 1.0F);
      this.putPosCol(buf, m, x1, y1, z0, cMain, 1.0F);
      this.putPosCol(buf, m, x0, y1, z0, cMain, 1.0F);
      // Back
      this.putPosCol(buf, m, x1, y0, z1, cMain, 1.0F);
      this.putPosCol(buf, m, x0, y0, z1, cMain, 1.0F);
      this.putPosCol(buf, m, x0, y1, z1, cMain, 1.0F);
      this.putPosCol(buf, m, x1, y1, z1, cMain, 1.0F);
      // Left
      this.putPosCol(buf, m, x0, y0, z1, cSide, 1.0F);
      this.putPosCol(buf, m, x0, y0, z0, cSide, 1.0F);
      this.putPosCol(buf, m, x0, y1, z0, cSide, 1.0F);
      this.putPosCol(buf, m, x0, y1, z1, cSide, 1.0F);
      // Right
      this.putPosCol(buf, m, x1, y0, z0, cSide, 1.0F);
      this.putPosCol(buf, m, x1, y0, z1, cSide, 1.0F);
      this.putPosCol(buf, m, x1, y1, z1, cSide, 1.0F);
      this.putPosCol(buf, m, x1, y1, z0, cSide, 1.0F);
   }

   private void drawBox3D(BufferBuilder buf, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1, Color cMain, Color cTop) {
      this.drawBandWrap(buf, m, x0, y0, z0, x1, y1, z1, cMain, cMain.darker());
      // Top
      this.putPosCol(buf, m, x0, y1, z0, cTop, 1.0F);
      this.putPosCol(buf, m, x1, y1, z0, cTop, 1.0F);
      this.putPosCol(buf, m, x1, y1, z1, cTop, 1.0F);
      this.putPosCol(buf, m, x0, y1, z1, cTop, 1.0F);
      // Bottom
      this.putPosCol(buf, m, x0, y0, z1, cMain.darker(), 1.0F);
      this.putPosCol(buf, m, x1, y0, z1, cMain.darker(), 1.0F);
      this.putPosCol(buf, m, x1, y0, z0, cMain.darker(), 1.0F);
      this.putPosCol(buf, m, x0, y0, z0, cMain.darker(), 1.0F);
   }

   private void putPosCol(BufferBuilder buf, Matrix4f m, float x, float y, float z, Color c, float a) {
      buf.vertex(m, x, y, z).color(c.getRed() / 255.0F, c.getGreen() / 255.0F, c.getBlue() / 255.0F, a);
   }

   private Color resolveCosmeticColor(String mode, long now, int offset) {
      if ("Chroma".equalsIgnoreCase(mode)) {
         float hue = (float)((now / 12L + offset) % 360L) / 360.0F;
         return new Color(Color.HSBtoRGB(hue, 0.85F, 1.0F));
      } else if ("Gold".equalsIgnoreCase(mode)) {
         return offset == 0 ? new Color(255, 215, 65) : new Color(255, 165, 30);
      } else if ("Crimson".equalsIgnoreCase(mode) || "Lunar Red".equalsIgnoreCase(mode)) {
         return offset == 0 ? new Color(220, 28, 46) : new Color(255, 75, 90);
      } else if ("White".equalsIgnoreCase(mode)) {
         return offset == 0 ? new Color(248, 248, 255) : new Color(215, 225, 245);
      } else if ("Obsidian".equalsIgnoreCase(mode)) {
         return offset == 0 ? new Color(36, 32, 48) : new Color(90, 70, 140);
      } else {
         return new Color(ThemeManager.getThemedColor((int)(now / 10L) + offset));
      }
   }

   private void renderChinaHat(MatrixStack matrices, long now) {
      matrices.push();
      ((PlayerEntityModel)(Object)this.getContextModel()).head.rotate(matrices);
      matrices.translate(0.0F, -0.4F, 0.0F);
      matrices.scale(1.0F, -1.0F, 1.0F);
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(this.spinAngle));
      Matrix4f matrix = matrices.peek().getPositionMatrix();
      Tessellator tessellator = Tessellator.getInstance();

      RenderSystem.enableBlend();
      RenderSystem.disableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(true);
      RenderSystem.blendFuncSeparate(
         GlStateManager.SrcFactor.SRC_ALPHA,
         GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA,
         GlStateManager.SrcFactor.ONE,
         GlStateManager.DstFactor.ZERO
      );
      ShaderProgram shader = RenderSystem.setShader(DolphyClient.CHINA_HAT_SHADER);
      if (shader != null) {
         float timeSecs = (float)(System.currentTimeMillis() % 1000000L) / 1000.0F;
         if (shader.getUniform("uTime") != null) {
            shader.getUniform("uTime").set(timeSecs);
         }

         if (shader.getUniform("uResolution") != null) {
            shader.getUniform("uResolution").set(1.0F, 1.0F);
         }

         int themeRgb = ThemeManager.getThemedColor((int)(now / 10L));
         float tr = (themeRgb >> 16 & 0xFF) / 255.0F;
         float tg = (themeRgb >> 8 & 0xFF) / 255.0F;
         float tb = (themeRgb & 0xFF) / 255.0F;
         if (shader.getUniform("uThemeColor") != null) {
            shader.getUniform("uThemeColor").set(tr, tg, tb);
         }
      }

      Color cInner = new Color(ThemeManager.getThemedColor((int)(now / 10L)));
      Color cOuter = new Color(ThemeManager.getThemedColor((int)(now / 10L) + 60));
      int optimizedLayers = 16;
      BufferBuilder bufBody = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

      for (int layer = 1; layer < optimizedLayers; layer++) {
         float t0 = (float)(layer - 1) / (optimizedLayers - 1);
         float t1 = (float)layer / (optimizedLayers - 1);
         float r0 = 0.65F * t0;
         float h0 = 0.28F * (1.0F - t0);
         float r1 = 0.65F * t1;
         float h1 = 0.28F * (1.0F - t1);
         Color c0 = this.lerpColor(cInner, cOuter, this.smoothstep(t0));
         Color c1 = this.lerpColor(cInner, cOuter, this.smoothstep(t1));

         for (int i = 0; i < 40; i++) {
            double ang0 = (Math.PI * 2) * i / 40.0;
            double ang1 = (Math.PI * 2) * (i + 1) / 40.0;
            float st = i / 40.0F;
            Color sc0 = this.lerpColor(c0, cOuter, st * 0.25F);
            Color sc1 = this.lerpColor(c1, cOuter, st * 0.25F);
            float u0_0 = (float)Math.cos(ang0) * t0 * 0.5F + 0.5F;
            float v0_0 = (float)Math.sin(ang0) * t0 * 0.5F + 0.5F;
            float u1_0 = (float)Math.cos(ang1) * t0 * 0.5F + 0.5F;
            float v1_0 = (float)Math.sin(ang1) * t0 * 0.5F + 0.5F;
            float u1_1 = (float)Math.cos(ang1) * t1 * 0.5F + 0.5F;
            float v1_1 = (float)Math.sin(ang1) * t1 * 0.5F + 0.5F;
            float u0_1 = (float)Math.cos(ang0) * t1 * 0.5F + 0.5F;
            float v0_1 = (float)Math.sin(ang0) * t1 * 0.5F + 0.5F;
            bufBody.vertex(matrix, (float)Math.cos(ang0) * r0, h0, (float)Math.sin(ang0) * r0)
               .texture(u0_0, v0_0)
               .color(sc0.getRed() / 255.0F, sc0.getGreen() / 255.0F, sc0.getBlue() / 255.0F, 1.0F);
            bufBody.vertex(matrix, (float)Math.cos(ang1) * r0, h0, (float)Math.sin(ang1) * r0)
               .texture(u1_0, v1_0)
               .color(sc0.getRed() / 255.0F, sc0.getGreen() / 255.0F, sc0.getBlue() / 255.0F, 1.0F);
            bufBody.vertex(matrix, (float)Math.cos(ang1) * r1, h1, (float)Math.sin(ang1) * r1)
               .texture(u1_1, v1_1)
               .color(sc1.getRed() / 255.0F, sc1.getGreen() / 255.0F, sc1.getBlue() / 255.0F, 1.0F);
            bufBody.vertex(matrix, (float)Math.cos(ang0) * r1, h1, (float)Math.sin(ang0) * r1)
               .texture(u0_1, v0_1)
               .color(sc1.getRed() / 255.0F, sc1.getGreen() / 255.0F, sc1.getBlue() / 255.0F, 1.0F);
         }
      }

      BufferRenderer.drawWithGlobalProgram(bufBody.end());
      float r = cOuter.getRed() / 255.0F;
      float g = cOuter.getGreen() / 255.0F;
      float b = cOuter.getBlue() / 255.0F;
      float rimW = 0.035F;
      float innerR = 0.65F - rimW;
      float innerH = 0.28F * (rimW / 0.65F);
      float innerT = (0.65F - rimW) / 0.65F;
      BufferBuilder bufRim = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

      for (int i = 0; i < 40; i++) {
         double a0 = (Math.PI * 2) * i / 40.0;
         double a1 = (Math.PI * 2) * (i + 1) / 40.0;
         float u0_in = (float)Math.cos(a0) * innerT * 0.5F + 0.5F;
         float v0_in = (float)Math.sin(a0) * innerT * 0.5F + 0.5F;
         float u1_in = (float)Math.cos(a1) * innerT * 0.5F + 0.5F;
         float v1_in = (float)Math.sin(a1) * innerT * 0.5F + 0.5F;
         float u1_out = (float)Math.cos(a1) * 0.5F + 0.5F;
         float v1_out = (float)Math.sin(a1) * 0.5F + 0.5F;
         float u0_out = (float)Math.cos(a0) * 0.5F + 0.5F;
         float v0_out = (float)Math.sin(a0) * 0.5F + 0.5F;
         bufRim.vertex(matrix, (float)Math.cos(a0) * innerR, innerH, (float)Math.sin(a0) * innerR)
            .texture(u0_in, v0_in)
            .color(r, g, b, 1.0F);
         bufRim.vertex(matrix, (float)Math.cos(a1) * innerR, innerH, (float)Math.sin(a1) * innerR)
            .texture(u1_in, v1_in)
            .color(r, g, b, 1.0F);
         bufRim.vertex(matrix, (float)Math.cos(a1) * 0.65F, 0.0F, (float)Math.sin(a1) * 0.65F)
            .texture(u1_out, v1_out)
            .color(r, g, b, 1.0F);
         bufRim.vertex(matrix, (float)Math.cos(a0) * 0.65F, 0.0F, (float)Math.sin(a0) * 0.65F)
            .texture(u0_out, v0_out)
            .color(r, g, b, 1.0F);
      }

      BufferRenderer.drawWithGlobalProgram(bufRim.end());
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
      RenderSystem.disableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      BufferBuilder glowRimBuf = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      innerR = 0.598F;
      innerH = 0.68899995F;
      innerT = 0.7F;

      for (int i = 0; i < 40; i++) {
         double a0 = (Math.PI * 2) * i / 40.0;
         double a1 = (Math.PI * 2) * (i + 1) / 40.0;
         glowRimBuf.vertex(matrix, (float)Math.cos(a0) * innerR, 0.005F, (float)Math.sin(a0) * innerR).color(r, g, b, innerT);
         glowRimBuf.vertex(matrix, (float)Math.cos(a1) * innerR, 0.005F, (float)Math.sin(a1) * innerR).color(r, g, b, innerT);
         glowRimBuf.vertex(matrix, (float)Math.cos(a1) * innerH, 0.001F, (float)Math.sin(a1) * innerH).color(r, g, b, 0.0F);
         glowRimBuf.vertex(matrix, (float)Math.cos(a0) * innerH, 0.001F, (float)Math.sin(a0) * innerH).color(r, g, b, 0.0F);
      }

      BufferRenderer.drawWithGlobalProgram(glowRimBuf.end());
      RenderSystem.setShaderTexture(0, BLOOM_TEXTURE);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      BufferBuilder bloomBaseBuf = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
      float bSize = 0.663F;
      bloomBaseBuf.vertex(matrix, -bSize, 0.005F, bSize).texture(0.0F, 1.0F).color(r, g, b, 0.4F);
      bloomBaseBuf.vertex(matrix, bSize, 0.005F, bSize).texture(1.0F, 1.0F).color(r, g, b, 0.4F);
      bloomBaseBuf.vertex(matrix, bSize, 0.005F, -bSize).texture(1.0F, 0.0F).color(r, g, b, 0.4F);
      bloomBaseBuf.vertex(matrix, -bSize, 0.005F, -bSize).texture(0.0F, 0.0F).color(r, g, b, 0.4F);
      BufferRenderer.drawWithGlobalProgram(bloomBaseBuf.end());
      matrices.pop();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(true);
      RenderSystem.enableCull();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
   }

   private Color lerpColor(Color a, Color b, float t) {
      t = MathHelper.clamp(t, 0.0F, 1.0F);
      return new Color(
         (int)(a.getRed() + (b.getRed() - a.getRed()) * t),
         (int)(a.getGreen() + (b.getGreen() - a.getGreen()) * t),
         (int)(a.getBlue() + (b.getBlue() - a.getBlue()) * t)
      );
   }

   private float smoothstep(float t) {
      t = MathHelper.clamp(t, 0.0F, 1.0F);
      return t * t * (3.0F - 2.0F * t);
   }
}
