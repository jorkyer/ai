package xyz.angames.dolphy.client.module.modules.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.setting.ModeSetting;

@Environment(EnvType.CLIENT)
public class KillEffectModule extends Module {
   public final ModeSetting mode = new ModeSetting("Mode", "Blood", "Blood", "Zap", "Thanos");

   public KillEffectModule() {
      super("KillEffect", Module.Category.RENDER);
      this.addSetting(this.mode);
   }

   @Override
   public void onTick() {
      DolphyClient.killEffectManager.tick();
   }
}
