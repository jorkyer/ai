package xyz.angames.dolphy.client.compat;

@FunctionalInterface
public interface CompatRenderCall {
    void execute();
}
