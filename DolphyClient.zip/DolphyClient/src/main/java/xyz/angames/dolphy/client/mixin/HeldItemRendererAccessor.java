package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_11659;
import net.minecraft.class_1306;
import net.minecraft.class_4587;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_759.class)
public interface HeldItemRendererAccessor {
    @Accessor("field_4043")
    void setEquipProgressMainHand(float value);

    @Accessor("field_4052")
    void setLastEquipProgressMainHand(float value);

    @Accessor("field_4051")
    void setEquipProgressOffHand(float value);

    @Accessor("field_4053")
    void setLastEquipProgressOffHand(float value);

    @Invoker("method_3219")
    void invokeRenderArmHoldingItem(
        class_4587 matrices,
        class_11659 vertexConsumers,
        int light,
        float equipProgress,
        float swingProgress,
        class_1306 arm
    );
}
