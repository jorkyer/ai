package xyz.angames.dolphy.client.hud;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import dev.sxmurxy.mre.builders.Builder;
import dev.sxmurxy.mre.builders.states.QuadColorState;
import dev.sxmurxy.mre.builders.states.QuadRadiusState;
import dev.sxmurxy.mre.builders.states.SizeState;
import dev.sxmurxy.mre.msdf.MsdfFont;
import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.config.ThemeManager;
import xyz.angames.dolphy.client.gui.HudEditorScreen;
import xyz.angames.dolphy.client.gui.clickgui.GuiUtils;
import xyz.angames.dolphy.client.module.modules.render.InterfaceModule;
import xyz.angames.dolphy.client.module.modules.render.LiquidGlassModule;
import xyz.angames.dolphy.client.util.DrawUtil;

@Environment(EnvType.CLIENT)
public class TestHudManager {
   private static final Supplier<MsdfFont> BOLD_FONT = Suppliers.memoize(() -> MsdfFont.builder().atlas("bold").data("bold").build());
   private static final Supplier<MsdfFont> SEMIBOLD_FONT = Suppliers.memoize(() -> MsdfFont.builder().atlas("semibold").data("semibold").build());
   private static final Supplier<MsdfFont> MEDIUM_FONT = Suppliers.memoize(() -> MsdfFont.builder().atlas("medium").data("medium").build());
   private static final Supplier<MsdfFont> INTERFACE_ICONS = Suppliers.memoize(
      () -> MsdfFont.builder()
         .name("interface_icons_liquidglass")
         .data(Identifier.of("mre", "icons/interface/interface.json"))
         .atlas(Identifier.of("mre", "icons/interface/interface.png"))
         .glyphMapper(g -> 'A' + g.index())
         .build()
   );

   public float x = 12.0F;
   public float y = 78.0F;
   public float width = 186.0F;
   public float height = 96.0F;
   private float currentWidth = 186.0F;
   private float currentHeight = 96.0F;
   private boolean dragging = false;
   private boolean isDragging = false;
   private float dragOffsetX;
   private float dragOffsetY;
   private float animationProgress = 0.0F;
   private double animatedBps = 0.0;
   private float animatedFpsRatio = 0.5F;
   private float animatedSpeedRatio = 0.0F;
   private long lastUpdateTimeNs = -1L;

   private LiquidGlassModule getLiquidGlassModule() {
      if (DolphyClient.moduleManager == null) {
         return null;
      }
      return (LiquidGlassModule)DolphyClient.moduleManager.getModuleByName("LiquidGlass");
   }

   private boolean isHudEnabled() {
      if (DolphyClient.moduleManager == null) {
         return false;
      }
      LiquidGlassModule lgMod = this.getLiquidGlassModule();
      InterfaceModule ifMod = (InterfaceModule)DolphyClient.moduleManager.getModuleByName("Interface");
      boolean lgEnabled = lgMod != null && lgMod.isEnabled();
      boolean ifEnabled = ifMod != null && ifMod.isEnabled() && ifMod.liquidGlassHud.get();
      return lgEnabled || ifEnabled;
   }

   public void render(DrawContext context, float delta) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world == null || mc.player == null) {
         return;
      }

      boolean isEditing = mc.currentScreen instanceof HudEditorScreen;
      if (mc.currentScreen != null && !isEditing) {
         this.animationProgress = 0.0F;
         DrawUtil.notifyScreenOpen();
         return;
      }
      boolean shouldShow = this.isHudEnabled() || isEditing;

      long nowNs = System.nanoTime();
      if (this.lastUpdateTimeNs == -1L) {
         this.lastUpdateTimeNs = nowNs;
      }
      double deltaSeconds = (nowNs - this.lastUpdateTimeNs) / 1.0E9;
      this.lastUpdateTimeNs = nowNs;
      if (deltaSeconds > 0.1) {
         deltaSeconds = 0.1;
      }
      if (deltaSeconds < 0.001) {
         deltaSeconds = 0.001;
      }

      this.animationProgress += ((shouldShow ? 1.0F : 0.0F) - this.animationProgress) * (float)(1.0 - Math.exp(-12.0 * deltaSeconds));
      if (this.animationProgress < 0.01F) {
         return;
      }

      LiquidGlassModule lgMod = this.getLiquidGlassModule();
      String style = lgMod != null ? lgMod.style.get() : "iOS Widget";
      float blurRad = lgMod != null ? (float)lgMod.blurRadius.get() : 9.0F;
      float refraction = lgMod != null ? (float)lgMod.refraction.get() : 0.065F;
      float fresnelPower = lgMod != null ? (float)lgMod.fresnelPower.get() : 2.4F;
      float rimGloss = lgMod != null ? (float)lgMod.rimGloss.get() : 0.88F;
      float glassTint = lgMod != null ? (float)lgMod.glassTint.get() : 0.14F;
      float squircle = lgMod != null ? (float)lgMod.squircle.get() : 2.8F;
      float baseRadius = lgMod != null ? (float)lgMod.cornerRadius.get() : 16.0F;
      boolean useThemeRim = lgMod != null && lgMod.themeRim.get();
      boolean innerGlass = lgMod == null || lgMod.innerGlass.get();

      float targetW;
      float targetH;
      if ("Dynamic Island".equalsIgnoreCase(style)) {
         targetW = 198.0F;
         targetH = 34.0F;
      } else if ("Pure Lens".equalsIgnoreCase(style)) {
         targetW = 160.0F;
         targetH = 92.0F;
      } else {
         targetW = 186.0F;
         targetH = 96.0F;
      }

      this.currentWidth += (targetW - this.currentWidth) * (float)(1.0 - Math.exp(-14.0 * deltaSeconds));
      this.currentHeight += (targetH - this.currentHeight) * (float)(1.0 - Math.exp(-14.0 * deltaSeconds));
      this.width = this.currentWidth;
      this.height = this.currentHeight;

      double dx = mc.player.getX() - mc.player.prevX;
      double dz = mc.player.getZ() - mc.player.prevZ;
      double instBps = Math.sqrt(dx * dx + dz * dz) * 20.0;
      this.animatedBps += (instBps - this.animatedBps) * (1.0 - Math.exp(-10.0 * deltaSeconds));
      if (this.animatedBps < 0.01) {
         this.animatedBps = 0.0;
      }

      int fps = Math.max(1, mc.getCurrentFps());
      int ping = this.getPing(mc);
      String timeStr = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
      String bpsStr = String.format("%.1f", this.animatedBps).replace(',', '.');

      float targetFpsRatio = MathHelper.clamp(fps / 240.0F, 0.08F, 1.0F);
      float targetSpeedRatio = MathHelper.clamp((float)(this.animatedBps / 12.0), 0.06F, 1.0F);
      this.animatedFpsRatio += (targetFpsRatio - this.animatedFpsRatio) * (float)(1.0 - Math.exp(-8.0 * deltaSeconds));
      this.animatedSpeedRatio += (targetSpeedRatio - this.animatedSpeedRatio) * (float)(1.0 - Math.exp(-8.0 * deltaSeconds));

      long nowMs = System.currentTimeMillis();
      Color themeColor = new Color(ThemeManager.getThemedColor(nowMs / 10L));
      Color rimColor = useThemeRim
         ? new Color(
            Math.min(255, (themeColor.getRed() + 255) / 2),
            Math.min(255, (themeColor.getGreen() + 255) / 2),
            Math.min(255, (themeColor.getBlue() + 255) / 2)
         )
         : new Color(248, 252, 255);
      Color glassColor = useThemeRim
         ? new Color(themeColor.getRed(), themeColor.getGreen(), themeColor.getBlue(), 210)
         : new Color(235, 245, 255, 215);

      float scaleModifier = this.getScaleModifier();
      float animScale = 0.92F + 0.08F * this.animationProgress;
      context.getMatrices().push();
      float cx = this.x + this.currentWidth * scaleModifier * 0.5F;
      float cy = this.y + this.currentHeight * scaleModifier * 0.5F;
      context.getMatrices().translate(cx, cy, 0.0F);
      context.getMatrices().scale(scaleModifier * animScale, scaleModifier * animScale, 1.0F);
      context.getMatrices().translate(-this.currentWidth * 0.5F, -this.currentHeight * 0.5F, 0.0F);
      Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();

      float rx = 0.0F;
      float ry = 0.0F;
      float rw = this.currentWidth;
      float rh = this.currentHeight;
      float effectiveRadius = Math.min(baseRadius, Math.min(rw, rh) * 0.48F);

      this.drawLiquidGlassSurface(
         matrix,
         rx,
         ry,
         rw,
         rh,
         effectiveRadius,
         blurRad,
         refraction,
         fresnelPower,
         rimGloss,
         glassTint,
         squircle,
         glassColor,
         rimColor,
         this.animationProgress,
         true
      );

      if ("Dynamic Island".equalsIgnoreCase(style)) {
         this.renderDynamicIslandContent(
            matrix, rx, ry, rw, rh, fps, ping, timeStr, themeColor, rimColor, glassColor, refraction, fresnelPower, squircle, innerGlass, nowMs
         );
      } else if ("Pure Lens".equalsIgnoreCase(style)) {
         this.renderPureLensContent(matrix, rx, ry, rw, rh, fps, ping, bpsStr, timeStr, themeColor, rimColor);
      } else {
         this.renderIosWidgetContent(
            matrix,
            rx,
            ry,
            rw,
            rh,
            fps,
            ping,
            bpsStr,
            timeStr,
            mc.player.getBlockX(),
            mc.player.getBlockY(),
            mc.player.getBlockZ(),
            themeColor,
            rimColor,
            glassColor,
            refraction,
            fresnelPower,
            squircle,
            innerGlass
         );
      }

      context.getMatrices().pop();
   }

   private void drawLiquidGlassSurface(
      Matrix4f matrix,
      float x,
      float y,
      float w,
      float h,
      float radius,
      float blurRad,
      float refraction,
      float fresnelPower,
      float rimGloss,
      float baseTint,
      float squircle,
      Color glassColor,
      Color rimColor,
      float alpha,
      boolean withShadow
   ) {
      if (withShadow) {
         int shadowSteps = 3;
         float maxSpread = 8.5F;
         for (int i = shadowSteps - 1; i >= 0; i--) {
            float p = (float)i / shadowSteps;
            float spread = p * maxSpread;
            float aFactor = (1.0F - p) * (1.0F - p);
            int sAlpha = (int)(68.0F * aFactor * alpha);
            if (sAlpha > 0) {
               Builder.rectangle()
                  .size(new SizeState(w + spread * 2.0F, h + spread * 2.0F))
                  .radius(new QuadRadiusState(radius + spread))
                  .color(new QuadColorState(new Color(0, 6, 18, sAlpha)))
                  .build()
                  .render(matrix, x - spread, y - spread + 1.5F);
            }
         }
      }

      if (blurRad > 0.1F) {
         Builder.rectangle()
            .size(new SizeState(w, h))
            .radius(new QuadRadiusState(radius))
            .color(new QuadColorState(new Color(14, 18, 26, Math.max(12, (int)(48.0F * alpha)))))
            .build()
            .render(matrix, x, y);
      }

      float liquidRadius = Math.min(Math.min(w, h) * 0.49F, radius * Math.max(1.0F, squircle * 0.46F));
      DrawUtil.renderCachedLiquidGlass(
         matrix,
         x,
         y,
         w,
         h,
         new QuadRadiusState(liquidRadius),
         new QuadColorState(glassColor),
         1.0F,
         squircle,
         alpha,
         baseTint,
         fresnelPower,
         rimColor.getRGB(),
         rimGloss,
         0.88F,
         false,
         refraction
      );

      Color topSheen = new Color(255, 255, 255, (int)(32.0F * alpha * rimGloss));
      Color clearSheen = new Color(255, 255, 255, 0);
      Builder.rectangle()
         .size(new SizeState(w - 2.0F, h * 0.44F))
         .radius(new QuadRadiusState(Math.max(2.0F, radius - 1.0F), 2.0F, 2.0F, Math.max(2.0F, radius - 1.0F)))
         .color(new QuadColorState(topSheen, clearSheen, clearSheen, topSheen))
         .build()
         .render(matrix, x + 1.0F, y + 0.8F);

      int rimStrongA = Math.min(255, (int)(195.0F * alpha * rimGloss));
      int rimSoftA = Math.min(255, (int)(58.0F * alpha * rimGloss));
      int rimBottomRightA = Math.min(255, (int)(135.0F * alpha * rimGloss));
      Color cTopLeft = new Color(255, 255, 255, rimStrongA);
      Color cBotLeft = new Color(rimColor.getRed(), rimColor.getGreen(), rimColor.getBlue(), rimSoftA);
      Color cBotRight = new Color(255, 255, 255, rimBottomRightA);
      Color cTopRight = new Color(rimColor.getRed(), rimColor.getGreen(), rimColor.getBlue(), rimSoftA);

      Builder.border()
         .size(new SizeState(w, h))
         .radius(new QuadRadiusState(radius))
         .thickness(0.85F)
         .smoothness(0.8F, 1.0F)
         .color(new QuadColorState(cTopLeft, cBotLeft, cBotRight, cTopRight))
         .build()
         .render(matrix, x, y);
   }

   private void renderIosWidgetContent(
      Matrix4f matrix,
      float x,
      float y,
      float w,
      float h,
      int fps,
      int ping,
      String bpsStr,
      String timeStr,
      int bx,
      int by,
      int bz,
      Color themeColor,
      Color rimColor,
      Color glassColor,
      float refraction,
      float fresnelPower,
      float squircle,
      boolean innerGlass
   ) {
      MsdfFont bold = BOLD_FONT.get();
      MsdfFont semibold = SEMIBOLD_FONT.get();
      MsdfFont medium = MEDIUM_FONT.get();
      MsdfFont logoFont = LogoRenderer.DOLPHY_FONT.get();
      MsdfFont wmIcons = LogoRenderer.WATERMARK_FONT.get();
      MsdfFont ifaceIcons = INTERFACE_ICONS.get();

      float a = this.animationProgress;
      Color white = GuiUtils.withAlpha(Color.WHITE, a);
      Color softWhite = GuiUtils.withAlpha(new Color(230, 238, 250), a * 0.86F);
      Color subLabelCol = GuiUtils.withAlpha(new Color(210, 222, 240), a * 0.72F);
      Color accentCol = GuiUtils.withAlpha(themeColor, a);

      float badgeX = x + 9.0F;
      float badgeY = y + 8.0F;
      float badgeSize = 20.0F;
      if (innerGlass) {
         this.drawLiquidGlassSurface(
            matrix,
            badgeX,
            badgeY,
            badgeSize,
            badgeSize,
            badgeSize * 0.5F,
            0.0F,
            refraction * 0.85F,
            fresnelPower,
            0.9F,
            0.18F,
            squircle,
            glassColor,
            rimColor,
            a,
            false
         );
      } else {
         Builder.rectangle()
            .size(new SizeState(badgeSize, badgeSize))
            .radius(new QuadRadiusState(badgeSize * 0.5F))
            .color(new QuadColorState(new Color(255, 255, 255, (int)(45.0F * a))))
            .build()
            .render(matrix, badgeX, badgeY);
      }

      if (!DrawUtil.drawDolphyAvatar(matrix, badgeX + 1.5F, badgeY + 1.5F, badgeSize - 3.0F, (badgeSize - 3.0F) * 0.5F, a) && logoFont != null) {
         float lw = logoFont.getWidth("A", 11.5F);
         Builder.text()
            .font(logoFont)
            .text("A")
            .size(11.5F)
            .color(white)
            .build()
            .render(matrix, badgeX + (badgeSize - lw) * 0.5F, badgeY + 4.0F);
      }

      float titleX = badgeX + badgeSize + 6.5F;
      if (bold != null) {
         Builder.text().font(bold).text("DolphyVisuals").size(8.5F).color(white).build().render(matrix, titleX, badgeY + 2.0F);
      }
      if (medium != null) {
         Builder.text().font(medium).text("iOS 26 Liquid Glass").size(6.2F).color(subLabelCol).build().render(matrix, titleX, badgeY + 11.5F);
      }

      if (bold != null) {
         float timeW = bold.getWidth(timeStr, 9.5F);
         float timeX = x + w - timeW - 10.0F;
         Builder.text().font(bold).text(timeStr).size(9.5F).color(white).build().render(matrix, timeX, badgeY + 2.5F);
         Builder.rectangle()
            .size(new SizeState(4.0F, 4.0F))
            .radius(new QuadRadiusState(2.0F))
            .color(new QuadColorState(accentCol))
            .build()
            .render(matrix, timeX - 7.0F, badgeY + 5.5F);
         if (medium != null) {
            String liveTxt = "LIVE";
            float lw = medium.getWidth(liveTxt, 5.5F);
            Builder.text().font(medium).text(liveTxt).size(5.5F).color(softWhite).build().render(matrix, x + w - lw - 10.0F, badgeY + 12.5F);
         }
      }

      float cardY = y + 33.5F;
      float cardH = 42.0F;
      float gap = 5.5F;
      float sidePad = 9.0F;
      float cardW = (w - sidePad * 2.0F - gap * 2.0F) / 3.0F;

      String[] labels = new String[]{"FPS", "PING", "SPEED"};
      String[] values = new String[]{String.valueOf(fps), ping + "ms", bpsStr};
      float[] ratios = new float[]{
         this.animatedFpsRatio,
         MathHelper.clamp(1.0F - ping / 250.0F, 0.15F, 1.0F),
         this.animatedSpeedRatio
      };

      for (int i = 0; i < 3; i++) {
         float cx = x + sidePad + i * (cardW + gap);
         if (innerGlass) {
            this.drawLiquidGlassSurface(
               matrix,
               cx,
               cardY,
               cardW,
               cardH,
               9.5F,
               0.0F,
               refraction * 0.7F,
               fresnelPower,
               0.82F,
               0.16F,
               squircle,
               glassColor,
               rimColor,
               a,
               false
            );
         } else {
            Builder.rectangle()
               .size(new SizeState(cardW, cardH))
               .radius(new QuadRadiusState(9.5F))
               .color(new QuadColorState(new Color(255, 255, 255, (int)(36.0F * a))))
               .build()
               .render(matrix, cx, cardY);
         }

         if (wmIcons != null && i < 2) {
            String ic = i == 0 ? "C" : "D";
            Builder.text().font(wmIcons).text(ic).size(7.0F).color(white).build().render(matrix, cx + 6.0F, cardY + 5.5F);
         } else if (ifaceIcons != null) {
            Builder.text().font(ifaceIcons).text("B").size(6.8F).color(white).build().render(matrix, cx + 6.0F, cardY + 5.5F);
         }

         if (medium != null) {
            Builder.text().font(medium).text(labels[i]).size(5.8F).color(subLabelCol).build().render(matrix, cx + 15.5F, cardY + 6.2F);
         }

         if (bold != null) {
            Builder.text().font(bold).text(values[i]).size(8.2F).color(white).build().render(matrix, cx + 6.0F, cardY + 17.5F);
         }

         float barX = cx + 6.0F;
         float barY = cardY + cardH - 7.5F;
         float barW = cardW - 12.0F;
         float barH = 2.6F;
         Builder.rectangle()
            .size(new SizeState(barW, barH))
            .radius(new QuadRadiusState(barH * 0.5F))
            .color(new QuadColorState(new Color(255, 255, 255, (int)(45.0F * a))))
            .build()
            .render(matrix, barX, barY);

         float fillW = Math.max(barH, barW * ratios[i]);
         Color barFill = new Color(255, 255, 255, (int)(225.0F * a));
         Builder.rectangle()
            .size(new SizeState(fillW, barH))
            .radius(new QuadRadiusState(barH * 0.5F))
            .color(new QuadColorState(barFill, accentCol, accentCol, barFill))
            .build()
            .render(matrix, barX, barY);
      }

      float footerY = y + h - 14.5F;
      if (semibold != null) {
         String coordText = bx + ", " + by + ", " + bz;
         Builder.text().font(semibold).text("XYZ  " + coordText).size(6.2F).color(softWhite).build().render(matrix, x + 10.0F, footerY);
         String bpsTag = bpsStr + " BPS";
         float bw = semibold.getWidth(bpsTag, 6.2F);
         Builder.text().font(semibold).text(bpsTag).size(6.2F).color(softWhite).build().render(matrix, x + w - bw - 10.0F, footerY);
      }

      float homeW = 48.0F;
      float homeH = 2.8F;
      float homeX = x + (w - homeW) * 0.5F;
      float homeY = y + h - 5.2F;
      Builder.rectangle()
         .size(new SizeState(homeW, homeH))
         .radius(new QuadRadiusState(homeH * 0.5F))
         .color(new QuadColorState(new Color(255, 255, 255, (int)(195.0F * a))))
         .build()
         .render(matrix, homeX, homeY);
   }

   private void renderDynamicIslandContent(
      Matrix4f matrix,
      float x,
      float y,
      float w,
      float h,
      int fps,
      int ping,
      String timeStr,
      Color themeColor,
      Color rimColor,
      Color glassColor,
      float refraction,
      float fresnelPower,
      float squircle,
      boolean innerGlass,
      long nowMs
   ) {
      MsdfFont bold = BOLD_FONT.get();
      MsdfFont semibold = SEMIBOLD_FONT.get();
      MsdfFont logoFont = LogoRenderer.DOLPHY_FONT.get();

      float a = this.animationProgress;
      Color white = GuiUtils.withAlpha(Color.WHITE, a);
      Color subWhite = GuiUtils.withAlpha(new Color(225, 235, 250), a * 0.82F);

      float orbSize = 22.0F;
      float orbX = x + 6.0F;
      float orbY = y + (h - orbSize) * 0.5F;
      if (innerGlass) {
         this.drawLiquidGlassSurface(
            matrix,
            orbX,
            orbY,
            orbSize,
            orbSize,
            orbSize * 0.5F,
            0.0F,
            refraction * 0.8F,
            fresnelPower,
            0.9F,
            0.2F,
            squircle,
            glassColor,
            rimColor,
            a,
            false
         );
      }
      if (!DrawUtil.drawDolphyAvatar(matrix, orbX + 1.5F, orbY + 1.5F, orbSize - 3.0F, (orbSize - 3.0F) * 0.5F, a) && logoFont != null) {
         float lw = logoFont.getWidth("A", 11.5F);
         Builder.text().font(logoFont).text("A").size(11.5F).color(white).build().render(matrix, orbX + (orbSize - lw) * 0.5F, orbY + 4.8F);
      }

      float textX = orbX + orbSize + 6.5F;
      if (bold != null) {
         Builder.text().font(bold).text("DolphyVisuals").size(7.8F).color(white).build().render(matrix, textX, y + 7.5F);
      }
      if (semibold != null) {
         Builder.text().font(semibold).text(fps + " FPS  •  " + ping + " ms").size(6.3F).color(subWhite).build().render(matrix, textX, y + 18.0F);
      }

      float waveBaseX = x + w - 52.0F;
      float centerY = y + h * 0.5F;
      for (int i = 0; i < 5; i++) {
         float phase = (nowMs / 140.0F) + i * 0.85F;
         float barH = 4.0F + (float)(Math.sin(phase) * 0.5 + 0.5) * 9.5F;
         float bx = waveBaseX + i * 3.4F;
         Color barCol = i % 2 == 0 ? white : GuiUtils.withAlpha(themeColor, a * 0.95F);
         Builder.rectangle()
            .size(new SizeState(2.0F, barH))
            .radius(new QuadRadiusState(1.0F))
            .color(new QuadColorState(barCol))
            .build()
            .render(matrix, bx, centerY - barH * 0.5F);
      }

      if (bold != null) {
         float tw = bold.getWidth(timeStr, 7.5F);
         Builder.text().font(bold).text(timeStr).size(7.5F).color(white).build().render(matrix, x + w - tw - 8.5F, centerY - 3.5F);
      }
   }

   private void renderPureLensContent(
      Matrix4f matrix,
      float x,
      float y,
      float w,
      float h,
      int fps,
      int ping,
      String bpsStr,
      String timeStr,
      Color themeColor,
      Color rimColor
   ) {
      MsdfFont bold = BOLD_FONT.get();
      MsdfFont semibold = SEMIBOLD_FONT.get();
      MsdfFont logoFont = LogoRenderer.DOLPHY_FONT.get();

      float a = this.animationProgress;
      Color white = GuiUtils.withAlpha(Color.WHITE, a);
      Color subtle = GuiUtils.withAlpha(new Color(235, 242, 255), a * 0.78F);

      if (!DrawUtil.drawDolphyAvatar(matrix, x + (w - 20.0F) * 0.5F, y + 14.0F, 20.0F, 10.0F, a) && logoFont != null) {
         float lw = logoFont.getWidth("A", 18.0F);
         Builder.text().font(logoFont).text("A").size(18.0F).color(white).build().render(matrix, x + (w - lw) * 0.5F, y + 16.0F);
      }

      if (bold != null) {
         String brand = "DolphyVisuals";
         float bw = bold.getWidth(brand, 10.0F);
         Builder.text().font(bold).text(brand).size(10.0F).color(white).build().render(matrix, x + (w - bw) * 0.5F, y + 40.0F);
      }

      if (semibold != null) {
         String info = fps + " FPS  •  " + ping + " MS  •  " + bpsStr + " BPS";
         float iw = semibold.getWidth(info, 6.5F);
         Builder.text().font(semibold).text(info).size(6.5F).color(subtle).build().render(matrix, x + (w - iw) * 0.5F, y + 56.0F);
      }

      float homeW = 42.0F;
      float homeH = 2.6F;
      Builder.rectangle()
         .size(new SizeState(homeW, homeH))
         .radius(new QuadRadiusState(homeH * 0.5F))
         .color(new QuadColorState(new Color(255, 255, 255, (int)(190.0F * a))))
         .build()
         .render(matrix, x + (w - homeW) * 0.5F, y + h - 7.0F);
   }

   private int getPing(MinecraftClient mc) {
      if (mc.getNetworkHandler() != null && mc.player != null) {
         PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
         if (entry != null) {
            return entry.getLatency();
         }
      }
      return 0;
   }

   public float getScaleModifier() {
      MinecraftClient mc = MinecraftClient.getInstance();
      double currentGuiScale = mc.getWindow().getScaleFactor();
      if (currentGuiScale <= 0.0) {
         currentGuiScale = 2.0;
      }
      return (float)(2.0 / currentGuiScale);
   }

   public boolean onMouseClicked(double mouseX, double mouseY, int button) {
      MinecraftClient mc = MinecraftClient.getInstance();
      boolean isEditing = mc.currentScreen instanceof HudEditorScreen;
      if (!isEditing && !this.isHudEnabled()) {
         return false;
      }
      float scaleModifier = this.getScaleModifier();
      float effectiveW = this.currentWidth * scaleModifier;
      float effectiveH = this.currentHeight * scaleModifier;
      if (button == 0 && mouseX >= this.x && mouseX <= this.x + effectiveW && mouseY >= this.y && mouseY <= this.y + effectiveH) {
         this.dragging = true;
         this.isDragging = true;
         this.dragOffsetX = (float)(mouseX - this.x);
         this.dragOffsetY = (float)(mouseY - this.y);
         return true;
      }
      return false;
   }

   public void onMouseDragged(double mouseX, double mouseY, int button) {
      if (button == 0 && this.dragging) {
         MinecraftClient mc = MinecraftClient.getInstance();
         float scaleModifier = this.getScaleModifier();
         float screenW = mc.getWindow().getScaledWidth();
         float screenH = mc.getWindow().getScaledHeight();
         float effectiveW = this.currentWidth * scaleModifier;
         float effectiveH = this.currentHeight * scaleModifier;
         this.x = Math.max(0.0F, Math.min(Math.max(0.0F, screenW - effectiveW), (float)mouseX - this.dragOffsetX));
         this.y = Math.max(0.0F, Math.min(Math.max(0.0F, screenH - effectiveH), (float)mouseY - this.dragOffsetY));
      }
   }

   public void onMouseReleased(double mouseX, double mouseY, int button) {
      if (button == 0) {
         this.dragging = false;
         this.isDragging = false;
      }
   }

   public void onMouseReleased(int button) {
      if (button == 0) {
         this.dragging = false;
         this.isDragging = false;
      }
   }

   public float getX() {
      return this.x;
   }

   public float getY() {
      return this.y;
   }

   public void setX(float x) {
      this.x = x;
   }

   public void setY(float y) {
      this.y = y;
   }

   public void setX(double x) {
      this.x = (float)x;
   }

   public void setY(double y) {
      this.y = (float)y;
   }

   public float getWidth() {
      return this.currentWidth;
   }

   public float getHeight() {
      return this.currentHeight;
   }
}
