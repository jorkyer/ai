package xyz.angames.dolphy.client.module.modules.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import xyz.angames.dolphy.client.module.Module;
import xyz.angames.dolphy.client.module.setting.BooleanSetting;
import xyz.angames.dolphy.client.module.setting.ModeSetting;
import xyz.angames.dolphy.client.module.setting.NumberSetting;

@Environment(EnvType.CLIENT)
public class LunarHatModule extends Module {
   public final ModeSetting style = new ModeSetting(
      "Style",
      "King Crown",
      "King Crown",
      "Angel Halo",
      "Devil Horns",
      "Top Hat",
      "Wizard Hat",
      "Bunny Ears",
      "Deadmau5"
   );
   public final ModeSetting colorMode = new ModeSetting("Color", "Theme", "Theme", "Gold", "Chroma", "Crimson", "White");
   public final BooleanSetting self = new BooleanSetting("Self", true);
   public final BooleanSetting friends = new BooleanSetting("Friends", true);
   public final NumberSetting scale = new NumberSetting("Scale", 1.0, 0.65, 1.45, 0.05);
   public final BooleanSetting bobbing = new BooleanSetting("Bobbing", true);

   public LunarHatModule() {
      super("LunarHat", "Lunar Client 3D hats: Crown, Halo, Horns, Top Hat, Wizard, Bunny, Deadmau5", Module.Category.COSMETIC);
      this.addSettings(this.style, this.colorMode, this.self, this.friends, this.scale, this.bobbing);
   }
}
