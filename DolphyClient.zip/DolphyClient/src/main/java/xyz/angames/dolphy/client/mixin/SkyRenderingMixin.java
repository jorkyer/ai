package xyz.angames.dolphy.client.mixin;

import net.minecraft.class_9975;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.angames.dolphy.client.DolphyClient;
import xyz.angames.dolphy.client.module.modules.render.AmbientsModule;

@Mixin(class_9975.class)
public class SkyRenderingMixin {
    @Inject(method = "method_62302", at = @At("HEAD"), cancellable = true)
    private void onRenderEndSky(int color, CallbackInfo ci) {
        AmbientsModule ambients = DolphyClient.getInstance().getModuleManager().getModule(AmbientsModule.class);
        if (ambients != null && ambients.shouldOverrideEndSky()) {
            ci.cancel();
        }
    }
}
